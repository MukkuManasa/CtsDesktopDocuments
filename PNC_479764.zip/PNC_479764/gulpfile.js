'use strict';

var gulp = require('gulp');
var connect = require('gulp-connect');
var open = require('gulp-open');
var watch = require('gulp-watch');
var concat = require('gulp-concat'),
    useref = require('gulp-useref'),
    gulpif = require('gulp-if'),
    uglify = require('gulp-uglify'),
    minifyCss = require('gulp-minify-css');

var paths = {
    appDir: 'src',
    buildDir: 'dist',
    scripts: {
        dir: 'app/js',
        src:  'app/js/**/*.js',
        dest: 'dist/js'
    },
    styles: {
        dir: 'app/styles',
        src:  'app/styles/**/*.css',
        dest: 'dist/styles'
    },
    images: {
        dir: 'app/images',
        src: 'app/images/**/*',
        dest: 'dist/images',
    },
    fonts: {
    		dir: null,
    		src: null,
    		dest: 'dist/fonts'
    }
};
 
gulp.task('webserver', function() {
  connect.server({
    livereload: true,
    port:8080,
    root:'src'
  });
});

gulp.task('livereload', function() {
  gulp.src(['src/**/*.css', 'src/scripts/*.js'])
    .pipe(watch())
    .pipe(connect.reload());
});

gulp.task('buildCss', function() {
	gulp.src('src/**/*.css')
	.pipe(concat('main.css'))
	.pipe(gulp.dest('dist/css'))
	.pipe(connect.reload());
});

gulp.task('scripts', function() {
    gulp.src('src/js/*.js')
      .pipe(concat('vendor.js'))
      .pipe(gulp.dest('dist/js'))
	  .pipe(connect.reload());
});

gulp.task('load', function() {
    gulp.src('*.html')
    .pipe(connect.reload());
});

gulp.task('watcher', function() {
	gulp.watch(['src/**/*.css'], ['buildCss']);
	gulp.watch(['src/js/*.js'], ['scripts']);
  gulp.watch(['*.html'], ['load']);
});

gulp.task('watch', ['watcher']);

gulp.task('css', ['buildCss']);
 
gulp.task('default', ['webserver', 'watch', 'app']);

gulp.task('app', function(){
  var options = {
    uri: 'http://localhost:8080',
    app: 'chrome'
  };
  gulp.src('')
  .pipe(open(options));
});

gulp.task('html', function () {
    return gulp.src('src/**/*.html')
        .pipe(useref())
        .pipe(gulpif('*.js', uglify()))
        .pipe(gulpif('*.css', minifyCss()))
        .pipe(gulp.dest('dist1'));
});


gulp.task('build', ['html', 'images']);
