"use strict";
(function(){
angular.module('PNCApp')
	.constant("PNC_EVENTS",{
		
		

	});		
 })();