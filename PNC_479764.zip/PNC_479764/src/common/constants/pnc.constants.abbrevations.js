"use strict";
(function(){
angular.module('PNCApp')
	.constant("PNC_CONSTANT",{
		      "HM":"Home",
		      "LT":"Logout",
		      "AM":"Administration",
		      "AR":"Analysis & Report",
		      "analysis":"AR",
		      "TL":"Tools",
		      "ME":"Model Execution Dashboard",
		      "CD":"Control Dashboard",
		      "SD":"Status Dashboard",
		      "ED":"Enterprise Dashboard",
		      "MQ":"My Queue",
		      "UM":"User Management",
		      "RM":"Role Management",
		      "DS":"Dimsum Monitoring",
		      "landing":"HM",
		      "modelExecution":"ME",
		      "administration":"AM",
		      "tools":"TL",
		      "RP":"All Runs",
		      "MR":"My Runs"
	});		
 })();