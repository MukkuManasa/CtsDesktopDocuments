"use strict";
(function(){
angular.module('PNCApp')
	.constant("PNC_STATE_CONSTANT",{
		/*map submenu short name as statename to dynamic state */
		      "UM":"administration.userManagement",
		      "RM":"administration.roleManagement",
		      "CD":"modelExecution.controldashboard",
		      "SD":"modelExecution.statusdashboard",
		      "ED":"modelExecution.enterprisedashboard",
		      "DS":"modelExecution.dimsum",
		      "MQ":"modelExecution.myqueue",
		      "RP":"tools.runPlan",
		      "MR":'tools.myRuns',
		      "AP":"tools.aggregationPlan"

	});		
 })();