"use strict";
(function(){

	angular.module('PNCApp')
	.decorator("pncServices",['$delegate', function($delegate){

            var generateCustomFiltersLogic = function(table,dtInstance,$compile,scope,trigger,filteredColumn){
            	        var filterTemplate = '';
            	        var searchRule = {};
            	        if(trigger){
            	        	searchRule = {search:'applied'};
            	        	applyFilter.call(filteredColumn,table);
            	        }
             	        table.api().columns(searchRule).every( function (index) {
				                var column = this;
				                var columnIndex = index;
				                if(trigger && filteredColumn && $(column.header()).is(filteredColumn)){
				                	return false;
				                }
				                if(!trigger){
				                	column.search('').draw();
				                }
				                if($(column.header()).find('.filterOverlay').length > 0){
	                                  $(column.header()).find('.filterOverlay').remove();
	                                  //$(column.header()).removeClass('filterApplied');
				                }
				                if(!(column.data().length==0 || (column.data().unique().length == 1 && column.data()[0]==null)) && column.visible()){
				                	var num = Math.random() * 10 + 1;
				                	var select = $('<div class="filterOverlay"><span class="filterImg"></span><div class="filterDiv"><div class="filterHeader">Filter</div><ul ng-scrollbars ng-scrollbars-config="scrollbarFilterConfig"><li class="checkbox"><input id="selectAll'+num+'" type="checkbox" value="selectAll" class="selectAllToggle labelChecked" checked><label for="selectAll'+num+'">Select All</label></li></ul><div class="filterButtons"><button class="filterSave grayButton">Ok</button><button class="filterCancel orangeButton">Cancel</button></div></div></div>')
			                                     .appendTo( $(column.header()));
			                        select.find('.filterSave').off('click');
			                        select.find('.filterImg').off('click');
			                        select.find('ul').off('click');
			                        select.find('.filterHeader').off('click');
			                        select.find('.filterCancel').off('click');
			                        select.find('.selectAllToggle').off('change');
			                        var colorRegex = /^#([0-9a-f]{3}|[0-9a-f]{6})$/i;
			                        if($(column.header()).hasClass('received')||$(column.header()).hasClass('expected')||$(column.header()).hasClass('errors')){
                                        column.data().unique().sort().each( function ( d, j ) {
                                        	if(d!=null){
                                        	   var splitData = d.split('~');
                                        	   filterTemplate += '<li class="checkbox inputCheck"><input class="labelChecked" id="'+d+num+'" type="checkbox" value="'+d+'" checked><label for="'+d+num+'"><span class="colorColumn" style="background-color:'+splitData[0]+'">'+splitData[1]+'</span></label></li>';
                                        	}
                                                    
                                       	});
			                        }else{
			                        	column.data().unique().sort().each( function ( d, j ) {
				                         if(d!=null){
						                   		filterTemplate += '<li class="checkbox inputCheck"><input class="labelChecked" id="'+d+num+'" type="checkbox" value="'+d+'" checked><label for="'+d+num+'">'+d+'</label></li>';
				                        	
				                         }
							            });
			                        }
							        select.find('ul').append(filterTemplate);
						            filterTemplate="";
						            select = $compile(select)(scope);
						            select.find('.filterSave').on( 'click', function (e) {
					                    	e.stopPropagation();
					                    	var filteredColumn = $(this).closest('th');
					                    	$(this).closest('.filterOverlay').find('ul li.inputCheck input').each(function(){
						                     		$(this).removeClass('labelChecked');
						                    })
					                   	    var searchValue = "";
					                   	    var checkedArray = $(this).closest('.filterOverlay').find('ul li.inputCheck input:checked');
						                    if(checkedArray.length>1){
						                     	checkedArray.each(function(i){
						                     		if(i === checkedArray.length-1){
						                     			 searchValue += ("^"+$(this).val()+"$");
						                     		}else{
						                     			  searchValue += ("^"+$(this).val()+"$")+ "|";
						                     		}
						                     		$(this).addClass('labelChecked');
						                        });
						                     }else if(checkedArray.length===1){
						                     	searchValue =  "^"+checkedArray.val()+"$";
						                     	$(checkedArray).addClass('labelChecked');
						                     }else{
						                     	$(this).closest('th').removeClass('filterApplied');
						                     	$('#clearFilter').addClass('disableFilter');
						                     	searchValue =null;
						                     }

			                                 column.column(columnIndex,{search:'applied'}).search(searchValue,true,false,true).draw();
					                    	 $(this).closest('.filterOverlay').find('.filterDiv').toggleClass('openFilter');
					                    	 generateCustomFiltersLogic(table,dtInstance,$compile,scope,'filtered',filteredColumn);
					                    	 /*var numOfCheckboxes = select.find('ul li.inputCheck input').length;
						            	     var numOfCheckedCheckboxes = select.find('ul li.inputCheck input:checked').length;
							            	 if(numOfCheckboxes === numOfCheckedCheckboxes){
							            	 	$(this).closest('th').removeClass('filterApplied');
							            	 }*/
					                });
                                    select.find('.filterImg').on('click',function(e){
				                    	$('tbody tr').removeClass("rowActive");
										$("tbody tr td span.options").remove();
				                    	e.stopPropagation();

				                    	select.closest('tr').find('th .filterOverlay .filterDiv').each(function(){
				                    		if($(this).hasClass('openFilter')){
				                    			 $(this).removeClass('openFilter')
				                    		}
				                    	})
				                    	$(this).closest('.filterOverlay').find('.filterDiv').toggleClass('openFilter').removeClass('flipFilterDiv');
				                    	/*var filterDiv = $(this).closest('.filterOverlay').find('.filterDiv'),
				                    	    offset = $(filterDiv).offset();
				                    	if(offset.top + $(this).closest('.filterOverlay').find('.filterDiv').outerHeight() > $('body').outerHeight()){
	                                         $(filterDiv).addClass('flipFilterDiv');
				                    	}*/
				                    })
                                    select.find('ul').on('click',function(e){	
				                                 e.stopPropagation();
						            })
						            select.find('.filterHeader').on('click',function(e){	
				                                 e.stopPropagation();
						            })
						            select.find('ul li.inputCheck input').on('change',function(){
						            	var numOfCheckboxes = select.find('ul li.inputCheck input').length;
						            	var numOfCheckedCheckboxes = select.find('ul li.inputCheck input:checked').length;
						            	if(numOfCheckboxes === numOfCheckedCheckboxes){
						            		select.find('.selectAllToggle').prop('checked', true);
						            	}else{
						            		select.find('.selectAllToggle').prop('checked', false);
						            	}

						            })
						            select.find('.filterCancel').on('click',function(e){
					                    	e.stopPropagation();
					                    	 	$(this).closest('.filterOverlay').find('ul li.inputCheck input').each(function(){
							                    	 	if(!$(this).hasClass('labelChecked')){
							                    	 	  $(this).prop('checked', false);
							                    	    }else{
							                    	    	$(this).prop('checked', true);
							                    	    }
							                    })
							                    var numOfCheckboxes = select.find('ul li.inputCheck input').length;
								            	var numOfCheckedCheckboxes = select.find('ul li.inputCheck input:checked').length;
								            	if(numOfCheckboxes === numOfCheckedCheckboxes){
								            		select.find('.selectAllToggle').prop('checked', true);
								            	}else{
								            		select.find('.selectAllToggle').prop('checked', false);
								            	}
					                    	 $(this).closest('.filterOverlay').find('.filterDiv').toggleClass('openFilter');
					                })
					                select.find('.selectAllToggle').on('change',function(){
					                	$(this).parent().siblings().find('input:checkbox').prop('checked', $(this).prop("checked"));
					                })
					                //select.find('input:checkbox').prop('checked',$(select).closest('th').find('.selectAllToggle').prop("checked"))
					                
			                    
				                }
			            });
			            
             	
					                
						                
            }

            var applyFilter = function(table){
                var defaultData = table.api().columns(0).data()[0];
                var filteredData = table.api().columns(0,{search:'applied'}).data()[0];
                if(defaultData && filteredData){
	        	 	  if(defaultData.length === filteredData.length){
	        	 	    $(this).closest('th').removeClass('filterApplied');
	        	 		$('#clearFilter').addClass('disableFilter');
	        	 	  }else{
	         			$(this).closest('th').addClass('filterApplied');
	                 	$('#clearFilter').removeClass('disableFilter');
	        	 	  }
				}

            }

	  	    //Generate dataTable and costum filtering 
	  	    $delegate.generateDTCustomFilters = function(dtInstance,$compile,scope){
                       var table =  dtInstance.dataTable;
                       $(table).find('th').removeClass('filterApplied');
                       $('#clearFilter').addClass('disableFilter');
					   generateCustomFiltersLogic(table,dtInstance,$compile,scope);
					   $(document).on('click',function(e){
                         	if(!$(e.target).parent().hasClass('filterDiv')){
                                 $('table').find('.filterOverlay').find('.filterDiv.openFilter').find('.filterCancel').trigger('click');
                         	}
                       })
                       $(document).on('click','#clearFilter',function(){
	                        $(table).find('th').removeClass('filterApplied');
	                        $(this).addClass('disableFilter');
                       	    generateCustomFiltersLogic(table,dtInstance,$compile,scope);
                       })
					                 
			}

	        return $delegate;

	}]);

})();