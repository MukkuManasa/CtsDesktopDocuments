"use strict";
(function(){

	angular.module('PNCApp')
	.decorator("pncServices",['$delegate','$rootScope','$uibModal',
		function($delegate,$rootScope,$uibModal){
				/*  edit and delete buttons functionality*/
		   		$delegate.editDeleteButtons = function(dtInstance,$compile,scope){
                           var table =  dtInstance.dataTable; 
                           $('.table-responsive table tbody').off('click');
                           $('tbody tr').removeClass("rowActive");
				           $("tbody tr td span.options").remove();
						   table.api().rows().every( function () {
						    	var row=this;
						    	var trIndex=null;
						    	trIndex = row.node();
						    	if($('#administrationWrapper .userManagement').length>0){
						    	$(trIndex).attr("data-id",row.data().userCd).attr("data-isFlag",row.data().isDeletedFlag);
						    }else{
						    	$(trIndex).attr("data-id",row.data().roleCd).attr("data-isFlag",row.data().isActiveFlag);
						    }

				            });
						    $('#dataTable').on('page.dt', function() {
	    						$('tbody tr').removeClass("rowActive");
					           	$("tbody tr td span.options").remove();
							});
				            $('.table-responsive table tbody').on('click', 'tr td:not(span)', function () {
				              	var trIndex=$(this).parent();
				              	if($(trIndex).hasClass("rowActive")){
				              		$('tbody tr').removeClass("rowActive");
				              		$("tbody tr td span.options").remove();
				              		$(".cloneRunplan").removeClass("orangeButton");
				              		$(".cloneRunplan").addClass("grayButton");
				              		scope.cloneDisable=true;
				              	}
				              	else{
				              		$('tbody tr').removeClass("rowActive");
				              		$("tbody tr td span.options").remove();
				              		$(trIndex).addClass("rowActive");
				              		scope.cloneDisable=false;
				              		$(".cloneRunplan").removeClass("grayButton");
				              		$(".cloneRunplan").addClass("orangeButton");
				              		scope.id=$(trIndex).attr("data-id");
								scope.isFlag = $(trIndex).attr("data-isFlag");	
								if($('#administrationWrapper .userManagement').length>0){
								if(scope.isFlag=='NO' && $("tbody tr td").hasClass("editdelete")){	
								$compile($(trIndex).find('.editdelete').append('<p><span class="options" id="edit"  ng-click="editRow($event); $event.stopPropagation();"></span></p>'))(scope);
								}
								else{	
								$("tbody tr td span.options").remove();
								$compile($(trIndex).find('.editdelete').append('<p><span class="options" id="edit" ng-click="editRow($event); $event.stopPropagation();"></span><span class="options" id="delete"  ng-click="deleteRow(); $event.stopPropagation();"></span></p>'))(scope);
								}
							}else{
								if(scope.isFlag=='NO' || scope.isFlag==undefined){	
								$compile($(trIndex).find('td:last-child').append('<p><span class="options" id="edit"  ng-click="editRow($event); $event.stopPropagation();"></span></p>'))(scope);
								}
								else{	
								$("tbody tr td span.options").remove();
								$compile($(trIndex).find('td:last-child').append('<p><span class="options" id="edit" ng-click="editRow($event); $event.stopPropagation();"></span><span class="options" id="delete"  ng-click="deleteRow(); $event.stopPropagation();"></span></p>'))(scope);
								}
							}
				              	}
				              })   
				       
		   		}  
				             
							new function ($) {
        $.fn.getCursorPosition = function () {
            var pos = 0;
            var el = $(this).get(0);
            // IE Support
            if (document.selection) {
                el.focus();
                var Sel = document.selection.createRange();
                var SelLength = document.selection.createRange().text.length;
                Sel.moveStart('character', -el.value.length);
                pos = Sel.text.length - SelLength;
            }
            // Firefox support
            else if (el.selectionStart || el.selectionStart == '0')
                pos = el.selectionStart;
            return pos;
        }
        $.fn.selectRange = function(start, end) {
    return this.each(function() {
        if (this.setSelectionRange) {
            this.focus();
            this.setSelectionRange(start, end);
        } else if (this.createTextRange) {
            var range = this.createTextRange();
            range.collapse(true);
            range.moveEnd('character', end);
            range.moveStart('character', start);
            range.select();
        }
    });
};

    } (jQuery);
	            return $delegate;

	}]);

})();