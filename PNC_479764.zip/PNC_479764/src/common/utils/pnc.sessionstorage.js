"use strict";
(function(){
angular.module('PNCApp')
	.factory("pncsession",['$sessionStorage',
	function($sessionStorage){
		
		this.update = function (key, value){
			$sessionStorage[key] = value;
		}

		this.get = function (key){
			return $sessionStorage[key];
		}

		this.remove = function (key){
			delete $sessionStorage[key];
		}

		this.removeAll = function (){
			$sessionStorage.$reset();
		}

		return this;

	}]);		
 })();