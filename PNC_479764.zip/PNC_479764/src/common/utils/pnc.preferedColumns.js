"use strict";
(function(){

	angular.module('PNCApp')
	.decorator("pncServices",['$delegate','$rootScope','pncsession','PNC_SESSION_CONFIG','$uibModal',
		function($delegate,$rootScope,pncsession,PNC_SESSION_CONFIG,$uibModal){
		  	 /*Hide colums and preferences */

		   		$delegate.preferedColumns = function(dtInstance,$compile,scope,noOfColumns,hideColumns){
	               
						   var hideColumn=hideColumns,
                            table =  dtInstance.dataTable,
                            checkboxArray = $('.preferencesDiv').find('ul input');
                           $('.table-responsive table tbody').off('click');
                           $('tbody tr').removeClass("rowActive");
				           $("tbody tr td span.options").remove();
				            $("tbody tr td").removeClass("editdelete");
                            if(pncsession.get(PNC_SESSION_CONFIG.PREFERED_DATA)!=undefined){
	                           	var toRemove=pncsession.get(PNC_SESSION_CONFIG.PREFERED_DATA);
	                           	var allColumns = noOfColumns;
		                           	if(allColumns.length!=toRemove.length){
		                           	hideColumn = allColumns.filter( function( el ) {
		  								return toRemove.indexOf( el ) < 0;
									});
		                           }
		                           else{
		                           	hideColumn=[];
		                           }
	                           var lastColumn = table.api().columns($(toRemove[toRemove.length-1])).nodes()[0];	
				            	for(var key in lastColumn){
	                        	$(lastColumn[key]).addClass("editdelete");
			    				}
	                           }
                            else{
								hideColumn=hideColumns;
								var showColumns = [];
								noOfColumns.filter(function(val){
									if(hideColumn.indexOf(val) === -1){
										showColumns.push(val);
									}
								})
								var lastShownColumn = showColumns[showColumns.length-1]
								if($('.preferencesDiv').length>0){
	                               var arr = (table.api().columns(lastShownColumn).nodes())[0];	
	                               for(var key in arr){
	                        		  $(arr[key]).addClass("editdelete");
			    					}
			    				}
							}
							for(var loop=0;loop<checkboxArray.length;loop++){
								 $(checkboxArray[loop]).addClass("preferenceLabelChecked");
							}
						for(var j=0;j<hideColumn.length;j++){
							var arr = (table.api().columns(hideColumn[j]).nodes())[0];	
			               	for(var key in arr){
                        	$(arr[key]).hide();
		    				}
		    				$(table.api().columns(hideColumn[j]).header()).hide();
			                }
                           
						    table.api().columns().every( function () {
			                var column = this;
			                if($('.preferencesDiv').length>0){	
			                	pncsession.update(PNC_SESSION_CONFIG.HIDECOLUMN_DATA,hideColumn);	
			                for(var j=0;j<hideColumn.length;j++){
			                	if(column.index()==hideColumn[j]){
			                $($('.preferencesDiv').find('ul input')[column.index()]).removeClass("preferenceLabelChecked");
			            	}
			            	}
			            }
			             });
						    
						    /*if($("thead tr").height()<70){
								$("thead tr").find('.filterOverlay').addClass("singleRow");
			    			}else if($("thead tr").height()>88){
			    				$("thead tr").find('.filterOverlay').removeClass("singleRow");
                                $("thead tr").find('.filterOverlay').addClass("tripleRow");
			    			}
			    			else{
			    				 $("thead tr").find('.filterOverlay').removeClass("tripleRow");
			    				$("thead tr").find('.filterOverlay').removeClass("singleRow");
			    			}*/
					
		   		}
		   		
	            return $delegate;

	}]);

})();