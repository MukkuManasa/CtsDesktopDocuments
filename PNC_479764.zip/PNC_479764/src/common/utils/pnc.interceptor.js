"use strict";
(function(){
var mod = angular.module('PNCApp');
	

	mod.factory('httpRequestInterceptor', [ 'PNC_SESSION_CONFIG', 'pncsession','$q','$rootScope',
	    function (PNC_SESSION_CONFIG, pncsession,$q,$rootScope) {
		  return {
		    request: function (config) {
                var url = config.url;
                var serviceName = url.substr((url.lastIndexOf('/')+1));

                if(serviceName === "getProcessAuditData"){
                	$rootScope.$broadcast('modal_loader_show');
                }else{
		    	    $rootScope.$broadcast('loader_show');
		        } 
		    	config.withCredentials = true;
		    	if(pncsession.get(PNC_SESSION_CONFIG.X_XSRF_TOKEN)){
		    		config.headers["X-XSRF-TOKEN"] = pncsession.get('X-XSRF-TOKEN');
		    	}

		      return config;
		    },
		    response:function(response){
               $rootScope.$broadcast('loader_hide');
               $rootScope.$broadcast('modal_loader_hide');
                return response || $q.when(response);
		    },
		    responseError : function(response){
		    	//if(response.status){
		    	   $rootScope.$broadcast('loader_hide');
		    	   $rootScope.$broadcast('modal_loader_hide');
		    	   if(response.status == 440){
		    	   		$rootScope.$broadcast('pnc_logout','Session has expired, Please login again');
		    	   }
                   //console.log('failed');
                   //pncsession.update(PNC_SESSION_CONFIG.SHOW_TECHNCALDIFFICULTIES,true);
                   //$rootScope.$broadcast('appStatus');
		    	//}

		    	return $q.reject(response);
		    }
		  };
		}]);

	mod.config(['$httpProvider',function ($httpProvider) {
		$httpProvider.interceptors.push('httpRequestInterceptor');
	}]);

})();