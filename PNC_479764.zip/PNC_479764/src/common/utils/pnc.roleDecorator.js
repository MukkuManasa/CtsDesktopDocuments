"use strict";
(function(){

	angular.module('PNCApp')
	.decorator("pncServices",['$delegate','$rootScope','$uibModal',
		function($delegate,$rootScope,$uibModal){
				/*Role management  edit and delete buttons functionality*/
		   		$delegate.getRoleButtons = function(dtInstance,$compile,scope){
	                
                           var table =  dtInstance.dataTable; 
                           $('#administrationWrapper .roleManagement .table-responsive table tbody').off('click');
                           $('tbody tr').removeClass("rowActive");
				           $("tbody tr td span.options").remove();
						   table.api().rows().every( function () {
						    	var row=this;
						    	var trIndex=null;
						    	trIndex = row.node();
						    	$(trIndex).attr("data-id",row.data().roleCd).attr("data-isActiveFlag",row.data().isActiveFlag);

				            });
						    $('#dataTable').on('page.dt', function() {
	    						$('tbody tr').removeClass("rowActive");
					           	$("tbody tr td span.options").remove();
							});
				            $('#administrationWrapper .roleManagement .table-responsive table tbody').on('click', 'tr td:not(span)', function () {
				              	var trIndex=$(this).parent();
				              	if($(trIndex).hasClass("rowActive")){
				              		$('tbody tr').removeClass("rowActive");
				              		$("tbody tr td span.options").remove();
				              	}
				              	else{
				              		$('tbody tr').removeClass("rowActive");
				              		$("tbody tr td span.options").remove();
				              		$(trIndex).addClass("rowActive");
				              		scope.id=$(trIndex).attr("data-id");
								scope.isActiveFlag = $(trIndex).attr("data-isActiveFlag");	
								if(scope.isActiveFlag=='NO'){	
								$compile($(trIndex).find('td:last-child').append('<span class="options" id="edit"  ng-click="editRow($event); $event.stopPropagation();"></span>'))(scope);
								}
								else{	
								$("tbody tr td span.options").remove();
								$compile($(trIndex).find('td:last-child').append('<span class="options" id="edit" ng-click="editRow($event); $event.stopPropagation();"></span><span class="options" id="delete"  ng-click="deleteRow(); $event.stopPropagation();"></span>'))(scope);
								}
				              	}
				              })   
				         	scope.editRow = function(id){
		                 		$delegate.getRoleById(scope.id).then(function(data){
			                 		var modalInstance = $uibModal.open({
			                 			templateUrl:"modules/secure/administration/views/addRolePopup.html",
			                 			controller:'addRolePopupCtrl',
			                 			resolve: {
			                 				data: function () {
			                 					return data;
			                 				}
			                 			},
			                 			backdrop : 'static' 
			                 		});

	                 	    	},function(err){
			                 		$rootScope.$broadcast('error_show',err.data);
	                 			});

	                 		};
	                 		scope.deleteRow = function(id){
	                 			var modalInstance = $uibModal.open({
								templateUrl:"modules/secure/administration/views/deletePopup.html",
								controller:'deleteRolePopupCtrl',
								resolve: {
										id: function () {
											return scope.id;
										},
										flag: function () {
											return scope.isActiveFlag;
										},
									},
								backdrop : 'static',
								windowClass :'addModelDialogueWidth'
								});

	                 		};
		   		}
		   		
	            return $delegate;

	}]);

})();