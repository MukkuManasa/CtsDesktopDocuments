"use strict";
(function(){
	angular.module('PNCAppDirectives')
	.directive("stackedChartaspdf",['$window','pncsession','PNC_SESSION_CONFIG',function($window,pncsession,PNC_SESSION_CONFIG){
	return{
		restrict:"A",
		scope:{
			chartoptions:'='
		},
		link:function(scope,element,attrs){
			var d3 = $window.d3;
			var unwatchPrintChart = scope.$watch('chartoptions.printObjData',function(newValue,oldValue){
				if(newValue !== oldValue){
					$('.capturePdfChartSection .stackedChartWrapper #chartPdf').empty();
					if(Object.keys(scope.chartoptions.printObjData).length !== 0){
							for(var key in scope.chartoptions.printObjData){
						 	  renderChart(scope.chartoptions.printObjData[key]);
						    }
						    renderToCanvas();
				    }
					
				}
			})

			scope.$on('$destroy',function(){
					unwatchPrintChart();
			})

			function renderChart(data){
				var width,actualSvgWidth,yaxisHeight,maxYvalue,maxXvalue,
				bufferWidth = 50,
				spacing = scope.chartoptions.spacing,
				gridSize= scope.chartoptions.gridsize;
                d3.select('.capturePdfChartSection').style('display','block');
                var div = d3.select('.capturePdfChartSection .stackedChartWrapper #chartPdf').append('div').attr('class','chartHolder');
				var svg = div.append('svg');
				//yaxisSvg = d3.select('.yAxisSection').select('svg'),
				//tooltip = d3.select('.captureChartSection .stackedChartWrapper #chartPrint').append('div').attr("class","chartTooltip").style("opacity",0);

				svg.attr("version", "1.1");
				svg.attr("xmlns", "http://www.w3.org/2000/svg");
				svg.attr("xmlns:xlink", "http://www.w3.org/1999/xlink");
				svg = svg.append("g").attr('transform','translate(180,50)');
				var layersArr = [],
				maxXvalue = Math.max.apply(Math,data['3'].map(function(o){return o.x;}));
				maxYvalue = Math.max.apply(Math,data['3'].map(function(o){return o.y;}));
				for(var i=0;i<= maxXvalue;i++){
					var layers = [];
					layers = data['3'].filter(function(d) {
						if(d.x == i){
							return d;
						}

					});
					layersArr.push(layers)

				}

				actualSvgWidth = ((gridSize+spacing) *(maxXvalue+1));
				var actualSvgHeight = ((gridSize * (maxYvalue+1)) + 100);

				var y = d3.scale.ordinal().rangeRoundBands([0,actualSvgHeight]);

				var yAxis = d3.svg.axis().scale(y).orient("left").ticks(5).tickSize(0);

				y.domain(data['2'].map(function(d){
					return d[Object.keys(d)]
				}))

				function make_y_axis(){
					return 	d3.svg.axis().scale(y).orient("left").ticks(5);
				}   
				svg.append("g").attr("class","axis yaxis")
				.attr("transform","translate(0,0)").call(yAxis).selectAll('.tick').each(function(d,i){
					var tick = d3.select(this);
					wrap(tick.select('text'),(y.rangeBand()*2)+20,'yaxis');
					tick.attr("transform","translate(-4,"+(((i)*gridSize)+(gridSize/2))+")")
					tick.select('text').attr('font-size',12+'px')
				})

				var yaxisWidth = Math.round(d3.select('.yaxis').node().getBBox().width);
				var totalSvgWidth = actualSvgWidth + yaxisWidth;
				width =  actualSvgWidth + bufferWidth;

				div.select('svg').attr('width',totalSvgWidth + 750).attr('height',actualSvgHeight+150);
				d3.select('.captureChartSection .StackedChartSection').select('.processGroup').style("width",actualSvgWidth + 'px');

				var x = d3.scale.ordinal().rangeRoundBands([0,actualSvgWidth]);
				var xAxis = d3.svg.axis().scale(x).orient("bottom").tickSize(0);
				x.domain(data['1'].map(function(d){
					return d.PROCESS_NAME;
				}))
				var layer = svg.append('g').attr('transform','translate(10,0)').selectAll(".layer")
				.data(layersArr).enter().append("g").attr("transform",function(d,i){
					return "translate("+(i)*spacing+",0)";
				});

				layer.selectAll('rect').data(function(d){
					return d;
				})
				.enter().append("rect")
				.attr("x",function(d){
					return (d.x)* gridSize;
				})
				.attr("y",function(d){
					return (d.y)*gridSize;
				})
				.attr('fill',function(d){return d.color})
				.attr("width",gridSize)
				.attr("height",gridSize)
				

				layer.selectAll('.rect1').data(function(d){
					return d;
				})
				.enter().append("rect")
				.attr("x",function(d){
					return (d.x)* gridSize;
				})
				.attr("y",function(d){
					return (d.y)*gridSize;
				})
				.attr("width",40)
				.attr("height",40)
				.attr('fill',function(d){
					var userID = pncsession.get(PNC_SESSION_CONFIG.LOGGEDIN_USER_INFO).user_Details.userCd;
					if (d.processStatus === "Not Started" && userID === d.approverID) {
						return 'url(#pending)'
					}
					else if (d.processStatus === "Executed" && userID === d.approverID) {
						return 'url(#pending)'
					}
					else if (d.processStatus === "Rejected" && userID === d.approverID) {
						return 'url(#pending)'
					}
					else {
						return d.color;
					}
				})

				svg.append('g').attr("class","axis xaxis")
				.attr("transform","translate(20,"+(actualSvgHeight-100)+")").call(xAxis)
				.selectAll('.tick').each(function(d,i){
					var tick = d3.select(this);
					if(tick.select('text').text()=== data['1'][i].PROCESS_NAME){
						if(data['1'][i].COLOR){
							tick.style("fill",data['1'][i].COLOR);
						}
						else{
							tick.style("fill","#2c94ff");
						}
					}
					wrap(tick.select('text'),x.rangeBand()-10,'xaxis');
					tick.attr("transform","translate("+((i*(gridSize+spacing))+10)+",0)")
					tick.select('text').attr('font-size',12+'px')
				});
				
				
				svg.append("g")            
				.attr("class", "grid")
				.call(make_y_axis()
					.tickSize(-totalSvgWidth, 0, 0)
					.tickFormat("")
					).selectAll('.tick').each(function(d,i){
						var tick = d3.select(this);
						yaxisHeight = (i+1)*gridSize;
						tick.attr("transform","translate("+(-yaxisWidth)+","+(i+1)*gridSize+")")
						tick.select('line').attr("y2",2).attr("stroke","black");
						if(y.domain().length - 1 === i){
							tick.attr("style","opacity:0");
						}
					})

					svg.select('.yaxis').select('path').attr("d","M0,0V0H0V"+(yaxisHeight+(gridSize/2))).attr("transform","rotate(-180) translate(0,"+-yaxisHeight+")").attr('stroke',"black")
					d3.select('.StackedChartSection').select('.controlOwnerGroup').style("height",yaxisHeight + 'px');
					svg.append("text")
					.attr("font-size","14px")
					.attr("font-family", "MetaOffcPro-Medi")
					.attr("dx", 0)
					.attr("dy", yaxisHeight+113)
					.text("Status Legend :");
					var color = d3.scale.category20();
					var dataset =[{"x":95, "r":6, "name":"Not Applicable","type":"controldashboard","colorcode":"#586671"}, 
					{"x":200, "r":6, "name":"Not Started","type":"controldashboard","colorcode":"#2c94ff"},
					{"x":300, "r":6, "name":"Executed","type":"controldashboard","colorcode":"#fd9b00"}, 
					{"x":380, "r":6, "name":"Reviewed","type":"controldashboard","colorcode":"#23a565"},
					{"x":455, "r":6, "name":"Rejected","type":"controldashboard","colorcode":"#bf0101"},
					{"x":95, "r":6, "name":"Not Applicable","type":"enterprisedashboard","colorcode":"#586671"}, 
					{"x":200, "r":6, "name":"Not Started","type":"enterprisedashboard","colorcode":"#2c94ff"},
					{"x":300, "r":6, "name":"Executed","type":"enterprisedashboard","colorcode":"#fd9b00"}, 
					{"x":380, "r":6, "name":"Reviewed","type":"enterprisedashboard","colorcode":"#23a565"},
					{"x":455, "r":6, "name":"Rejected","type":"enterprisedashboard","colorcode":"#bf0101"},
					{"x":90, "r":6, "name":"Not Applicable","type":"statusdashboard","colorcode":"#586671"}, 
					{"x":200, "r":6, "name":"Not Started","type":"statusdashboard","colorcode":"#2c94ff"},
					{"x":300, "r":6, "name":"Executed","type":"statusdashboard","colorcode":"#fd9b00"}, 
					{"x":380, "r":6, "name":"Reviewed","type":"statusdashboard","colorcode":"#23a565"}]
					var dataset1 ={"controldashboard1":[
					{"x":150,"name":"Input","colorcode":"#25A1EF"}, 
					{"x":180, "name":"Execution","colorcode":"#C14141"},
					{"x":235, "name":"Output","colorcode":"#05A505"}, 
					{"x":280, "name":"Reporting","colorcode":"#FFA500"}
					]};

					var condFlag=d3.select("#dashboardHolder").attr("class");
					condFlag = condFlag.split(" ")[0];
					var title;
					if(condFlag == "controldashboard"){
						title="Control Dashboard"
					}
					if(condFlag == "enterprisedashboard"){
						title="Enterprise Dashboard"
					}
					if(condFlag == "statusdashboard"){
						title="Status Dashboard"
					}
					var filtered = dataset.filter(function(d) {
						return d.type == condFlag; 
					});
					var forecast = d3.select(".forecast #dropdown").text();
					svg.append("text")
					.attr("dx", actualSvgWidth/2)
					.attr("dy",-25)
					.text(title+" ("+forecast+")")
					.attr("fill","#fd7607");

					var elem = svg.selectAll("g myCircleText")
					.data(filtered)
					var ele = elem.enter()
					.append("g")
					.attr("transform", function(d){return "translate("+(d.x+d.name.length)+","+(yaxisHeight+110)+")";})

					/* var ele = svg.append('g').attr('transform',"translate(30,"+(yaxisHeight+80)+")")*/
					var circle = ele.append("circle")
					.attr("r", function(d){return d.r} )
					.attr("stroke","black")
					.style("fill",function(d){return d.colorcode});
					ele.append("text")
					.attr("dx", 12)
					.attr("dy", 5)
					.text(function(d){
						return (d.name);
					})
					.attr("font-size","12px")
					.attr("font-family", "MetaOffcPro-Norm");
					svg.append("circle")
					.attr("r", 11)
					.attr("cx", 549)
					.attr("cy",yaxisHeight+105)
					.style("fill","url(#controlpending)")
					.style("display", function(condFlag) {
						condFlag =d3.select("#dashboardHolder").attr("class");
						condFlag = condFlag.split(" ")[0];
						return condFlag == "controldashboard" ? "block" : "none";
					});
					svg.append("text")
					.attr("dx", 562)
					.attr("dy",yaxisHeight+115)
					.style("display", function(condFlag) {
						condFlag =d3.select("#dashboardHolder").attr("class");
						condFlag = condFlag.split(" ")[0];
						return condFlag == "controldashboard" ? "block" : "none";
					})
					.text("Pending")
					.attr("font-size","12px")
					.attr("font-family", "MetaOffcPro-Norm");;
					svg.append("text")
					.attr("class","onlyControlDashboard")
					.attr("dx", 0)
					.attr("dy", yaxisHeight+145)
					.style("display", function(condFlag) {
						condFlag =d3.select("#dashboardHolder").attr("class");
						condFlag = condFlag.split(" ")[0];
						return condFlag == "controldashboard" ? "block" : "none";
					})
					.text("Control Group Legend :")
					.attr("font-size","14px")
					.attr("font-family", "MetaOffcPro-Medi");
					var elem1 = svg.selectAll("g controlText")
					.data(dataset1.controldashboard1)
					var ele1 = elem1.enter()
					.append("g")
					.attr("transform", function(d){return "translate("+(d.x)+","+(yaxisHeight+145)+")";})
					ele1.append("text").data(dataset1.controldashboard1)
					.style("display", function(condFlag) {
						condFlag =d3.select("#dashboardHolder").attr("class");
						condFlag = condFlag.split(" ")[0];
						return condFlag == "controldashboard" ? "block" : "none";
					})
					.text(function(d){
						return (d.name);
					})
					.attr("fill",function(d){return d.colorcode})
					.attr("font-size","12px")
					.attr("font-family", "MetaOffcPro-Norm");

					var HorizontalLine= svg.append("line")          
					.style("stroke", "black")  
					.attr("x1", totalSvgWidth/4)     
					.attr("y1", yaxisHeight+75)      
					.attr("x2", totalSvgWidth/2-20)     
					.attr("y2", yaxisHeight+75)
					svg.append("text")
					.attr("dx", totalSvgWidth/2-15)
					.attr("dy", yaxisHeight+77)
					.text("Processes")
					.attr("font-family", "MetaOffcPro-Norm")
					.attr("font-size", "12px");
					svg.append("line")          
					.style("stroke", "black")  
					.attr("x1", totalSvgWidth/2+40)     
					.attr("y1", yaxisHeight+75)      
					.attr("x2", totalSvgWidth-totalSvgWidth/4)     
					.attr("y2", yaxisHeight+75)

					if(condFlag == "controldashboard"){
						 var verticalLine =  svg.append("line")          
												.style("stroke", "black")  
												.attr("x1", -yaxisWidth-40)     
												.attr("y1", yaxisHeight/4)      
												.attr("x2", -yaxisWidth-40)     
												.attr("y2", yaxisHeight/2-20)

												svg.append("text")
												.attr("dx", -yaxisWidth-60)
												.attr("dy", yaxisHeight/2-10)
												.text("Control")
												.attr("font-family", "MetaOffcPro-Norm")
												.attr("font-size", "12px");
												svg.append("text")
												.attr("dx", -yaxisWidth-60)
												.attr("dy", yaxisHeight/2+3)
												.text("Group")
												.attr("font-family", "MetaOffcPro-Norm")
												.attr("font-size", "12px");
												svg.append("text")
												.attr("dx", -yaxisWidth-60)
												.attr("dy", yaxisHeight/2+15)
												.text("Owner")
												.attr("font-family", "MetaOffcPro-Norm")
												.attr("font-size", "12px");
												svg.append("line")          
												.style("stroke", "black")  
												.attr("x1",-yaxisWidth-40)     
												.attr("y1", yaxisHeight/2+20)      
												.attr("x2", -yaxisWidth-40)     
												.attr("y2", yaxisHeight-yaxisHeight/4);

					}else{
						var verticalLine =  svg.append("line")          
												.style("stroke", "black")  
												.attr("x1", -yaxisWidth-40)     
												.attr("y1", yaxisHeight/4)      
												.attr("x2", -yaxisWidth-40)     
												.attr("y2", yaxisHeight/2-20)
												svg.append("text")
												.attr("dx", -yaxisWidth-60)
												.attr("dy", yaxisHeight/2-10)
												.text("Models")
												.attr("font-family", "MetaOffcPro-Norm")
												.attr("font-size", "12px");
												svg.append("line")          
												.style("stroke", "black")  
												.attr("x1",-yaxisWidth-40)     
												.attr("y1", yaxisHeight/2-7)      
												.attr("x2", -yaxisWidth-40)     
												.attr("y2", yaxisHeight-yaxisHeight/4);
					}

					
					svg.append("defs")
					.append("pattern")
					.attr("id", "controlpending")
					.attr('patternUnits','userSpaceOnUse')
					.attr("width",20)
					.attr("height",21)
					.append("image")
					.attr("xlink:href", "assets/images/pending_CntlDb.png")
					.attr('x',0)
					.attr('y',0)
					.attr("width",18)
					.attr("height",19);
					svg.append("defs").append("marker")
					.attr("id", "arrowhead")
					.attr("markerUnits","strokeWidth")
					.attr("refX", 3)
					.attr("refY", 8)
					.attr("markerWidth", 20)
					.attr("markerHeight", 20)
					.attr("orient","auto")
					.append("path")
					.attr("d", "M2,2 L2,14 L14,8 L2,2").attr("style","fill: #57798c;")
					svg.append("defs")
					.append("pattern")
					.attr("id", "pending")
					.attr('patternUnits','userSpaceOnUse')
					.attr("width",40)
					.attr("height",40)
					.append("image")
					.attr("xlink:href", "assets/images/pending__CntlDb-white.png")
					.attr('x',10)
					.attr('y',10)
					.attr("width",20)
					.attr("height",21);
					svg.select(".xaxis").select("path").attr("d","M0,0V0H"+(actualSvgWidth+spacing)+"V0").attr('transform','translate('+-spacing+',0)').attr('stroke',"black")
					d3.select('.capturePdfChartSection').style('display','none');

					function wrap(text, width,axis) {
                 			text.each(function() {
                 				var text = d3.select(this),
                 				words = text.text().split(/\s+/).reverse(),
                 				splitStringArray = [],
                 				word,
                 				line = [],
                 				lineNumber = 0,
						        lineHeight = 1.1, // ems
						        y = text.attr("y"),
						        dy = parseFloat(text.attr("dy")),
						        tspan = text.text(null).append("tspan").attr("x", 0).attr("y", y).attr("dy", dy + "em");
						      
						        if(axis==="xaxis"){
							        for(var i=0;i< words.length;i++){
							        	if(words[i].length > 10 ){
							        		var sb = words[i].substr(9);
							        		var sb2 = words[i].substr(0,9);
						        	 		words.splice(i,1,sb,sb2);
						        	 	
						        	 	}
						        	}
					        	}
					        	while (word = words.pop()) {
					        		line.push(word);
					        		tspan.text(line.join(" "));
					        		if (tspan.node().getComputedTextLength() > width) {
					        			line.pop();
					        			tspan.text(line.join(" "));
					        			line = [word];
					        			tspan = text.append("tspan").attr("x", 0).attr("y", y).attr("dy", ++lineNumber * lineHeight + dy + "em").text(word);
					        		}
					        	}
					        });
                 		}
				}      
			function renderToCanvas(){
				var NumOfsvgs = $('.capturePdfChartSection').find('#chartPdf .chartHolder').length;
					    $('.imageContainer').empty();
					for(var i=0;i < NumOfsvgs;i++){                       
						  var chartContainer = $('.capturePdfChartSection').find('#chartPdf .chartHolder')[i];
                            chartContainer = $(chartContainer).html().trim();
                        var c = document.createElement('canvas');
                            $(c).attr('id',i)
                            canvg(c,chartContainer,{renderCallback:(function(c){
                            	return function(){
                            		var destinationCanvas = document.createElement("canvas");
										destinationCanvas.width = c.width;
										destinationCanvas.height = c.height;

										var destCtx = destinationCanvas.getContext('2d');

										//create a rectangle with the desired color
										destCtx.fillStyle = "#FFFFFF";
										destCtx.fillRect(0,0,c.width,c.height);

										//draw the original canvas onto the destination canvas
										destCtx.drawImage(c, 0, 0);
										var canvasID = $(c).attr('id');
                            		    var img = destinationCanvas.toDataURL("image/jpeg");
                            		   $('.imageContainer').append('<img id="'+canvasID+'" src='+img+'>')
                            		   destinationCanvas.remove()
                            	}
                            })(c)
                        });
                    }

			}
		}

	}

    }])
    .directive("stackedChartaspng",['$window','pncsession','PNC_SESSION_CONFIG',function($window,pncsession,PNC_SESSION_CONFIG){
	return{
		restrict:"A",
		scope:{
			chartoptions:'='
		},
		link:function(scope,element,attrs){
			var d3 = $window.d3;
			var unwatchChartPng = scope.$watch('chartoptions.ObjData',function(newValue,oldValue){
				if(newValue !== oldValue){
					d3.select('.captureChartSection .stackedChartWrapper').select('svg').selectAll("*").remove();
					if(Object.keys(scope.chartoptions.ObjData).length !== 0){
							renderChart(scope.chartoptions.ObjData);
				    }
					
				}
			})
			
			scope.$on('$destroy',function(){
				unwatchChartPng();
			})

			function renderChart(data){
				var width,actualSvgWidth,yaxisHeight,maxYvalue,maxXvalue,
				bufferWidth = 50,
				spacing = scope.chartoptions.spacing,
				gridSize= scope.chartoptions.gridsize;
                d3.select('.captureChartSection').style('display','block');
				var svg = d3.select('.captureChartSection .stackedChartWrapper').select('svg').append("g").attr('transform','translate(300,50)'),
				yaxisSvg = d3.select('.yAxisSection').select('svg')
				svg.attr("version", "1.1");
				svg.attr("xmlns", "http://www.w3.org/2000/svg");
				svg.attr("xmlns:xlink", "http://www.w3.org/1999/xlink");
				var layersArr = [],
				maxXvalue = Math.max.apply(Math,data['3'].map(function(o){return o.x;}));
				maxYvalue = Math.max.apply(Math,data['3'].map(function(o){return o.y;}));
				for(var i=0;i<= maxXvalue;i++){
					var layers = [];
					layers = data['3'].filter(function(d) {
						if(d.x == i){
							return d;
						}

					});
					layersArr.push(layers)

				}

				actualSvgWidth = ((gridSize+spacing) *(maxXvalue+1));
				var actualSvgHeight = ((gridSize * (maxYvalue+1)) + 100);

				var y = d3.scale.ordinal().rangeRoundBands([0,actualSvgHeight]);

				var yAxis = d3.svg.axis().scale(y).orient("left").ticks(5).tickSize(0);

				y.domain(data['2'].map(function(d){
					return d[Object.keys(d)]
				}))

				function make_y_axis(){
					return 	d3.svg.axis().scale(y).orient("left").ticks(5);
				}   
				svg.append("g").attr("class","axis yaxis")
				.attr("transform","translate(0,0)").call(yAxis).selectAll('.tick').each(function(d,i){
					var tick = d3.select(this);
					wrap(tick.select('text'),(y.rangeBand()*2)+20,'yaxis');
					tick.attr("transform","translate(-4,"+(((i)*gridSize)+(gridSize/2))+")")
					tick.select('text').attr('font-size',12+'px')
				})

				var yaxisWidth = Math.round(d3.select('.yaxis').node().getBBox().width);
				var totalSvgWidth = actualSvgWidth + yaxisWidth;
				width =  actualSvgWidth + bufferWidth;

				d3.select('.captureChartSection .stackedChartWrapper').select('svg').attr('width',totalSvgWidth + 750).attr('height',actualSvgHeight+150);
				d3.select('.captureChartSection .StackedChartSection').select('.processGroup').style("width",actualSvgWidth + 'px');

				var x = d3.scale.ordinal().rangeRoundBands([0,actualSvgWidth]);
				var xAxis = d3.svg.axis().scale(x).orient("bottom").tickSize(0);
				x.domain(data['1'].map(function(d){
					return d.PROCESS_NAME;
				}))
				var layer = svg.append('g').attr('transform','translate(10,0)').selectAll(".layer")
				.data(layersArr).enter().append("g").attr("transform",function(d,i){
					return "translate("+(i)*spacing+",0)";
				});

				layer.selectAll('rect').data(function(d){
					return d;
				})
				.enter().append("rect")
				.attr("x",function(d){
					return (d.x)* gridSize;
				})
				.attr("y",function(d){
					return (d.y)*gridSize;
				})
				.attr('fill',function(d){return d.color})
				.attr("width",gridSize)
				.attr("height",gridSize)
				

				layer.selectAll('.rect1').data(function(d){
					return d;
				})
				.enter().append("rect")
				.attr("x",function(d){
					return (d.x)* gridSize;
				})
				.attr("y",function(d){
					return (d.y)*gridSize;
				})
				.attr("width",40)
				.attr("height",40)
				.attr('fill',function(d){
					var userID = pncsession.get(PNC_SESSION_CONFIG.LOGGEDIN_USER_INFO).user_Details.userCd;
					if (d.processStatus === "Not Started" && userID === d.approverID) {
						return 'url(#pending)'
					}
					else if (d.processStatus === "Executed" && userID === d.approverID) {
						return 'url(#pending)'
					}
					else if (d.processStatus === "Rejected" && userID === d.approverID) {
						return 'url(#pending)'
					}
					else {
						return d.color;
					}
				})

				svg.append('g').attr("class","axis xaxis")
				.attr("transform","translate(20,"+(actualSvgHeight-100)+")").call(xAxis)
				.selectAll('.tick').each(function(d,i){
					var tick = d3.select(this);
					if(tick.select('text').text()=== data['1'][i].PROCESS_NAME){
						if(data['1'][i].COLOR){
							tick.style("fill",data['1'][i].COLOR);
						}
						else{
							tick.style("fill","#2c94ff");
						}
					}
					wrap(tick.select('text'),x.rangeBand()-10,'xaxis');
					tick.attr("transform","translate("+((i*(gridSize+spacing))+10)+",0)")
					tick.select('text').attr('font-size',12+'px')
				});
				
				
				svg.append("g")            
				.attr("class", "grid")
				.call(make_y_axis()
					.tickSize(-totalSvgWidth, 0, 0)
					.tickFormat("")
					).selectAll('.tick').each(function(d,i){
						var tick = d3.select(this);
						yaxisHeight = (i+1)*gridSize;
						tick.attr("transform","translate("+(-yaxisWidth)+","+(i+1)*gridSize+")")
						tick.select('line').attr("y2",2).attr("stroke","black");
						if(y.domain().length - 1 === i){
							tick.attr("style","opacity:0");
						}
					})

					svg.select('.yaxis').select('path').attr("d","M0,0V0H0V"+(yaxisHeight+(gridSize/2))).attr("transform","rotate(-180) translate(0,"+-yaxisHeight+")").attr('stroke',"black")
					d3.select('.StackedChartSection').select('.controlOwnerGroup').style("height",yaxisHeight + 'px');
					svg.append("text")
					.attr("font-size","14px")
					.attr("font-family", "MetaOffcPro-Medi")
					.attr("dx", 0)
					.attr("dy", yaxisHeight+113)
					.text("Status Legend :");
					var color = d3.scale.category20();
					var dataset =[{"x":95, "r":6, "name":"Not Applicable","type":"controldashboard","colorcode":"#586671"}, 
					{"x":200, "r":6, "name":"Not Started","type":"controldashboard","colorcode":"#2c94ff"},
					{"x":300, "r":6, "name":"Executed","type":"controldashboard","colorcode":"#fd9b00"}, 
					{"x":380, "r":6, "name":"Reviewed","type":"controldashboard","colorcode":"#23a565"},
					{"x":455, "r":6, "name":"Rejected","type":"controldashboard","colorcode":"#bf0101"},
					{"x":95, "r":6, "name":"Not Applicable","type":"enterprisedashboard","colorcode":"#586671"}, 
					{"x":200, "r":6, "name":"Not Started","type":"enterprisedashboard","colorcode":"#2c94ff"},
					{"x":300, "r":6, "name":"Executed","type":"enterprisedashboard","colorcode":"#fd9b00"}, 
					{"x":380, "r":6, "name":"Reviewed","type":"enterprisedashboard","colorcode":"#23a565"},
					{"x":455, "r":6, "name":"Rejected","type":"enterprisedashboard","colorcode":"#bf0101"},
					{"x":90, "r":6, "name":"Not Applicable","type":"statusdashboard","colorcode":"#586671"}, 
					{"x":200, "r":6, "name":"Not Started","type":"statusdashboard","colorcode":"#2c94ff"},
					{"x":300, "r":6, "name":"Executed","type":"statusdashboard","colorcode":"#fd9b00"}, 
					{"x":380, "r":6, "name":"Reviewed","type":"statusdashboard","colorcode":"#23a565"}]
					var dataset1 ={"controldashboard1":[
					{"x":150,"name":"Input","colorcode":"#25A1EF"}, 
					{"x":180, "name":"Execution","colorcode":"#C14141"},
					{"x":235, "name":"Output","colorcode":"#05A505"}, 
					{"x":280, "name":"Reporting","colorcode":"#FFA500"}
					]};
					var condFlag=d3.select("#dashboardHolder").attr("class");
					condFlag = condFlag.split(" ")[0];
					var title;
					if(condFlag == "controldashboard"){
						title="Control Dashboard"
					}
					if(condFlag == "enterprisedashboard"){
						title="Enterprise Dashboard"
					}
					if(condFlag == "statusdashboard"){
						title="Status Dashboard"
					}
					var filtered = dataset.filter(function(d) {
						return d.type == condFlag; 
					});
					var forecast = d3.select(".forecast #dropdown").text();
					svg.append("text")
					.attr("dx", actualSvgWidth/2)
					.attr("dy",-25)
					.text(title+" ("+forecast+")")
					.attr("fill","#fd7607");

					var elem = svg.selectAll("g myCircleText")
					.data(filtered)
					var ele = elem.enter()
					.append("g")
					.attr("transform", function(d){return "translate("+(d.x+d.name.length)+","+(yaxisHeight+110)+")";})

					/* var ele = svg.append('g').attr('transform',"translate(30,"+(yaxisHeight+80)+")")*/
					var circle = ele.append("circle")
					.attr("r", function(d){return d.r} )
					.attr("stroke","black")
					.style("fill",function(d){return d.colorcode});
					ele.append("text")
					.attr("dx", 12)
					.attr("dy", 5)
					.text(function(d){
						return (d.name);
					})
					.attr("font-size","12px")
					.attr("font-family", "MetaOffcPro-Norm");
					svg.append("circle")
					.attr("r", 11)
					.attr("cx", 549)
					.attr("cy",yaxisHeight+105)
					.style("fill","url(#controlpending)")
					.style("display", function(condFlag) {
						condFlag =d3.select("#dashboardHolder").attr("class");
						condFlag = condFlag.split(" ")[0];
						return condFlag == "controldashboard" ? "block" : "none";
					});
					svg.append("text")
					.attr("dx", 562)
					.attr("dy",yaxisHeight+115)
					.style("display", function(condFlag) {
						condFlag =d3.select("#dashboardHolder").attr("class");
						condFlag = condFlag.split(" ")[0];
						return condFlag == "controldashboard" ? "block" : "none";
					})
					.text("Pending")
					.attr("font-size","12px")
					.attr("font-family", "MetaOffcPro-Norm");;
					svg.append("text")
					.attr("class","onlyControlDashboard")
					.attr("dx", 0)
					.attr("dy", yaxisHeight+145)
					.style("display", function(condFlag) {
						condFlag =d3.select("#dashboardHolder").attr("class");
						condFlag = condFlag.split(" ")[0];
						return condFlag == "controldashboard" ? "block" : "none";
					})
					.text("Control Group Legend :")
					.attr("font-size","14px")
					.attr("font-family", "MetaOffcPro-Medi");
					var elem1 = svg.selectAll("g controlText")
					.data(dataset1.controldashboard1)
					var ele1 = elem1.enter()
					.append("g")
					.attr("transform", function(d){return "translate("+(d.x)+","+(yaxisHeight+145)+")";})
					ele1.append("text").data(dataset1.controldashboard1)
					.style("display", function(condFlag) {
						condFlag =d3.select("#dashboardHolder").attr("class");
						condFlag = condFlag.split(" ")[0];
						return condFlag == "controldashboard" ? "block" : "none";
					})
					.text(function(d){
						return (d.name);
					})
					.attr("fill",function(d){return d.colorcode})
					.attr("font-size","12px")
					.attr("font-family", "MetaOffcPro-Norm");

					var HorizontalLine= svg.append("line")          
					.style("stroke", "black")  
					.attr("x1", totalSvgWidth/4)     
					.attr("y1", yaxisHeight+75)      
					.attr("x2", totalSvgWidth/2-20)     
					.attr("y2", yaxisHeight+75)
					svg.append("text")
					.attr("dx", totalSvgWidth/2-15)
					.attr("dy", yaxisHeight+77)
					.text("Processes")
					.attr("font-family", "MetaOffcPro-Norm")
					.attr("font-size", "12px");
					svg.append("line")          
					.style("stroke", "black")  
					.attr("x1", totalSvgWidth/2+40)     
					.attr("y1", yaxisHeight+75)      
					.attr("x2", totalSvgWidth-totalSvgWidth/4)     
					.attr("y2", yaxisHeight+75)

					if(condFlag == "controldashboard"){
						 var verticalLine =  svg.append("line")          
												.style("stroke", "black")  
												.attr("x1", -yaxisWidth-40)     
												.attr("y1", yaxisHeight/4)      
												.attr("x2", -yaxisWidth-40)     
												.attr("y2", yaxisHeight/2-20)

												svg.append("text")
												.attr("dx", -yaxisWidth-60)
												.attr("dy", yaxisHeight/2-10)
												.text("Control")
												.attr("font-family", "MetaOffcPro-Norm")
												.attr("font-size", "12px");
												svg.append("text")
												.attr("dx", -yaxisWidth-60)
												.attr("dy", yaxisHeight/2+3)
												.text("Group")
												.attr("font-family", "MetaOffcPro-Norm")
												.attr("font-size", "12px");
												svg.append("text")
												.attr("dx", -yaxisWidth-60)
												.attr("dy", yaxisHeight/2+15)
												.text("Owner")
												.attr("font-family", "MetaOffcPro-Norm")
												.attr("font-size", "12px");
												svg.append("line")          
												.style("stroke", "black")  
												.attr("x1",-yaxisWidth-40)     
												.attr("y1", yaxisHeight/2+20)      
												.attr("x2", -yaxisWidth-40)     
												.attr("y2", yaxisHeight-yaxisHeight/4);

					}else{
						var verticalLine =  svg.append("line")          
												.style("stroke", "black")  
												.attr("x1", -yaxisWidth-40)     
												.attr("y1", yaxisHeight/4)      
												.attr("x2", -yaxisWidth-40)     
												.attr("y2", yaxisHeight/2-20)
												svg.append("text")
												.attr("dx", -yaxisWidth-60)
												.attr("dy", yaxisHeight/2-10)
												.text("Models")
												.attr("font-family", "MetaOffcPro-Norm")
												.attr("font-size", "12px");
												svg.append("line")          
												.style("stroke", "black")  
												.attr("x1",-yaxisWidth-40)     
												.attr("y1", yaxisHeight/2-7)      
												.attr("x2", -yaxisWidth-40)     
												.attr("y2", yaxisHeight-yaxisHeight/4);
					}
					svg.append("defs")
					.append("pattern")
					.attr("id", "controlpending")
					.attr('patternUnits','userSpaceOnUse')
					.attr("width",20)
					.attr("height",21)
					.append("image")
					.attr("xlink:href", "assets/images/pending_CntlDb.png")
					.attr('x',0)
					.attr('y',0)
					.attr("width",18)
					.attr("height",19);
					svg.append("defs").append("marker")
					.attr("id", "arrowhead")
					.attr("markerUnits","strokeWidth")
					.attr("refX", 3)
					.attr("refY", 8)
					.attr("markerWidth", 20)
					.attr("markerHeight", 20)
					.attr("orient","auto")
					.append("path")
					.attr("d", "M2,2 L2,14 L14,8 L2,2").attr("style","fill: #57798c;")
					svg.append("defs")
					.append("pattern")
					.attr("id", "pending")
					.attr('patternUnits','userSpaceOnUse')
					.attr("width",40)
					.attr("height",40)
					.append("image")
					.attr("xlink:href", "assets/images/pending__CntlDb-white.png")
					.attr('x',10)
					.attr('y',10)
					.attr("width",20)
					.attr("height",21);
					svg.select(".xaxis").select("path").attr("d","M0,0V0H"+(actualSvgWidth+spacing)+"V0").attr('transform','translate('+-spacing+',0)').attr('stroke',"black")
					d3.select('.captureChartSection').style('display','none');

					function wrap(text, width,axis) {
                 			text.each(function() {
                 				var text = d3.select(this),
                 				words = text.text().split(/\s+/).reverse(),
                 				splitStringArray = [],
                 				word,
                 				line = [],
                 				lineNumber = 0,
						        lineHeight = 1.1, // ems
						        y = text.attr("y"),
						        dy = parseFloat(text.attr("dy")),
						        tspan = text.text(null).append("tspan").attr("x", 0).attr("y", y).attr("dy", dy + "em");
						      
						        if(axis==="xaxis"){
							        for(var i=0;i< words.length;i++){
							        	if(words[i].length > 10 ){
							        		var sb = words[i].substr(9);
							        		var sb2 = words[i].substr(0,9);
						        	 		words.splice(i,1,sb,sb2);
						        	 	
						        	 	}
						        	}
					        	}
					        	while (word = words.pop()) {
					        		line.push(word);
					        		tspan.text(line.join(" "));
					        		if (tspan.node().getComputedTextLength() > width) {
					        			line.pop();
					        			tspan.text(line.join(" "));
					        			line = [word];
					        			tspan = text.append("tspan").attr("x", 0).attr("y", y).attr("dy", ++lineNumber * lineHeight + dy + "em").text(word);
					        		}
					        	}
					        });
                 		}
				}       
			}
		}

	}])


})()