'use strict';
(function(){
  angular.module('PNCAppDirectives',[])
    .directive('treeView',function(){
		return{
			restrict:'E',
			templateUrl:'views/treeView.html',
			require:'^?uiTreeNodes'
		}
	})
})()
