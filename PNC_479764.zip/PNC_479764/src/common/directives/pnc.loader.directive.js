'use strict';
(function(){
  angular.module('PNCAppDirectives')
   .directive('loader',['$rootScope',function($rootScope){
		return{
			restrict:'E',
			link:function(scope,element,attrs){
				var loaderShow = scope.$on('loader_show',function(){
                      element.show();
				})
				var loaderHide = scope.$on('loader_hide',function(){
                      element.hide();
				})
				scope.$on('$destroy',function(){
					loaderShow();
					loaderHide();
				})
			},
			template:'<div class="chartOverLay"><div class="loadingImg">Please Wait...</div></div>'
		}
	}])
    .directive('modalLoader',['$rootScope',function($rootScope){
		return{
			restrict:'E',
			link:function(scope,element,attrs){
				var unbindModalLoaderShow = scope.$on('modal_loader_show',function(){
                      element.show();
				})
				var unbindModalLoaderHide = scope.$on('modal_loader_hide',function(){
                      element.hide();
				})
				scope.$on('destroy',function(){
					unbindModalLoaderShow();
					unbindModalLoaderHide();
				})
			},
			template:'<div class="ModalOverLay"><div class="loadingImg">Please Wait...</div></div>'
		}
	}])

})()