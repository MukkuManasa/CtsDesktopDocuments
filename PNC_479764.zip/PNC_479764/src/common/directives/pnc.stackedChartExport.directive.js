'use strict';
(function(){
   angular.module('PNCAppDirectives')
   .directive("captureChart",function(){
		return{
			restrict:'A',
			link:function(scope,element,attrs){
				element.on('click',function(){
					if(!element.parent().hasClass('tableDisabled')){
						var dashboardHolder = element.closest('#dashboardHolder').attr('class');
						dashboardHolder = dashboardHolder.split(" ")[0];
						createPng(element.attr('class'),dashboardHolder);
				     }	
				})
				function createPng(className,dashboardHolder){
					var chartContainer = $('.captureChartSection').find('#chartPrint').html().trim(),
					canvas= $('#canvas')[0],
					className = className,
					dashboardHolder = dashboardHolder;
					

					function savePng(){
						   //create a dummy CANVAS

							var destinationCanvas = document.createElement("canvas");
							destinationCanvas.width = canvas.width;
							destinationCanvas.height = canvas.height;

							var destCtx = destinationCanvas.getContext('2d');

							//create a rectangle with the desired color
							destCtx.fillStyle = "#FFFFFF";
							destCtx.fillRect(0,0,canvas.width,canvas.height);

							//draw the original canvas onto the destination canvas
							destCtx.drawImage(canvas, 0, 0);

						var jpg =  destinationCanvas.toDataURL("image/jpeg");
						        if(className === 'imgChart'){
	                       	        if (canvas.msToBlob) { //for IE
	                       	        	var blob = destinationCanvas.msToBlob();
	                       	        	window.navigator.msSaveBlob(blob, dashboardHolder+'.jpg');
	                       	        }else{
	                       	        	$('body').append('<a id="export-image-container"></a>') 
	                       	        	$('#export-image-container').attr('href', jpg);
	                       	        	$('#export-image-container').attr('download',dashboardHolder+'.jpg')
	                       	        	$('#export-image-container')[0].click()
	                       	        	$('#export-image-container').remove();  
	                       	        }
	                       	    }else if(className === 'pdfChart'){
	                       	    	var doc = new jsPDF('l','pt','a2');
	                       	    	
	                       	    	doc.addImage(jpg,'jpeg',0,0);
	                       	    	doc.save(dashboardHolder+'.pdf');
	                       	    	$(destinationCanvas).remove()
	                       	    }else if(className === 'printChart'){

				                       var newWin = window.open();
				                       newWin.document.write('<img width=1200 transform="rotate(90deg)" id="printPng" src="'+jpg+'"/>');
				                        newWin.document.close();
										newWin.focus();
										newWin.print();
										newWin.close();
														                       
				                       //$('#printPng').remove()
				                   } 

				               }
				               canvg(canvas,chartContainer,{renderCallback:savePng});
				           }

				       } 
				   }
})
.directive("pdfChart",function(){
		return{
			restrict:'A',
			link:function(scope,element,attrs){
				element.on('click',function(){
					if(!element.parent().hasClass('tableDisabled')){
						var dashboardHolder = element.closest('#dashboardHolder').attr('class');
						dashboardHolder = dashboardHolder.split(" ")[0];
						createPdf(element.attr('class'),dashboardHolder);
				     }	
				})
				function createPdf(className,dashboardHolder){
					var NumOfcanvases = $('.imageContainer').find('img'),
					    doc = new jsPDF('p','pt','a4'),
					    count = 0;
					    NumOfcanvases.sort(function(a,b){
					    	return $(a).attr('id') - $(b).attr('id')
					    })
					    $('.imageContainer').empty();
					    for(var i=0;i<NumOfcanvases.length;i++){
					    	count++;
					    	var img = $(NumOfcanvases[i])[0];
					    	$('.imageContainer').append(img);
					    	doc.addImage(img,'jpeg',0,0);
					    	doc.addPage();
					    	if(count === NumOfcanvases.length){
					    		if(className === 'pdfChart'){
                            		doc.save(dashboardHolder+'.pdf');
                            	}else if(className === 'printChart'){
	                                var newWin = window.open("", "w");
									var html = $('.imageContainer').html();
									newWin.document.write(html);
			                        newWin.document.close();
									newWin.focus();
									newWin.print();
									newWin.close();
                            	}
					    	}
					    }
                            		
                }
                           

			} 	               
			}

})

})();
