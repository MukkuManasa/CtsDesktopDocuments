'use strict';
(function(){
  angular.module('PNCAppDirectives')
    .directive('errorHolder',function(){
		return{
			restrict:'E',
			link:function(scope,element,attrs){
				var unbindErrorShow = scope.$on('error_show',function(event,args){
					  element.find('.alertMsg').html(args.message);
                      element.find('.alert').removeClass('hideSection');
				})
				var unbindErrorHide = scope.$on('error_hide',function(event){
                      element.find('.alert').addClass('hideSection');
				})
                element.find('.close').on('click',function() {
                	element.find('.alert').addClass('hideSection')
                })
                scope.$on('$destroy',function(){
                	unbindErrorShow();
                	unbindErrorHide();
                })
			},
			templateUrl:'views/alerts.html'
		}
	})
	.directive('runplanerror',function(){
		return{
			restrict:'E',
			link:function(scope,element,attrs){
				var unbindErrorRunplanShow = scope.$on('runPlanError_show',function(event,args){
					  element.find('.runPlanErrMsg').html(args.message);
                      element.find('.errHolder').removeClass('hideSection');
				})
				var unbindErrorRunplanHide = scope.$on('runPlanError_hide',function(event){
                      element.find('.errHolder').addClass('hideSection');
				})
				scope.$on('$destroy',function(){
                	unbindErrorRunplanShow();
                	unbindErrorRunplanShow();
                })
			},
			template:'<div class="errHolder hideSection"><span class="runPlanErrMsg"></span></div>'
		}
	})
})()