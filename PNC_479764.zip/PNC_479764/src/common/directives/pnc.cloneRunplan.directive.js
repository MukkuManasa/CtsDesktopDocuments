'use strict';
(function(){
  angular.module('PNCAppDirectives')
    .directive('cloneRunplan',['$rootScope','pncServices','pncsession','PNC_SESSION_CONFIG','$uibModal',
    	                       function($rootScope,pncServices,pncsession,PNC_SESSION_CONFIG,$uibModal){
		return{
			restrict:'A',
			link:function(scope,element,attrs){
				element.on('click',function(){

					if(element.hasClass('orangeButton')){
						    if(element.hasClass('cloneRunplan')){
								var pojo = $('.runPlanTable').find('tbody tr.rowActive').attr('pojo');
								var mode = "CLONE";
							}else if(element.hasClass('addRunPlan')){
								var pojo = "";
								var mode = "ADD"
							}
							var userID = pncsession.get(PNC_SESSION_CONFIG.LOGGEDIN_USER_INFO).user_Details.userCd;
							var foreCastPurpose =  pncsession.get(PNC_SESSION_CONFIG.SELECTED_RUNPLANFORECAST);
							pncServices.getModelNameDropDown(userID,foreCastPurpose).then(function(res){
								$rootScope.$broadcast('error_hide');
								var selectObj = pncsession.get(PNC_SESSION_CONFIG.GET_RUNPLANSELECTDATA);
								var data = {
							    			pojo: pojo,
							    		    selectObj : selectObj,
						    			    modelObj:res,
						    			    forecastPurpose : foreCastPurpose,
							    			mode:mode
							    	};
							    var modalInstance = $uibModal.open({
				                 			templateUrl:"modules/secure/tools/views/editRunPlanPopup.html",
				                 			controller:'editRunPlanPopupCtrl',
				                 			resolve: {
				                 				data: function () {
				                 					return data;
				                 				}
				                 			},
				                 			backdrop : 'static' 
				                });
				            },function(err){
			                 		console.log(err);
			                 		$rootScope.$broadcast('error_show',err.data);
			                })

				    }
							
				})
			}
		}
	}])
})()