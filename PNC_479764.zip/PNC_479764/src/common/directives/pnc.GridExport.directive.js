'use strict';
(function(){
  angular.module('PNCAppDirectives')
  	.directive('printGrid',function(){
		return{
			restrict:'A',
			link:function(scope,element,attrs){
				element.on('click',function(){
					angular.element('.printButton').triggerHandler('click')
				})

			}
		}
	})
	.directive('exportGridtoexcel',['$rootScope','pncServices','pncsession','PNC_SESSION_CONFIG','$window',function($rootScope,pncServices,pncsession,PNC_SESSION_CONFIG,$window){
		return{
			restrict:'A',
			scope:{
				fileUrl:'=fileurl',
				fileName:'=filename',
				exportobj:"="

			},
			link:function(scope,element,attrs){
				element.on('click',function(){
					var exportData = angular.extend({},scope.exportobj);
					if(!element.parent().hasClass('tableDisabled')){
						var grid = element.parents('.sectionHolder').find('table');
						var subState = element.parents('.sectionHolder').find('.runPlan').attr('abbr');
						if($(grid).find('th.filterApplied').length>0 || subState === 'MR'){
							 var dataTableInstance = grid.dataTable();
							 var visibleData = {
								 isFilter : true,
								 filterData : dataTableInstance.api().columns('.'+exportData.columnClass,{search:'applied'}).data()[0]
								}
							 angular.extend(exportData,visibleData);
						}

						pncServices.exportToExcel(exportData,scope.fileUrl)
									.then(function(data){
										$rootScope.$broadcast('error_hide');
										var ua = window.navigator.userAgent;
	                                    var msie = ua.indexOf("MSIE ");
	                                    var blob = new Blob([data], {type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"});
	                                    if(msie !== -1 || !!navigator.userAgent.match(/Trident.*rv\:11\./)){
	                                    	window.navigator.msSaveBlob(blob, scope.fileName);
	                                    }else{
	                                    	var objectUrl = $window.URL.createObjectURL(blob);
								            
									        $('body').append('<a id="download"></a>'); 
											      $('#download').attr('href', objectUrl);
											      $('#download').attr('download', scope.fileName);
											      $('#download')[0].click();
											      $('#download').remove();

									        

	                                    }   
									 },function(err){
									 	$rootScope.$broadcast('error_show',err.data);
									 });
                    } 

				})
                  
			}
		}

	}])
    .directive("exportGridtopdf",['$rootScope','pncServices','pncsession','PNC_SESSION_CONFIG','$window',function($rootScope,pncServices,pncsession,PNC_SESSION_CONFIG,$window){
    	return{
    		restrict:'A',
    		scope:{
				fileUrl:'=fileurl',
				fileName:'=filename',
				exportobj:"="
			},
    		link:function(scope,element,attrs){
    			element.on('click',function(){
    				var exportData = angular.extend({},scope.exportobj);
    				if(!element.parent().hasClass('tableDisabled')){
    					    var grid = element.parents('.sectionHolder').find('table');
						    var subState = element.parents('.sectionHolder').find('.runPlan').attr('abbr');
						        if($(grid).find('th.filterApplied').length>0 || subState === 'MR'){
									 var dataTableInstance = grid.dataTable();
									 var visibleData = {
										 isFilter : true,
										 filterData : dataTableInstance.api().columns('.'+exportData.columnClass,{search:'applied'}).data()[0]
										}
									 angular.extend(exportData,visibleData);
								}
							pncServices.exportToPDF(exportData,scope.fileUrl)
								.then(function(data){
									$rootScope.$broadcast('error_hide');
									var ua = window.navigator.userAgent;
                                    var msie = ua.indexOf("MSIE ");
                                    var blob = new Blob([data], {type: "application/pdf"});
                                    if(msie !== -1 || !!navigator.userAgent.match(/Trident.*rv\:11\./)){
                                    	window.navigator.msSaveBlob(blob, scope.fileName);
                                    }else{
                                    	var objectUrl = $window.URL.createObjectURL(blob);
							            
								        $('body').append('<a id="download"></a>'); 
										      $('#download').attr('href', objectUrl);
										      $('#download').attr('download', scope.fileName);
										      $('#download')[0].click();
										      $('#download').remove();

                                    }
								 },function(err){
								 	$rootScope.$broadcast('error_show',err.data);
								 });
					}

    			})
    		}
    	}
    }])
	.directive("mailGrid",['$rootScope','pncServices','pncsession','PNC_SESSION_CONFIG',function($rootScope,pncServices,pncsession,PNC_SESSION_CONFIG){
		return{
			restrict:"A",
			scope:{
               exportobj:"="
			},
			link:function(scope,element,attrs){
				element.on('click',function(){
					var exportData = angular.extend({},scope.exportobj);
					if(!element.parent().hasClass('tableDisabled')){
						var grid = element.parents('.sectionHolder').find('table');
						if($(grid).find('th.filterApplied').length>0){
							 var dataTableInstance = grid.dataTable();
							 var visibleData = {
									isFilter : true,
									filterData : dataTableInstance.api().columns('.'+exportData.columnClass,{search:'applied'}).data()[0]
								}
							 angular.extend(exportData,visibleData);
						}
						exportData.filterData = exportData.filterData.toString();
						exportData.isFilter = exportData.isFilter.toString();
					    delete exportData.columnClass;
					    var mailInputParams = Object.keys(exportData).map(function(key){
					    	                        if(key === "isFilter"){
					    	                         	 return exportData[key]
					    	                        }
                                                    return exportData[key]||"-"
					                          })
						$rootScope.$broadcast('error_hide');
						var userInfo = pncsession.get(PNC_SESSION_CONFIG.LOGGEDIN_USER_INFO);
				 		var fullName = "";
				 		if(userInfo.user_Details.firstNameTxt){
				 			fullName = userInfo.user_Details.firstNameTxt;
				 		}
				 		if(userInfo.user_Details.middleNameTxt){
				 			fullName += ' ' + userInfo.user_Details.middleNameTxt;
				 		}
				 		if(userInfo.user_Details.lastNameTxt){
							fullName += ' ' + userInfo.user_Details.lastNameTxt;
				 		}

				 		var toAddress = userInfo.user_Details.emailAddrTxt;
				 		var mailBody = [fullName];

				 		pncServices.sendMail(toAddress, mailBody, mailInputParams)
				 			.then(function(data){
				 			    $rootScope.$broadcast('success_show',data)
						 },function(err){
						 	$rootScope.$broadcast('error_show',err.data)
						 });
					}
				})
			}
		}

	}])
})();