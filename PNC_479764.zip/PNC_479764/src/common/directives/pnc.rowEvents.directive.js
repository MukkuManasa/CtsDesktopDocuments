'use strict';
(function(){
  angular.module('PNCAppDirectives')
    .directive('rowEvents',['$compile',function($compile){
		return{
			restrict:'A',
			link:function(scope,element,attrs){
				element.on('click',function(e){
					e.stopPropagation();
					if(!element.hasClass('rowActive')){
						$(element).siblings().removeClass('rowActive')
						$("tbody tr td span.options").remove();
                        $(element).addClass('rowActive');
                        $('.cloneRunplan').addClass('orangeButton')
                        scope.obj = $(element).attr('pojo');
                        $(element).find('td:visible:last').append($compile('<p><span class="options" id="edit" ng-click="editRunPlan($event,obj)"></span><span class="options" id="delete"  ng-click="deleteRunPlan($event,obj);"></span></p>')(scope))

					}else{
                        $(element).removeClass('rowActive');
                        $('.cloneRunplan').removeClass('orangeButton')
                        $("tbody tr td span.options").remove();
					}
				})
			}
		}
	}])
})()