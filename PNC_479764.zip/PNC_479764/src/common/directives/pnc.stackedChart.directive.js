"use strict";
(function(){
	angular.module('PNCAppDirectives')
	.directive("stackedChart",['$window','pncsession','PNC_SESSION_CONFIG',function($window,pncsession,PNC_SESSION_CONFIG){
		return{
			restrict:"A",
			scope:{
				chartoptions:'=',
				open:'='
			},
			link:function(scope,element,attrs){
				var d3 = $window.d3;
				var unWatchChart = scope.$watch('chartoptions.ObjData',function(newValue,oldValue){
					if(newValue !== oldValue){
						d3.select('.yAxisSection').select('svg').selectAll("*").remove();
						d3.select('.stackedChartWrapper').select('svg').selectAll("*").remove();
						if(Object.keys(scope.chartoptions.ObjData).length !== 0){
							renderChart(scope.chartoptions.ObjData);
						}
						
					}
				})
				scope.$on('$destroy',function(){
					unWatchChart();
				})
				function renderChart(data){
					var width,actualSvgWidth,yaxisHeight,maxYvalue,maxXvalue,
					bufferWidth = 50,
					spacing = scope.chartoptions.spacing,
					gridSize= scope.chartoptions.gridsize;

					var svg = d3.select('.stackedChartWrapper').select('svg').append("g").attr('transform','translate(10,50)').attr("xmlns","http://www.w3.org/2000/svg").attr("xmlns:xlink","http://www.w3.org/1999/xlink"),

					yaxisSvg = d3.select('.yAxisSection').select('svg');

					d3.select('.chartTooltip').remove();
                 //tooltip = d3.select('.stackedChartWrapper').append('div').attr("class","chartTooltip").style("opacity",0);
                 
                 var layersArr = [],
                 maxXvalue = Math.max.apply(Math,data['3'].map(function(o){return o.x;}));
                 maxYvalue = Math.max.apply(Math,data['3'].map(function(o){return o.y;}));
                 for(var i=0;i<= maxXvalue;i++){
                 	var layers = [];
                 	layers = data['3'].filter(function(d) {
                 		if(d.x == i){
                 			return d;
                 		}

                 	});
                 	layersArr.push(layers)

                 }

                 actualSvgWidth = ((gridSize+spacing) *(maxXvalue+1));
                 var actualSvgHeight = ((gridSize * (maxYvalue+1)) + 100);
                 width =  actualSvgWidth + bufferWidth;

                 d3.select('.stackedChartWrapper').select('svg').attr('width',width).attr('height',actualSvgHeight);
                 d3.select('.yAxisSection').select('svg').attr('height',actualSvgHeight);
                 d3.select('.controlOwnerGroup').style("height",actualSvgHeight*0.45 + 'px');
                 d3.select('.processGroup').style("width",actualSvgHeight*0.8 + 'px');

                 var x = d3.scale.ordinal().rangeRoundBands([0,actualSvgWidth]);

                 var y = d3.scale.ordinal().rangeRoundBands([0,actualSvgHeight]);

                 var xAxis = d3.svg.axis().scale(x).orient("bottom").tickSize(0);

                 var yAxis = d3.svg.axis().scale(y).orient("left").ticks(5).tickSize(0);

                 function make_y_axis(){
                 	return 	d3.svg.axis().scale(y).orient("left").ticks(5);
                 }   

                 x.domain(data['1'].map(function(d){
                 	return d.PROCESS_NAME;
                 }))
                 y.domain(data['2'].map(function(d){
                 	return d[Object.keys(d)]
                 }))

                 var tip = d3.tip()
                 .attr('class', 'chartTooltip')
                 .offset([0, 0])
                 .html(function(d) {
                 	var tipHtml = "";
                 	tipHtml = '<p>' + d.processName + '</p><p>Status:' + d.processStatus + '</p>';
                 	if(d.processStatus != "Not Applicable"){
                 		tipHtml += '<p>Executor:'+d.reviewerID+'</p><p>Reviewer:'+d.ownerID+'</p>';
                 	}
                 	return tipHtml;
                 })
                 svg.call(tip);

                 var layer = svg.selectAll(".layer")
                 .data(layersArr).enter().append("g").attr("transform",function(d,i){
                 	return "translate("+i*spacing+",0)";
                 });

                 layer.selectAll('rect').data(function(d){
                 	return d;
                 })
                 .enter().append("rect")
                 .attr("x",function(d){
                 	return (d.x)* gridSize;
                 })
                 .attr("y",function(d){
                 	return (d.y)*gridSize;
                 })
                 .attr('fill',function(d){
                 	return d.color;
                 })
                 .attr("width",gridSize)
                 .attr("height",gridSize)
                 .on("click",function(d){
                 	scope.open(d);
                 })
                 .on("mouseover",tip.show)					
                 .on("mouseout", tip.hide);

                 layer.selectAll('.rect1').data(function(d){
                 	return d;
                 })
                 .enter().append("rect")
                 .attr("x",function(d){
                 	return (d.x)* gridSize;
                 })
                 .attr("y",function(d){
                 	return (d.y)*gridSize;
                 })
                 .style('cursor',function(d){if(d.processStatus!="Not Applicable") return 'pointer'})
                 .attr("width",40)
                 .attr("height",40)
                 .attr('fill',function(d){
                 	var userID = pncsession.get(PNC_SESSION_CONFIG.LOGGEDIN_USER_INFO).user_Details.userCd;
                 	if (d.processStatus === "Not Started" && userID === d.approverID) {
                 		return 'url(#pending)'
                 	}
                 	else if (d.processStatus === "Executed" && userID === d.approverID) {
                 		return 'url(#pending)'
                 	}
                 	else if (d.processStatus === "Rejected" && userID === d.approverID) {
                 		return 'url(#pending)'
                 	}
                 	else {
                 		return d.color;
                 	}

                 })
                 .on("click",function(d){
                 	if(d.processStatus!="Not Applicable")
                 	scope.open(d);
                 })
                 .on("mouseover",tip.show)					
                 .on("mouseout", tip.hide);


                 svg.append("g").attr("class","axis xaxis")
                 .attr("transform","translate(0,"+(actualSvgHeight-100)+")").call(xAxis)
                 .selectAll('.tick').each(function(d,i){
                 	var tick = d3.select(this);

                 	if(tick.select('text').text()=== data['1'][i].PROCESS_NAME){
                 		if(data['1'][i].COLOR){
                 			tick.style("fill",data['1'][i].COLOR);
                 		}
                 		else{
                 			tick.style("fill","#2c94ff");
                 		}
                 	}

                 	wrap(tick.select('text'),x.rangeBand()-5,'xaxis');
                 	tick.attr("transform","translate("+((i*(gridSize+spacing))+20)+",0)")
                 });
                 yaxisSvg.append("g").attr("class","axis yaxis")
                 .attr("transform","translate(124,50)").call(yAxis).selectAll('.tick').each(function(d,i){
                 	var tick = d3.select(this);
                 	wrap(tick.select('text'),(y.rangeBand()*2)+20,'yaxis');
                 	tick.attr("transform","translate(-4,"+(((i)*gridSize)+(gridSize/2))+")")
                 })

                 svg.append("g")            
                 .attr("class", "grid")
                 .call(make_y_axis()
                 	.tickSize(-actualSvgWidth, 0, 0)
                 	.tickFormat("")
                 	).selectAll('.tick').each(function(d,i){
                 		var tick = d3.select(this);
                 		yaxisHeight = (i+1)*gridSize;
                 		tick.attr("transform","translate(0,"+(i+1)*gridSize+")")
                 		if(y.domain().length - 1 === i){
                 			tick.attr("style","opacity:0");
                 		}
                 	})
                 	yaxisSvg.append("g").attr("transform",'translate(0,50)')           
                 	.attr("class", "grid")
                 	.call(make_y_axis()
                 		.tickSize(-width, 0, 0)
                 		.tickFormat("")
                 		).selectAll('.tick').each(function(d,i){
                 			var tick = d3.select(this);
                 			yaxisHeight = (i+1)*gridSize;
                 			tick.attr("transform","translate(0,"+(i+1)*gridSize+")")
                 			if(y.domain().length - 1 === i){
                 				tick.attr("style","opacity:0");
                 			}
                 		})
                 		yaxisSvg.select('.yaxis').select('path').attr("marker-end",'url(#arrowhead)').attr("d","M0,0V0H0V"+(yaxisHeight+(gridSize/2))).attr("transform","rotate(-180) translate(0,"+-yaxisHeight+")");
                 		d3.select('.StackedChartSection').select('.controlOwnerGroup').style("height",yaxisHeight + 'px');
                 		svg.append("defs").append("marker")
                 		.attr("id", "arrowhead")
                 		.attr("markerUnits","strokeWidth")
                 		.attr("refX", 3)
                 		.attr("refY", 8)
                 		.attr("markerWidth", 20)
                 		.attr("markerHeight", 20)
                 		.attr("orient","auto")
                 		.append("path")
                 		.attr("d", "M2,2 L2,14 L14,8 L2,2").attr("style","fill: #57798c;")
                 		svg.append("defs")
                 		.append("pattern")
                 		.attr("id", "pending")
                 		.attr('patternUnits','userSpaceOnUse')
                 		.attr("width",40)
                 		.attr("height",40)
                 		.append("image")
                 		.attr("xlink:href", "assets/images/pending__CntlDb-white.png")
                 		.attr('x',10)
                 		.attr('y',10)
                 		.attr("width",20)
                 		.attr("height",21);
                 		d3.select(".xaxis").select("path").attr("d","M0,0V0H"+(actualSvgWidth+spacing)+"V0").attr("marker-end",'url(#arrowhead)').attr('transform','translate('+-spacing+',0)');
                 		$('.xAxisClone svg').empty();
                 		$('.StackedChartSection').find('svg').find('.xaxis').clone().appendTo('.xAxisClone svg')
                 		d3.select('.xAxisClone').select('svg').attr('width',width)
                 		d3.select('.xAxisClone').select('.xaxis').attr('transform','translate(10,6)');
                 		d3.select('.xAxisClone').select('.xaxis path').attr('transform','translate(-20,0)')
                 		$('.xAxisClone').addClass('hideXaxis');


                 		function wrap(text, width,axis) {
                 			text.each(function() {
                 				var text = d3.select(this),
                 				words = text.text().split(/\s+/).reverse(),
                 				splitStringArray = [],
                 				word,
                 				line = [],
                 				lineNumber = 0,
						        lineHeight = 1.1, // ems
						        y = text.attr("y"),
						        dy = parseFloat(text.attr("dy")),
						        tspan = text.text(null).append("tspan").attr("x", 0).attr("y", y).attr("dy", dy + "em");
						      
						        if(axis==="xaxis"){
							        for(var i=0;i< words.length;i++){
							        	if(words[i].length > 10 ){
							        		var sb = words[i].substr(9);
							        		var sb2 = words[i].substr(0,9);
						        	 		words.splice(i,1,sb,sb2);
						        	 	
						        	 	}
						        	}
					        	}
					        	while (word = words.pop()) {
					        		line.push(word);
					        		tspan.text(line.join(" "));
					        		if (tspan.node().getComputedTextLength() > width) {
					        			line.pop();
					        			tspan.text(line.join(" "));
					        			line = [word];
					        			tspan = text.append("tspan").attr("x", 0).attr("y", y).attr("dy", ++lineNumber * lineHeight + dy + "em").text(word);
					        		}
					        	}
					        });
                 		}

                 	}

                 }


             }

    }])
})()