'use strict';
(function(){
  angular.module('PNCAppDirectives')
    .directive('treeComponent',function(){
    	return{
    		restrict:'E',
    		scope:{
                treeobj : '='
    		},
    		link:function(scope,element,attr){
                      var $tree = $('#tree');
                      var key = Object.keys(scope.treeobj)[0];
                      $tree.tree({
                      	data:scope.treeobj[key],
                      	autoOpen: 1,
                      	selectable: false,
                      	onCreateLi: function(node,$li){
                      		if(node.children.length === 0){
                      			if(node.name === 'Home'||node.name === 'Logout'){
                                     $li.find('.jqtree-element').append('<select data-node-name="'+node.name+'" disabled><option value="none">None</option><option value="edit">Edit</option><option value="view">View</option></select>')
                      			}else{
                      				$li.find('.jqtree-element').append('<select data-node-name="'+node.name+'"><option value="none">None</option><option value="edit">Edit</option><option value="view">View</option></select>')
                      			}
                      			
                      			$li.find('.jqtree-element').find('select').val(node.privilege);
                      			$li.find('.jqtree-element').find('select').on('change',function(){
                      				var privilege = $(this).val();
                      				var name = $(this).data('node-name');
                      				scope.treeobj[key].filter(function(d){
                      					if(d.children.length !== 0){
                                            for(var i in d.children){
                                            	if(d.children[i].name === name){
                                            		d.children[i].privilege = privilege;
                                            		return false;
                                            	}
                                            }
                      					}else{
                      						 if(name === d.name){
		                      				   d.privilege = privilege;
		                      				   return false;
		                      			     }
                      					}
                      					
		                      		})
                      			})
                      		}
                      	}
                      })  
    		},
    		template:'<div id="tree"></div>'
    	}


   	})
})();