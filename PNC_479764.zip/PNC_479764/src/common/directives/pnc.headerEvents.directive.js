'use strict';
(function(){
  angular.module('PNCAppDirectives')
    .directive('eventDir',['pncServices','$q','$state','PNC_STATE_CONSTANT','pncsession','PNC_SESSION_CONFIG',function(pncServices, $q,$state,PNC_STATE_CONSTANT,pncsession,PNC_SESSION_CONFIG){
		return{
			restrict:'A',
			link:function(scope,ele,attrs){
				ele.on('click',function(){
					var privilege = $(ele).attr('privilege');
				    var defaultSubState = $(ele).attr('defaultSubMenu');
					if(ele.hasClass('LT')){
						var loginPageRedirectFlag = pncsession.get(PNC_SESSION_CONFIG.LOGGEDIN_USER_INFO).login_page_redirect;
						pncServices.logout()
						.then(function(data){			 			
							if(data.isLogoutSuccess){
								if(loginPageRedirectFlag){
									$state.go('login');
								}else{
									$state.go('appStatus',{fromApp:true});
								}
								
							}
						},function(err){
							console.log(err);

						});
					}else if(ele.hasClass('ME')||ele.hasClass("AM")||ele.hasClass('TL')){
						if(defaultSubState!== "none"){
							$state.go(PNC_STATE_CONSTANT[defaultSubState]);
						}
					}		
					else if(ele.hasClass('HM')){
						$state.go("landing");
					}else if(ele.hasClass("MQ")){
						ele.siblings().removeClass('selected')
						ele.addClass('selected');
						$state.go('modelExecution.myqueue');
					}else if(ele.hasClass('CD')){
						ele.siblings().removeClass('selected')
						ele.addClass('selected');
						$state.go('modelExecution.controldashboard');
					}else if(ele.hasClass("ED")){
						ele.siblings().removeClass('selected')
						ele.addClass('selected');
						$state.go('modelExecution.enterprisedashboard');
					}else if(ele.hasClass("SD")){
						ele.siblings().removeClass('selected')
						ele.addClass('selected');
						$state.go('modelExecution.statusdashboard');
					}else if(ele.hasClass("UM")){
						ele.siblings().removeClass('selected')
						ele.addClass('selected');
						$state.go('administration.userManagement');
					}else if(ele.hasClass("RM")){
						ele.siblings().removeClass('selected')
						ele.addClass('selected');
						$state.go('administration.roleManagement');
					}else if(ele.hasClass('DS')){
						ele.siblings().removeClass('selected')
						ele.addClass('selected');
						$state.go('modelExecution.dimsum');
					}else if(ele.hasClass('RP')){
						ele.siblings().removeClass('selected')
						ele.addClass('selected');
						$state.go('tools.runPlan');
					}else if(ele.hasClass('MR')){
						ele.siblings().removeClass('selected')
						ele.addClass('selected');
						$state.go('tools.myRuns');
					}else if(ele.hasClass('AP')){
						ele.siblings().removeClass('selected')
						ele.addClass('selected');
						$state.go('tools.aggregationPlan');
					}
				})
			}
		}
	}])
    .directive('getPrivilege',['$timeout',function($timeout){
    	return{
    		restrict:'A',
    		link:function(scope,element,attr){
                $timeout(function(){
    			 var abbr = $(element).attr('abbr');
                 var privilege = $('.navbar-nav').find('.'+abbr).attr('privilege')+"Privilege";
                 $(element).addClass(privilege)
                },0)

    		}
    	}

    }])

})()  