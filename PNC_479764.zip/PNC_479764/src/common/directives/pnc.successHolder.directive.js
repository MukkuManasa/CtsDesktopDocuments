'use strict';
(function(){
  angular.module('PNCAppDirectives')
    .directive('successHolder',function(){
		return{
			restrict:'E',
			link:function(scope,element,attrs){
				var unbindSuccessShow = scope.$on('success_show',function(event,args){
					  element.find('.alertMsg').html("Mail sent successfully.");
                      element.find('.alert').removeClass('hideSection');
				})
                element.find('.close').on('click',function() {
                	element.find('.alert').addClass('hideSection')
                })
                var unbindSuccessHide = scope.$on('success_hide',function(){
                    element.find('.alert').addClass('hideSection')
                })
                scope.$on('$destroy',function(){
                	unbindSuccessShow();
                	unbindSuccessHide();
                })
			},
			templateUrl:'views/successAlerts.html'
		}
	})
})()