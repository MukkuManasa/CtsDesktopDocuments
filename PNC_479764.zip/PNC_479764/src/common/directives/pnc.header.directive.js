'use strict';
(function(){
  angular.module('PNCAppDirectives',[])
    .directive('pncHeader',function(){
		return{
			restrict:'E',
			scope:{
				userinfo: '=',
				pncconstants: '=',
				setchoicevalue:'&',
				currentstate : "="
			},
			templateUrl:'views/headerTemplate.html'
		}

	})

})();