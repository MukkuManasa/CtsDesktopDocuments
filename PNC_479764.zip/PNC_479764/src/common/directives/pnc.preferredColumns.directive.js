'use strict';
(function(){
  angular.module('PNCAppDirectives')
    .directive('preferedColumns',['pncsession','PNC_SESSION_CONFIG',function(pncsession,PNC_SESSION_CONFIG){
		return{
			restrict:'A',
			link:function(scope,ele,attrs){
					scope.showPreferences = function(){
						scope.hideshowFlag = !scope.hideshowFlag;
						var table =  $('#dataTable').dataTable();
						var checkboxArray = $('.preferencesDiv').find('ul input');
						var checkedArray = $('.preferencesDiv').find('ul input:checked');
						$('tbody tr').removeClass("rowActive");
				        $("tbody tr td span.options").remove();
				         $("tbody tr td").removeClass("editdelete");
						function selectedColumns(checkedArray){
		    							var selectedColumns=[];
		    							if(checkedArray.length>0){
		    							checkedArray.each(function(j){
		    							selectedColumns.push(parseInt($(checkedArray[j]).val()));
		    						});
		    							
		    						}
		    						return selectedColumns
		    						}
		    						var temp=selectedColumns(checkedArray);
		    						pncsession.update(PNC_SESSION_CONFIG.PREFERED_DATA,temp);
		    						var toRemove=temp;
                           	var allColumns = scope.$eval(attrs.allcolumns);
                           	if(allColumns.length!=toRemove.length){
                           	temp = allColumns.filter( function( el ) {
  								return toRemove.indexOf( el ) < 0;
							});
                           }
		    				pncsession.update(PNC_SESSION_CONFIG.HIDECOLUMN_DATA,temp);	
						if(checkboxArray.length>0){
							
							for(var loop=0;loop<checkboxArray.length;loop++){
								$(checkboxArray[loop]).removeClass('preferenceLabelChecked');
							var arr = (table.api().columns($(checkboxArray[loop]).attr("id")).nodes())[0];	
			               	for(var key in arr){
                        	$(arr[key]).hide();
                        	$(arr[key]).removeClass("editdelete");
		    				}
		    				$(table.api().columns($(checkboxArray[loop]).attr("id")).header()).hide();
			                }
						for(var j=0;j<checkedArray.length;j++){
							$(checkedArray[j]).addClass('preferenceLabelChecked');
							var arr = (table.api().columns($(checkedArray[j]).attr("id")).nodes())[0];	
			               	for(var key in arr){
                        	$(arr[key]).show();
		    				}
		    				$(table.api().columns($(checkedArray[j]).attr("id")).header()).show();
			                }
			                var lastColumn = (table.api().columns($(checkedArray[checkedArray.length-1]).attr("id")).nodes())[0];	
			            	for(var key in lastColumn){
                        	$(lastColumn[key]).addClass("editdelete");
		    				}
		    				/*if($("thead tr").height()<70){
								$("thead tr").find('.filterOverlay').addClass("singleRow");
			    			}else if($("thead tr").height()>88){
			    				$("thead tr").find('.filterOverlay').removeClass("singleRow");
                                $("thead tr").find('.filterOverlay').addClass("tripleRow");
			    			}
			    			else{
			    				 $("thead tr").find('.filterOverlay').removeClass("tripleRow");
			    				$("thead tr").find('.filterOverlay').removeClass("singleRow");
			    			}*/ 
			            }else{

			            }

					};
					scope.cancelPreferences = function(){
						scope.hideshowFlag = !scope.hideshowFlag;
						$('.preferencesDiv').find('ul input').each(function(){
							if(!$(this).hasClass('preferenceLabelChecked')){
								$(this).prop('checked', false);
							}else{
								$(this).prop('checked', true);
							}
						})

					}
					scope.$on('getPrefernces',function(event, data){
             		   scope.getCheckedPrefernces();
         			});
         			scope.getCheckedPrefernces = function(){
         				var hideColumn=pncsession.get(PNC_SESSION_CONFIG.HIDECOLUMN_DATA);	
         					var allColumns = scope.$eval(attrs.allcolumns);
         				if(hideColumn.length!=allColumns.length){
         				for(var loop=0;loop<hideColumn.length;loop++){
         					$($('.preferencesDiv').find('ul input')[hideColumn[loop]]).removeClass('preferenceLabelChecked');
         						
         				}
         				}
						$('.preferencesDiv').find('ul input').each(function(){
							if($(this).hasClass('preferenceLabelChecked')){
								$(this).prop('checked', true);
							}else{
								$(this).prop('checked', false);
							}
						})

					};

			},
			templateUrl:'modules/secure/administration/views/preferencesTemplate.html'
		}
    }])

})()