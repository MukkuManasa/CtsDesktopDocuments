"use strict";
(function(){
angular.module('PNCApp')
	.constant("PNC_CONFIG",{
		
		//baseUrl: 'http://pc245848:9080/CCARWeb/' 
		baseUrl: baseUrl,
		//baseUrl: ''//build path

	});		
 })();