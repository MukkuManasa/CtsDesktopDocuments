"use strict";
angular.module('PNCApp',
		[
			'PNCApp.loginModule',
			'PNCApp.landingModule',
			'PNCApp.modelExecutionModule',
			'PNCApp.AnalysisnReportModule',
			'PNCApp.toolsModule',
			'PNCApp.appStatusModule',
			'ui.bootstrap',
			'PNCApp.services',
			'base64',
			'ngStorage',
			'PNCAppDirectives',
			//'pncMockService',
			'ngCookies',
			'PNCApp.administrationModule'	
			])
.run(['$rootScope','$state','pncsession','$location','PNC_SESSION_CONFIG','pncServices',
	function($rootScope,$state,pncsession,$location,PNC_SESSION_CONFIG,pncServices){

		$rootScope.$on('appStatus',function(event){
			$state.go('appStatus');
		});

		$rootScope.$on('pnc_logout',function(event){
			pncsession.removeAll();
			$state.go('login',{timeout: true});
		});


	    $rootScope.$on('$stateChangeStart', function (event,toState,toParams,fromState,fromParams) {
	    	
	    	if($location.search().isSingleSign){
	    		pncsession.update('isLogged',true);
	    	}
	    	
	      var isLogged=pncsession.get('isLogged');
	       var redirectPath = angular.isUndefined(isLogged) ? false : true;
	       var techinicalFlag =angular.isUndefined(pncsession.get(PNC_SESSION_CONFIG.SHOW_TECHNCALDIFFICULTIES)) ? false : true;
	      if(redirectPath && toState.name=="login"){
	          event.preventDefault();
	          if(fromState.name!="" ){
	          $state.go(fromState.name);
	              }
	        else if(fromState.name==""){
	          $state.go('landing');
	        }
	      }
	     
	      else{
	      	   if(!redirectPath){
			      	event.preventDefault();
			      	if(toState.name === "appStatus"){
                        $state.go('appStatus',toParams, {notify: false}).then(function() {
			                            $rootScope.$broadcast('$stateChangeSuccess', toState, toParams, fromState, fromParams);
			                        });
                        return;
			      	}else{
			      			$state.go('login', toParams, {notify: false}).then(function() {
			                            $rootScope.$broadcast('$stateChangeSuccess', toState, toParams, fromState, fromParams);
			                });
			      	}
			    }
			    else{
			        event.preventDefault();
			        $state.go(toState.name, toParams, {notify: false}).then(function() {
			                            $rootScope.$broadcast('$stateChangeSuccess', toState, toParams, fromState, fromParams);
			        });
			        return;
			    }
	  }
	    });
	}]);