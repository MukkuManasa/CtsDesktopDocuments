"use strict";
(function(){
	angular.module('PNCApp.toolsModule').controller('aggregationPlanCtrl', ['$scope','pncServices','PNC_CONSTANT','pncsession','PNC_SESSION_CONFIG','$q','$state','DTOptionsBuilder','DTColumnBuilder','$compile','$rootScope','$uibModal','$timeout',
		function($scope,pncServices,PNC_CONSTANT,pncsession,PNC_SESSION_CONFIG,$q,$state,DTOptionsBuilder,DTColumnBuilder,$compile,$rootScope,$uibModal,$timeout) {
			$scope.abbr = $state.current.abbr;
			$scope.displayFlag=false;
			$scope.input = {};
			 pncServices.getDimsumForeCastPurpose().then(function(data){
			 	             $rootScope.$broadcast('error_hide');
				    	     $scope.getAggregationObj = pncsession.get(PNC_SESSION_CONFIG.GET_DIMSUMEVENTS);
				    	     $scope.getAggregationData($scope.getAggregationObj[0],'initial');
				            },function(err){
	                          console.log(err);
	                           $rootScope.$broadcast('error_show',err.data);

				        });

				        $scope.getAggregationData = function (data,mode) {
				        	$rootScope.$broadcast('error_hide');
			        	    $scope.selectedValue = data.forecastPurpose;
			        	    pncsession.update(PNC_SESSION_CONFIG.SELECTED_AGGRPLANFORECAST, data.forecastPurpose);
			        	    $scope.exportObj = {
			        	    	forecastPurpose : data.forecastPurpose
			        	    }
			        	    pncServices.getAggrRunList(data.forecastPurpose).then(function(data){
			    	  	        $scope.displayFlag = true;
			    	  	        $scope.input.searchVal="";
                               if(mode){
                                	drawAggregationTable();
                                }else{
			        	             /*$scope.dtInstance.rerender(); 
			        	             $timeout(function(){
                                        pncServices.generateDTCustomFilters($scope.dtInstance,$compile,$scope);
                                    },100)*/
			        	           function getUpdatedAggrTable(){
										var deferred = $q.defer();
										var tableData = pncsession.get(PNC_SESSION_CONFIG.GET_AGGREGATIONDATA);
										if(tableData.length === 0){
                                             $scope.isDisabled = true;
										}else{
                                            $scope.isDisabled = false;
										}
										deferred.resolve(tableData);
										return deferred.promise;
								    }
                                	$scope.dtInstance.changeData(getUpdatedAggrTable);
                                	$timeout(function(){
                                        pncServices.generateDTCustomFilters($scope.dtInstance,$compile,$scope);
                                    },100)
                                }
			    	  		},function (err) {
			    	  			$scope.isError = true;
			    	  			$scope.displayFlag = false;
			    	  			$scope.errorQueue = err.data.message;
			    	  		})
				        }
            
			
				function drawAggregationTable(){
					        var foreCastPurpose =  pncsession.get(PNC_SESSION_CONFIG.SELECTED_RUNPLANFORECAST);
					        var message = "<h4>Forecast Purpose:"+foreCastPurpose+"</h4>";
					        $scope.scrollbarFilterConfig = {
								axis:"y",
						    	autoHideScrollbar:false,
						    	theme:"dark",
						    	autoDraggerLength:true,
						    	scrollButtons:{
						    		enable: false 
						    	}
						    }

							$scope.dtOptions = DTOptionsBuilder.fromFnPromise(function(){
								return getRunPlanTableData()
							}).withOption('info',false).withPaginationType('numbers').withDisplayLength(15);
							$scope.dtColumns=[
								DTColumnBuilder.newColumn('forecastPurpose').withTitle('Forecast Purpose'),	
								DTColumnBuilder.newColumn('forecastType').withTitle('Forecast Type'),	
								DTColumnBuilder.newColumn('modelName').withTitle('Model Name'),
								DTColumnBuilder.newColumn('runId').withTitle('Run Id'),
								DTColumnBuilder.newColumn('runStatus').withTitle('Published Status'),
								DTColumnBuilder.newColumn('aggrPublisher').withTitle('Publisher'),
								DTColumnBuilder.newColumn('aggrPublishedDateTime').withTitle('Published Date/Time')
								
							];

							function getRunPlanTableData () {
							    	var deferred = $q.defer();
			                       	var tableData = pncsession.get(PNC_SESSION_CONFIG.GET_AGGREGATIONDATA);
			                       	if(tableData.length === 0){
		                                     $scope.isDisabled = true;
										}else{
		                                    $scope.isDisabled = false;
										}
			                        deferred.resolve(tableData);
			                        return deferred.promise;
							}

							$scope.dtInstanceCallback = function(dtInstance){
								$scope.dtInstance = dtInstance;
								pncServices.generateDTCustomFilters(dtInstance,$compile,$scope);
					        	
							}
							var unwatchSearch = $scope.$watch("input.searchVal",function(newVal,oldVal){ 
					       if(newVal !== oldVal){
							  if($scope.dtInstance){
								var table = $scope.dtInstance.DataTable;
								table.search($scope.input.searchVal).draw();
								}
							}
		    		});

					$scope.clearSearch = function(){
				    	$scope.input.searchVal="";
				    }
                    $scope.$on('$destroy',function(){
                    	unwatchSearch();
                    })
    				
					}

					$scope.publishAggrPlan = function(){
						$rootScope.$broadcast('error_hide');
						var userID = pncsession.get(PNC_SESSION_CONFIG.LOGGEDIN_USER_INFO).user_Details.userCd;
						var forecastPurpose = pncsession.get(PNC_SESSION_CONFIG.SELECTED_AGGRPLANFORECAST);
						var obj = {
							forecastPurpose : forecastPurpose
						}
						pncServices.updateAggrRunPlan(forecastPurpose,userID).then(function(data){
                             $scope.getAggregationData(obj)
						},function(err){
							$scope.isError = true;
							$scope.displayFlag = false;
							$scope.errorQueue = err.data.message;
						})
					}

					 $scope.clearSearch = function(){
				    	$scope.input.searchVal="";
				    	var table = $scope.dtInstance.DataTable;
	                    table.search($scope.input.searchVal).draw();
				    }

				    
					
	                
}])

})();