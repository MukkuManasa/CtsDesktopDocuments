"use strict";
(function(){
  angular.module('PNCApp.toolsModule').controller('toolsCtrl',['$scope','pncServices','PNC_CONSTANT','pncsession','PNC_SESSION_CONFIG','$q','$state',
  	              function($scope,pncServices,PNC_CONSTANT,pncsession,PNC_SESSION_CONFIG,$q,$state){
  	              	$scope.pncConstants = PNC_CONSTANT;
				    $scope.userInfo = pncsession.get(PNC_SESSION_CONFIG.LOGGEDIN_USER_INFO);
				    $scope.currentState='tools';
				    $scope.currentSubState = $state.current.name;
				    $scope.currentSubStateAbbr = $state.current.abbr;

				    $scope.action = function(value){
	                     $scope.userInfo.default_Role = value;
	                     $state.go('landing')
				    }
				    $scope.subMenuObj =  $scope.userInfo.assigned_Resources[$scope.userInfo.default_Role].filter(function(d){
                            if(d.menuShortName === $scope.pncConstants[$scope.currentState]){
                               return d;
                            }
                          
				    })
				    pncsession.remove(PNC_SESSION_CONFIG.HIDECOLUMN_DATA);
				    pncsession.remove(PNC_SESSION_CONFIG.PREFERED_DATA);


  }])
})();