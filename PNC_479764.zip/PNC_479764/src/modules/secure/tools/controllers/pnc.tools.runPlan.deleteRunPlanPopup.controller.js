"use strict";
 angular.module('PNCApp.toolsModule').controller('deleteRunPlanPopupCtrl', ['$scope','$uibModalInstance','pncServices','data','$rootScope','PNC_SESSION_CONFIG','pncsession',
 	function($scope,$uibModalInstance,pncServices,data,$rootScope,PNC_SESSION_CONFIG,pncsession) {
 		$rootScope.$broadcast('runPlanError_hide');
 		$scope.runId = data.runId;
 		$scope.cancel = function () {
	        $uibModalInstance.dismiss('cancel');
	    };
	    $scope.deleteRunPlan = function(){
	    	pncServices.deleteRunPlan(data).then(function(){
	    		            $scope.$parent.errorFlag = false;
	    		             $uibModalInstance.dismiss('cancel');
                             $rootScope.$broadcast('getRunPlanTableData');
                    	 },function(err){
	                 		console.log(err);
	                 		$uibModalInstance.dismiss('cancel');
	                 		$rootScope.$broadcast('runPlanError_show',err.data);

	        })
	    }
	            			
}])