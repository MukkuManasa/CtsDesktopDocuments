"use strict";
 angular.module('PNCApp.toolsModule').controller('editRunPlanPopupCtrl', ['$scope','$uibModalInstance','pncServices','data','$rootScope','PNC_SESSION_CONFIG','pncsession','$uibModal',
 	function($scope,$uibModalInstance,pncServices,data,$rootScope,PNC_SESSION_CONFIG,pncsession,$uibModal) {
 		$rootScope.$broadcast('runPlanError_hide');
 		$scope.editRunPlan = {};
 		 $scope.editMode = false;
 		 $scope.addMode = false;
 		 $scope.cloneMode = false;
 		 $scope.disabledFlag = false;
 		if(data){
 		   var selectData = data.selectObj;
 		   var modelData = data.modelObj;


 			/*Drop Down objects*/
           $scope.editRunPlan.fundedUnfundedObj = selectData.FUNDED_UNFUNDED;
           $scope.editRunPlan.newVolumeIncludedObj = selectData.NEW_VOLUME_INCLUDED;
           $scope.editRunPlan.scenarioObj = selectData.SCENARIO;
           $scope.editRunPlan.runTypeObj = selectData.RUN_TYPE;
           $scope.editRunPlan.includeInAggregationObj = selectData.INCLUDE_IN_AGGREGATION;
           $scope.editRunPlan.runStatusObj = selectData.RUN_STATUS;
           $scope.editRunPlan.forecastTypeObj = selectData.FORECAST_TYPE;
           $scope.editRunPlan.modelNameObj = modelData;
           
		            if(data.mode === "EDIT" || data.mode === "CLONE"){ // For EDIT Modal
		            	  $scope.editMode = true;
		            	  $scope.disabledFlag = true;
				 		   var pojo = JSON.parse(data.pojo);
				           $scope.editRunPlan.runId = pojo.runId;
				           $scope.editRunPlan.modelName = pojo.mrmgModelName;
				           $scope.editRunPlan.runName = pojo.runName;
				           $scope.editRunPlan.runDescription = pojo.runDescription;
				           $scope.editRunPlan.createdBy = pojo.createdBy;
				           $scope.editRunPlan.createdDateTime = pojo.createdDateTime;
				           $scope.editRunPlan.forecastPurpose = pojo.forecastPurpose;
				           $scope.editRunPlan.approver = pojo.approver;
				           $scope.editRunPlan.approverComments = pojo.approvedComments;
				           $scope.editRunPlan.aprrovedDateTime = pojo.aprrovedDateTime;
				           $scope.editRunPlan.modelId  = pojo.mrmgModelId;
				           /*Drop down values*/

				           $scope.editRunPlan.fundedUnfunded = pojo.fundedUnfunded;
				           $scope.editRunPlan.newVolumeIncluded = pojo.newVolumeIncluded;
				           $scope.editRunPlan.scenario = pojo.scenario;
				           $scope.editRunPlan.runType = pojo.runType;
				           $scope.editRunPlan.includeInAggregation = pojo.includeInAggregation;
				           $scope.editRunPlan.runStatus = pojo.runStatus;
				           $scope.editRunPlan.forecastType = pojo.forecastType;

				 	}else if(data.mode === "ADD"){
				 		$scope.addMode = true;
				 		$scope.disabledFlag = false;
				 		$scope.editRunPlan.newVolumeIncluded = 'Yes';
				 		$scope.editRunPlan.forecastPurpose = data.forecastPurpose; 
				 	} 
				 	if(data.mode === "CLONE"){
		                $scope.cloneMode = true;
		                $scope.editMode = false;
		                $scope.disabledFlag = false;
		                $scope.editRunPlan.runId = "";
				 	}

		}
 		
 				$scope.scrollBarYConfig= {
					axis:"y",
					autoHideScrollbar:false,
					theme:"dark",
					autoDraggerLength:true,
					scrollButtons:{
						enable: false 
					}
				}
 				
				$scope.cancel = function () {
	                $uibModalInstance.dismiss('cancel');
	            };
	            $scope.hasError = function(field, validation){
	            	if(validation){
	            		return ($scope.form[field].$touched && $scope.form[field].$error[validation]) || ($scope.submitted && $scope.form[field].$error[validation]);
	            	}
	            	return ($scope.form[field].$touched && $scope.form[field].$invalid) || ($scope.submitted && $scope.form[field].$invalid);
	            };
                $scope.validateRunId = function(form){
                	if($scope.editRunPlan.runId && $scope.editRunPlan.forecastPurpose && $scope.editRunPlan.modelId){
                		var runId = ($scope.editRunPlan.runId).toUpperCase().split('_');
	                	if(runId[0] === $scope.editRunPlan.forecastPurpose && runId[1] === $scope.editRunPlan.modelId){
	                		return false;
	                	}
	                	form.$valid = false;
	                	form.runId.$invalid = true;
	                	return true;
                	}
                	
                }
                $scope.checkRunId = function(form){
                		 if($scope.editRunPlan.runId && !$scope.editMode){
	                      var runPlanData = pncsession.get(PNC_SESSION_CONFIG.GET_RUNPLANDATA);
	                      for(var key in runPlanData){
                                if((runPlanData[key].runId).toUpperCase() === ($scope.editRunPlan.runId).toUpperCase()){
                                	form.$valid = false;
                                	form.runId.$invalid = true;
                                	return true;
                                }
	                      }
	                      return false;
                	 }

               
                	
                }
	            
	            $scope.changeInAggr = function(aggrModel){
                     if(aggrModel === "No"){
                         var modalInstance = $uibModal.open({
	                 			templateUrl:"modules/secure/tools/views/warningPopup.html",
	                 			controller : ['$scope','$uibModalInstance',function($scope,$uibModalInstance){
                                        $scope.cancel = function () {
									        $uibModalInstance.dismiss('cancel');
									    };
	                 			}],
	                 			windowClass : 'deleteModalWidth',
	                 			backdrop : 'static' 
	                 		});
                     }
	            }
	           
	            $scope.updateRunPlan =  function(form){
	            	$scope.submitted = true;
	            	if(form.$valid){
	            		var userDetails = pncsession.get(PNC_SESSION_CONFIG.LOGGEDIN_USER_INFO).user_Details;
	            		var userID = userDetails.userCd;
	            		var emailID = userDetails.emailAddrTxt;
	            		var firstName = userDetails.firstNameTxt;
	            		var middleName = userDetails.middleNameTxt;
	            		var lastName = userDetails.lastNameTxt;
           	            

	            		var pojo = {
	            			"mrmgModelId" : $scope.editRunPlan.modelId,
	            			"mrmgModelName":$scope.editRunPlan.modelName,
	            			"forecastType" : $scope.editRunPlan.forecastType,
	            			"forecastPurpose" : $scope.editRunPlan.forecastPurpose,
	            			"runId" : $scope.editRunPlan.runId,
	            			"runType": $scope.editRunPlan.runType,
	            			"runName" : $scope.editRunPlan.runName,
	            			"runDescription": $scope.editRunPlan.runDescription,
							"fundedUnfunded": $scope.editRunPlan.fundedUnfunded,
							"newVolumeIncluded": $scope.editRunPlan.newVolumeIncluded,
							"scenario":$scope.editRunPlan.scenario,
							"includeInAggregation":$scope.editRunPlan.includeInAggregation,
							"runStatus": $scope.editRunPlan.runStatus,
							"updatedByUserCd":userID,
							"updatedByUserCdEmail":emailID,
							"userCdFirstName":firstName,
							"userCdMiddleName":middleName,
							"userCdLastName":lastName
	            		}
	            		pncServices.editRunPlan(pojo).then(function(data){
	            		   $scope.$parent.errorFlag = false;
	            		   $uibModalInstance.dismiss('cancel');
	            		   $rootScope.$broadcast('getRunPlanTableData');
						},function(err){
							$uibModalInstance.dismiss('cancel');
							$rootScope.$broadcast('runPlanError_show',err.data);
						});
	            	}
	            };
	            $scope.addCloneRunPlan = function(form){
	            	$scope.submitted = true;
	            	if(form.$valid){
	            	    var userDetails = pncsession.get(PNC_SESSION_CONFIG.LOGGEDIN_USER_INFO).user_Details;
	            		var userID = userDetails.userCd;
	            		var emailID = userDetails.emailAddrTxt;
	            		var firstName = userDetails.firstNameTxt;
	            		var middleName = userDetails.middleNameTxt;
	            		var lastName = userDetails.lastNameTxt;
	            	    var emailID = userDetails.emailAddrTxt;
	            	    var modelArray = modelData.filter(function(d){
           	            if(d.MRMG_MODEL_ID === $scope.editRunPlan.modelId){
           	             	return d;
           	             }
                        })
	            		var pojo = {
	            			"mrmgModelId" : $scope.editRunPlan.modelId,
                            "mrmgModelName": modelArray[0].MODEL_NAME,
	            			"forecastPurpose" : $scope.editRunPlan.forecastPurpose,
	            			"forecastType" : $scope.editRunPlan.forecastType,
	            			"runId" : $scope.editRunPlan.runId,
	            			"runType": $scope.editRunPlan.runType,
	            			"runName" : $scope.editRunPlan.runName,
	            			"runDescription": $scope.editRunPlan.runDescription,
							"fundedUnfunded": $scope.editRunPlan.fundedUnfunded,
							"newVolumeIncluded": $scope.editRunPlan.newVolumeIncluded,
							"scenario":$scope.editRunPlan.scenario,
							"includeInAggregation":$scope.editRunPlan.includeInAggregation,
							"createdBy":userID,
							"updatedByUserCd":userID,
							"updatedByUserCdEmail":emailID,
							"userCdFirstName":firstName,
							"userCdMiddleName":middleName,
							"userCdLastName":lastName
	            		}
	            		pncServices.addRunPlan(pojo).then(function(data){
	            			$scope.$parent.errorFlag = false;
	            		   $uibModalInstance.dismiss('cancel');
	            		   $rootScope.$broadcast('getRunPlanTableData');
						},function(err){
							$uibModalInstance.dismiss('cancel');
							$rootScope.$broadcast('runPlanError_show',err.data);
						});
	            	}
	            }
	            			
}])