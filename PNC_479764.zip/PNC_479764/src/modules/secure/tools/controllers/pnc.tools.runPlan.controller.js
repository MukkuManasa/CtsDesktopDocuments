"use strict";
(function(){
	angular.module('PNCApp.toolsModule').controller('runPlanCtrl', ['$scope','pncServices','PNC_CONSTANT','pncsession','PNC_SESSION_CONFIG','$q','$state','DTOptionsBuilder','DTColumnBuilder','$compile','$rootScope','$uibModal','$timeout',
		function($scope,pncServices,PNC_CONSTANT,pncsession,PNC_SESSION_CONFIG,$q,$state,DTOptionsBuilder,DTColumnBuilder,$compile,$rootScope,$uibModal,$timeout) {
			//$rootScope.$broadcast('runPlanError_hide');
			$scope.abbr = $state.current.abbr;
			$scope.input = {};
			$scope.displayFlag=false;
			$scope.cloneDisable=true;
			$scope.hideshowFlag=false;
			$scope.gridTitle = PNC_CONSTANT[$scope.abbr]
			//$scope.isError = false;
			var hideColumns=[0,3,4,8,9,12,13];
			var noOfColumns=[0,1,2,3,4,5,6,7,8,9,10,11,12,13];
			$scope.$on('getRunPlanTableData',function(){
                var obj = {
                	 forecastPurpose : pncsession.get(PNC_SESSION_CONFIG.SELECTED_RUNPLANFORECAST)
                };

                $scope.getRunPlanData(obj,"EDIT");
			})
			pncServices.getDimsumForeCastPurpose().then(function(data){
				$rootScope.$broadcast('runPlanError_hide');
				 pncServices.getRunPlanDropdownData().then(function(data){
				 	$rootScope.$broadcast('runPlanError_hide');
                     $scope.getRunPlanObj = pncsession.get(PNC_SESSION_CONFIG.GET_DIMSUMEVENTS);
	    	         $scope.getRunPlanData($scope.getRunPlanObj[0],'ADD');
				 },function(err){
                    console.log(err);
                    $rootScope.$broadcast('runPlanError_show',err.data); 
				 })
	    	    
	            },function(err){
                  console.log(err);
                  $rootScope.$broadcast('runPlanError_show',err.data);    
			});
            
			$scope.getRunPlanData = function (data,mode) {
			        	    $scope.selectedValue = data.forecastPurpose;
			        	    pncsession.update(PNC_SESSION_CONFIG.SELECTED_RUNPLANFORECAST, data.forecastPurpose);
			        	    var userID = pncsession.get(PNC_SESSION_CONFIG.LOGGEDIN_USER_INFO).user_Details.userCd;
			        	    $scope.exportObj = {
			        	    	foreCastPurpose : data.forecastPurpose,
			        	    	userCd : userID,
			        	    	columnClass : 'runId',
						    	isFilter : false,
						    	filterData : []
			        	    }
			        	    pncServices.getRunPlanList(data.forecastPurpose,userID).then(function(data){
			        	    	$rootScope.$broadcast('runPlanError_hide');
			    	  	        $scope.displayFlag = true;
			    	  	        $scope.input.searchVal="";
			    	  	        $rootScope.$broadcast('loader_show');
                               if(mode === "ADD"){
                                	drawRunPlanTable();
                                }else{
                                	function getUpdatedDimsumTable(){
										var deferred = $q.defer();
										var tableData = pncsession.get(PNC_SESSION_CONFIG.GET_RUNPLANDATA);
										if($scope.abbr === "MR"){
				                       		tableData = tableData.filter(function(d){
	                                                if(d.isRowEditable === "TRUE"){
	                                                	return d;
	                                                }
				                       		})
			                       	    }
										if(tableData.length === 0){
                                             $scope.isDisabled = true;
										}else{
                                            $scope.isDisabled = false;
										}
										deferred.resolve(tableData);
										return deferred.promise;
								    }
                                	$scope.dtInstance.changeData(getUpdatedDimsumTable);
                                	$timeout(function(){
                                        pncServices.generateDTCustomFilters($scope.dtInstance,$compile,$scope);
                                        pncServices.preferedColumns($scope.dtInstance,$compile,$scope,noOfColumns,hideColumns);
                                         $rootScope.$broadcast('loader_hide');
                                    },100)
                                    $('.cloneRunplan').removeClass('orangeButton');
                                   
			        	            /* $scope.dtInstance.rerender(); 
			        	             $timeout(function(){
                                        pncServices.generateDTCustomFilters($scope.dtInstance,$compile,$scope);
                                    },100)*/
                                }
			    	  		},function (err) {
			    	  			$scope.isError = true;
			    	  			$scope.displayFlag=false;
			    	  			$scope.errorQueue = err.data.message;
			    	  		})
				}

				function drawRunPlanTable(){  
					       var message = "<h4 class='printMsg'>Forecast Purpose:</h4>"
					        $scope.scrollbarFilterConfig = {
								axis:"y",
						    	autoHideScrollbar:false,
						    	theme:"dark",
						    	autoDraggerLength:true,
						    	scrollButtons:{
						    		enable: false 
						    	}
						    }

							$scope.dtOptions = DTOptionsBuilder.fromFnPromise(function(){
								return getRunPlanTableData()
							}).withOption('info',false).withPaginationType('numbers').withDisplayLength(15).withButtons([{
								extend:'print',
								title:$scope.gridTitle,
								className:'printButton',
								message:message,
								text:"Print",
								exportOptions: {
				                    columns: ':visible'
				                },
								customize:function(win){
									var selectObj =  pncsession.get(PNC_SESSION_CONFIG.SELECTED_RUNPLANFORECAST);
								    $(win.document.body).find('.printMsg').html('Forecast Purpose:'+selectObj);
									$(win.document.body).find('table').css({'margin':'0px','padding':'0px','border-collapse':'collapse','width':'80%'}).addClass('compact').css('font-size','inherit');
									$(win.document.body).find('table,table td,table th').css('border','1px solid black')
									$(win.document.body).find('th,td').css({'margin':'0px','padding':'0px'})
									$(win.document.body).find('td').css({'word-break':'break-all','white-space':'pre-wrap','word-wrap':'break-word','min-width':'50px'})
									
								}
							}]).withOption('fnCreatedRow',function(nRow, aData, iDataIndex){
								    if(aData.isRowEditable === "TRUE"){
								       var obj = JSON.stringify(aData);
								       $(nRow).attr({'row-events':"",pojo:obj});
								       $(nRow).addClass('rowEditable')
								       $compile(nRow)($scope);
								       return nRow;
								    }		
							}).withOption("order",[]);
							$scope.dtColumns=[
								DTColumnBuilder.newColumn('mrmgModelId').withTitle('MRMG Model ID'),
								DTColumnBuilder.newColumn('forecastType').withTitle('Forecast Type'),
								DTColumnBuilder.newColumn('mrmgModelName').withTitle('Model Name'),
								DTColumnBuilder.newColumn('fundedUnfunded').withTitle('Funded Unfunded'),
								DTColumnBuilder.newColumn('newVolumeIncluded').withTitle('New Volume Included').withClass('text-center'),
								DTColumnBuilder.newColumn('scenario').withTitle('Scenario'),
								DTColumnBuilder.newColumn('runId').withTitle('Run Id').withOption('class','runId'),
								DTColumnBuilder.newColumn('runType').withTitle('Run Type'),
								DTColumnBuilder.newColumn('runName').withTitle('Run Name'),
								DTColumnBuilder.newColumn('runDescription').withTitle('Run Description'),
								DTColumnBuilder.newColumn('includeInAggregation').withTitle('Include In Aggregation').withClass('text-center'),
								DTColumnBuilder.newColumn('runStatus').withTitle('Run Status'),
								DTColumnBuilder.newColumn('createdBy').withTitle('Created By'),
								DTColumnBuilder.newColumn('createdDateTime').withTitle('Created date time')
							];

							function getRunPlanTableData () {
							    	var deferred = $q.defer();
			                       	var tableData = pncsession.get(PNC_SESSION_CONFIG.GET_RUNPLANDATA);
			                       	if($scope.abbr === "MR"){
			                       		tableData = tableData.filter(function(d){
                                                if(d.isRowEditable === "TRUE"){
                                                	return d;
                                                }
			                       		})
			                       	}
			                       	if(tableData.length === 0){
		                                     $scope.isDisabled = true;
										}else{
		                                    $scope.isDisabled = false;
										}
			                        deferred.resolve(tableData);
			                        return deferred.promise;
							}

							$scope.dtInstanceCallback = function(dtInstance){
								$scope.dtInstance = dtInstance;
								pncServices.generateDTCustomFilters(dtInstance,$compile,$scope);
								pncServices.preferedColumns(dtInstance,$compile,$scope,noOfColumns,hideColumns);
								 $rootScope.$broadcast('loader_hide');
					        	
							}
					}

					var unwatchSearch = $scope.$watch("input.searchVal",function(newVal,oldVal){ 
					       if(newVal !== oldVal){
							  if($scope.dtInstance){
								var table = $scope.dtInstance.DataTable;
								table.search($scope.input.searchVal).draw();
								}
							}
		    		});

					$scope.clearSearch = function(){
				    	$scope.input.searchVal="";
				    }
                    $scope.$on('$destroy',function(){
                    	unwatchSearch();
                    })
					

				    $scope.editRunPlan = function($event,pojo){
                        $event.stopPropagation();
                        var userID = pncsession.get(PNC_SESSION_CONFIG.LOGGEDIN_USER_INFO).user_Details.userCd;
                        var foreCastPurpose =  pncsession.get(PNC_SESSION_CONFIG.SELECTED_RUNPLANFORECAST);
				    	pncServices.getModelNameDropDown(userID,foreCastPurpose).then(function(res){
				    		$scope.errorFlag = false;
				    		var selectObj = pncsession.get(PNC_SESSION_CONFIG.GET_RUNPLANSELECTDATA);
				    		var data = {
				    			pojo: pojo,
				    			selectObj : selectObj,
				    			modelObj:res,
				    			forecastPurpose : foreCastPurpose,
				    			mode:"EDIT"
				    		}
	                 		var modalInstance = $uibModal.open({
	                 			templateUrl:"modules/secure/tools/views/editRunPlanPopup.html",
	                 			controller:'editRunPlanPopupCtrl',
	                 			resolve: {
	                 				data: function () {
	                 					return data;
	                 				}
	                 			},
	                 			backdrop : 'static' 
	                 		});

				    	},function(err){
	                 		console.log(err);
	                 		$rootScope.$broadcast('runPlanError_show',err.data);
	                 	})

                    };
                    $scope.getPrefernces = function(){
						$scope.hideshowFlag = !$scope.hideshowFlag;
						 $rootScope.$broadcast('getPrefernces',{});

					};
                    $scope.deleteRunPlan = function($event,pojo){
                    	 $event.stopPropagation();
                    	 var obj = JSON.parse(pojo);
                    	 var runId = obj.runId;
                    	 var userDetails = pncsession.get(PNC_SESSION_CONFIG.LOGGEDIN_USER_INFO).user_Details;
                    	 var data = {
	            			"mrmgModelId" : obj.mrmgModelId,
	            			"mrmgModelName" : obj.mrmgModelName, 
	            			"forecastPurpose" : obj.forecastPurpose,
	            			"forecastType" : obj.forecastType,
	            			"runId" : obj.runId,
	            			"runType": obj.runType,
	            			"runName" : obj.runName,
	            			"runDescription": obj.runDescription,
							"fundedUnfunded": obj.fundedUnfunded,
							"newVolumeIncluded": obj.newVolumeIncluded,
							"scenario":obj.scenario,
							"includeInAggregation":obj.includeInAggregation,
							"runStatus": obj.runStatus,
							"createdBy":userDetails.userCd,
							"updatedByUserCd":userDetails.userCd,
							"updatedByUserCdEmail":userDetails.emailAddrTxt,
							"userCdFirstName":userDetails.firstNameTxt,
							"userCdMiddleName":userDetails.middleNameTxt,
							"userCdLastName":userDetails.lastNameTxt
	            		}
                        
                        var modalInstance = $uibModal.open({
	                 			templateUrl:"modules/secure/tools/views/deletePopUp.html",
	                 			controller:'deleteRunPlanPopupCtrl',
	                 			resolve: {
	                 				data: function () {
	                 					return data;
	                 				}
	                 			},
	                 			windowClass : 'deleteModalWidth',
	                 			backdrop : 'static' 
	                    });
                    }
					
	                
}])

})();