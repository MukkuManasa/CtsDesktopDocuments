'use strict';
(function(){
angular.module('PNCApp.toolsModule',['ui.router'])
.config(['$stateProvider','$urlRouterProvider',function($stateProvider,$urlRouterProvider){
   $stateProvider
        .state('tools', {
	   		url:'/tools',
	    	templateUrl: 'modules/secure/tools/views/tools.html',
	    	controller:'toolsCtrl'
	    })
	    .state('tools.runPlan',{
	   	   url:'/runPlan',
	   	   templateUrl:'modules/secure/tools/views/runPlan.html',
	   	   controller:"runPlanCtrl",
	   	   abbr:"RP"
	    })
	    .state('tools.myRuns',{
	   	   url:'/myRuns',
	   	   templateUrl:'modules/secure/tools/views/runPlan.html',
	   	   controller:"runPlanCtrl",
	   	   abbr:"MR"
	    })
	    .state('tools.aggregationPlan',{
	   	   url:'/aggregationPlan',
	   	   templateUrl:'modules/secure/tools/views/aggregationPlan.html',
	   	   controller:"aggregationPlanCtrl",
	   	   abbr:"AP"
	    })

 }])
})();