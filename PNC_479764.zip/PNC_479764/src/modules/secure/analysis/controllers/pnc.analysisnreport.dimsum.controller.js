"use strict";
(function(){
  angular.module('PNCApp.AnalysisnReportModule').controller('dimsumCtrl',
  	['$scope','DTOptionsBuilder','DTColumnBuilder','pncServices','PNC_CONSTANT','pncsession','PNC_SESSION_CONFIG','$q','$state','$window','$compile','$timeout',
  	              function($scope,DTOptionsBuilder,DTColumnBuilder,pncServices,PNC_CONSTANT,pncsession,PNC_SESSION_CONFIG,$q,$state,$window,$compile,$timeout){
		                $scope.isInit = false;

  	              	    $scope.isDisabled = false;
                        $scope.abbr = $state.current.abbr;
  	              	    $scope.scrollbarFilterConfig = {
								axis:"y",
						    	autoHideScrollbar:false,
						    	theme:"dark",
						    	autoDraggerLength:true,
						    	scrollButtons:{
						    		enable: false 
						    	}
				        }



	                    pncServices.getDimsumForeCastPurpose().then(function(data){
				    	     $scope.getDimsumObj = pncsession.get(PNC_SESSION_CONFIG.GET_DIMSUMEVENTS);
				    	     $scope.getDimsumData($scope.getDimsumObj[0],'initial');
				            },function(err){
	                          console.log(err);
				        });

				        $scope.getDimsumData = function (data,mode) {
			        	    $scope.selectedValue = data.forecastPurpose;
			        	    $scope.exportObj = {
			        	    	forecastPurpose : data.forecastPurpose
			        	    }
			        	    pncServices.getDimsumRunList(data.forecastPurpose).then(function(data){
			    	  	        $scope.isInit = true;
                               if(mode){
                                	generateDimsumTable();
                                }else{
                                	/*function getUpdatedDimsumTable(){
										var deferred = $q.defer(),
										tableData = data;
										if(tableData.length === 0){
                                             $scope.isDisabled = true;
										}else{
                                            $scope.isDisabled = false;
										}
										deferred.resolve(tableData);
										return deferred.promise;
								    }
                                	$scope.dtInstance.changeData(getUpdatedDimsumTable);
                                	$timeout(function(){
                                        pncServices.generateDTCustomFilters($scope.dtInstance,$compile,$scope);
                                    },100)*/
			        	             $scope.dtInstance.rerender(); 
			        	             $timeout(function(){
                                        pncServices.generateDTCustomFilters($scope.dtInstance,$compile,$scope);
                                    },100)
                                }
			    	  		},function (err) {
			    	  			$scope.errorQueue = err.data.code+" "+err.data.message;
			    	  		})
				        }

				        function generateDimsumTable(){

				        	    $scope.dtOptions = DTOptionsBuilder.fromFnPromise(function () {
                                              return getDimsumTableData();
					  	              		}).withPaginationType('numbers').withButtons([{
												extend:'print',title:"Dimsum Monitoring Data",className:'printButton',text:"Print",customize:function(win){
													$(win.document.body).find('table').css({'margin':'0px','padding':'0px','border-collapse':'collapse','width':'80%'}).addClass('compact').css('font-size','inherit');
												 $(win.document.body).find('table,table td,table th').css('border','1px solid black')
												  $(win.document.body).find('th,td').css({'margin':'0px','padding':'0px'})
													
												}
											}]).withOption('info',false).withDisplayLength(15).withOption('fnCreatedRow',function(nRow, aData, iDataIndex){
												  $('td:eq(5)', nRow).html( '<span class="colorColumn" style="background-color:'+aData.received+'">&nbsp;</span>' );
												  $('td:eq(6)', nRow).html( '<span class="colorColumn" style="background-color:'+aData.expected+'">&nbsp;</span>' );
												  $('td:eq(7)', nRow).html( '<span class="colorColumn" style="background-color:'+aData.errors+'">&nbsp;</span>' );

											});

							    $scope.dtColumns=[
							        DTColumnBuilder.newColumn('forecastType').withTitle('Forecast Type'),
							        DTColumnBuilder.newColumn('displayMode').withTitle('Display Mode'),
							        DTColumnBuilder.newColumn('mrmgModelId').withTitle('MRMG Model ID'),
							        DTColumnBuilder.newColumn('modelName').withTitle('Model Name'),
							        DTColumnBuilder.newColumn('runId').withTitle('Run ID'),
							        DTColumnBuilder.newColumn('received').withTitle('Received').withClass('text-center'),
							        DTColumnBuilder.newColumn('expected').withTitle('Expected').withClass('text-center'),
							        DTColumnBuilder.newColumn('errors').withTitle('Errors').withClass('text-center'),
							        DTColumnBuilder.newColumn('receivedDateTime').withTitle('Received Date Time')   
							    ];

							    function getDimsumTableData () {
							    	var deferred = $q.defer();
			                       	var tableData = pncsession.get(PNC_SESSION_CONFIG.GET_DIMSUMDATA);
			                       	if(tableData.length === 0){
                                             $scope.isDisabled = true;
										}else{
                                            $scope.isDisabled = false;
										}
			                        deferred.resolve(tableData);
			                        return deferred.promise;
							    }

							    $scope.dtInstanceCallback = function (dtInstance) {
				                           $scope.dtInstance = dtInstance;
				                           pncServices.generateDTCustomFilters(dtInstance,$compile,$scope);
				                           
								}

				        }

				        

    }])
	
})();