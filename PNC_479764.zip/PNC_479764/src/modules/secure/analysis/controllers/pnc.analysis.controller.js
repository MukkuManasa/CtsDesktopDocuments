"use strict";
(function(){
  angular.module('PNCApp.AnalysisnReportModule').controller('analysisNreportCtrl',['$scope','pncServices','PNC_CONSTANT','pncsession','PNC_SESSION_CONFIG','$q','$state',
  	              function($scope,pncServices,PNC_CONSTANT,pncsession,PNC_SESSION_CONFIG,$q,$state){
  	              	$scope.pncConstants = PNC_CONSTANT;
				    $scope.userInfo = pncsession.get(PNC_SESSION_CONFIG.LOGGEDIN_USER_INFO);
				    $scope.currentState='analysis';
				    $scope.currentSubState = $state.current.name;

				    $scope.action = function(value){
	                     $scope.userInfo.default_Role = value;
	                     $state.go('landing')
				    }


  }])
})();