'use strict';
(function(){
angular.module('PNCApp.AnalysisnReportModule',['ui.router'])
.config(['$stateProvider','$urlRouterProvider',function($stateProvider,$urlRouterProvider){
   $stateProvider
        .state('analysis',{
           url:'/analysisnreport',
	   	   templateUrl:'modules/secure/analysis/views/analysisnreport.html',
	   	   controller:'analysisNreportCtrl'
        })
 }])
})();