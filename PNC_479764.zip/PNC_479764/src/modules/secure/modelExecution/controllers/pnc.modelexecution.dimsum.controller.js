"use strict";
(function(){
  angular.module('PNCApp.AnalysisnReportModule').controller('dimsumCtrl',
  	['$scope','DTOptionsBuilder','DTColumnBuilder','pncServices','PNC_CONSTANT','pncsession','PNC_SESSION_CONFIG','$q','$state','$window','$compile','$timeout','$rootScope',
  	              function($scope,DTOptionsBuilder,DTColumnBuilder,pncServices,PNC_CONSTANT,pncsession,PNC_SESSION_CONFIG,$q,$state,$window,$compile,$timeout,$rootScope){
		                $scope.isInit = false;
                        $scope.hideshowFlag=false;
  	              	    $scope.isDisabled = false;
                        $scope.abbr = $state.current.abbr;
                        var hideColumns=[4,5];
			            var noOfColumns=[0,1,2,3,6,7,8,9,10,11];
  	              	    $scope.scrollbarFilterConfig = {
								axis:"y",
						    	autoHideScrollbar:false,
						    	theme:"dark",
						    	autoDraggerLength:true,
						    	scrollButtons:{
						    		enable: false 
						    	}
				        }



	                    pncServices.getDimsumForeCastPurpose().then(function(data){
	                    	 $rootScope.$broadcast('error_hide');
				    	     $scope.getDimsumObj = pncsession.get(PNC_SESSION_CONFIG.GET_DIMSUMEVENTS);
				    	     $scope.getDimsumData($scope.getDimsumObj[0],'initial');
				            },function(err){
	                          console.log(err);
	                          $rootScope.$broadcast('error_show',err.data);
				        });

				        $scope.getDimsumData = function (data,mode) {
				        	$rootScope.$broadcast('error_hide');
			        	    $scope.selectedValue = data.forecastPurpose;
			        	    pncsession.update(PNC_SESSION_CONFIG.SELECTED_RUNPLANFORECAST, data.forecastPurpose);
			        	    var userID = pncsession.get(PNC_SESSION_CONFIG.LOGGEDIN_USER_INFO).user_Details.userCd;
			        	    $scope.exportObj = {
			        	    	forecastPurpose : data.forecastPurpose,
			        	    	userCd : userID,
			        	    	columnClass : 'runId',
						    	isFilter : false,
						    	filterData : []
			        	    }
			        	    pncServices.getDimsumRunList(data.forecastPurpose).then(function(data){
			        	    	$rootScope.$broadcast('loader_show');
			    	  	        $scope.isInit = true;
                               if(mode){
                                	generateDimsumTable();
                                }else{
                                	function getUpdatedDimsumTable(){
										var deferred = $q.defer();
										var tableData = pncsession.get(PNC_SESSION_CONFIG.GET_DIMSUMDATA);
										if(tableData.length === 0){
                                             $scope.isDisabled = true;
										}else{
                                            $scope.isDisabled = false;
										}
										deferred.resolve(tableData);
										return deferred.promise;
								    }
                                	$scope.dtInstance.changeData(getUpdatedDimsumTable);
                                	$timeout(function(){
                                        pncServices.generateDTCustomFilters($scope.dtInstance,$compile,$scope);
                                        pncServices.preferedColumns($scope.dtInstance,$compile,$scope,noOfColumns,hideColumns);
                                        $rootScope.$broadcast('loader_hide');
                                    },100)
			        	             /*$scope.dtInstance.rerender(); 
			        	             $timeout(function(){
                                        pncServices.generateDTCustomFilters($scope.dtInstance,$compile,$scope);
                                        pncServices.preferedColumns($scope.dtInstance,$compile,$scope,noOfColumns,hideColumns);
                                        $rootScope.$broadcast('loader_hide');
                                    },100)*/
                                }
			    	  		},function (err) {
			    	  			$scope.isError = true;
			    	  			$scope.errorQueue = err.data.message;
			    	  		})
				        }
                        $scope.getPrefernces = function(){
						 $scope.hideshowFlag = !$scope.hideshowFlag;
						 $rootScope.$broadcast('getPrefernces',{});

					    };
				        function generateDimsumTable(){
                                var message = "<h4 class='printMsg'>Forecast Purpose:</h4>";
				        	    $scope.dtOptions = DTOptionsBuilder.fromFnPromise(function () {
                                              return getDimsumTableData();
					  	              		}).withPaginationType('numbers')
				        	    .withOption('info',false).withDisplayLength(15)
											.withOption('fnCreatedRow',function(nRow, aData, iDataIndex){ var receivedData = aData.received.split('~');
												 var receivedData = aData.received.split('~');												 
												 var expectedData = aData.expected.split('~');
                                                 var errorData = aData.errors.split('~');
												  $('td:eq(5)', nRow).html( '<span class="colorColumn" style="background-color:'+receivedData[0]+'">&nbsp;</span>' );
												  $('td:eq(6)', nRow).html( '<span class="colorColumn" style="background-color:'+expectedData[0]+'">&nbsp;</span>' );
												  $('td:eq(7)', nRow).html( '<span class="colorColumn" style="background-color:'+errorData[0]+'">&nbsp;</span>' );
											})
											.withOption('order', [[3, 'asc'], [4, 'asc']])
											.withButtons([{
											 extend:'print',
											 title:"Dimsum Monitoring Data",
											 message:message,
											 exportOptions : {
                                                 columns : [0,1,2,3,4,8,9,10,11,12,13,14,{search:'applied'}]
											 },
											 className:'printButton',
											 text:"Print",
											 customize:function(win){
											 	    var selectObj =  pncsession.get(PNC_SESSION_CONFIG.SELECTED_RUNPLANFORECAST);
								                    $(win.document.body).find('.printMsg').html('Forecast Purpose:'+selectObj);
													$(win.document.body).find('table').css({'margin':'0px','padding':'0px','border-collapse':'collapse','width':'80%'}).addClass('compact').css('font-size','inherit');
													$(win.document.body).find('table,table td,table th').css('border','1px solid black')
													$(win.document.body).find('th,td').css({'margin':'0px','padding':'0px'})
													$(win.document.body).find('td').css({'word-break':'break-all','white-space':'pre-wrap','word-wrap':'break-word','min-width':'50px'})
												}
											}])

							    $scope.dtColumns=[
							        DTColumnBuilder.newColumn('forecastType').withTitle('Forecast Type'),
							        DTColumnBuilder.newColumn('runName').withTitle('Run Name').withClass('runId'),
							        DTColumnBuilder.newColumn('runType').withTitle('Run Type'),
							        DTColumnBuilder.newColumn('scenario').withTitle('Scenario'),
							        DTColumnBuilder.newColumn('displayMode').withTitle('Display Mode'),
							        DTColumnBuilder.newColumn('mrmgModelId').withTitle('MRMG Model ID'),
							        DTColumnBuilder.newColumn('modelName').withTitle('Model Name'),
							        DTColumnBuilder.newColumn('runId').withTitle('Run ID').withClass('runId'),
							        DTColumnBuilder.newColumn('received').withTitle('Received').withClass('text-center received'),
							        DTColumnBuilder.newColumn('expected').withTitle('Expected').withClass('text-center expected'),
							        DTColumnBuilder.newColumn('errors').withTitle('Errors').withClass('text-center errors'),
							        DTColumnBuilder.newColumn('receivedDateTime').withTitle('Received Date Time').withClass('dimsum_DT'),
							        DTColumnBuilder.newColumn('receivedFlag').withTitle('Received').withClass('text-center').withOption('visible',false),
							        DTColumnBuilder.newColumn('expectedFlag').withTitle('Expected').withClass('text-center').withOption('visible',false),
							        DTColumnBuilder.newColumn('errorsFlag').withTitle('Errors').withClass('text-center').withOption('visible',false),  
							    ];

							    function getDimsumTableData () {
							    	var deferred = $q.defer();
			                       	var tableData = pncsession.get(PNC_SESSION_CONFIG.GET_DIMSUMDATA);
			                       	if(tableData.length === 0){
                                             $scope.isDisabled = true;
										}else{
                                            $scope.isDisabled = false;
										}
			                        deferred.resolve(tableData);
			                        return deferred.promise;
							    }

							    $scope.dtInstanceCallback = function (dtInstance) {
				                           $scope.dtInstance = dtInstance;
				                           pncServices.generateDTCustomFilters(dtInstance,$compile,$scope);
				                           pncServices.preferedColumns(dtInstance,$compile,$scope,noOfColumns,hideColumns);
				                           $rootScope.$broadcast('loader_hide');
				                           
								}

				        }

				        

				        

    }])
	
})();