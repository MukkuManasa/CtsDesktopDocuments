"use strict";
(function(){
  angular.module('PNCApp.modelExecutionModule').controller('meMyQueueCtrl',
  	['$scope','DTOptionsBuilder','DTColumnBuilder','pncServices','PNC_CONSTANT','pncsession','PNC_SESSION_CONFIG','$q','$state','$window','$compile','$uibModal','$timeout','$rootScope',
  	              function($scope,DTOptionsBuilder,DTColumnBuilder,pncServices,PNC_CONSTANT,pncsession,PNC_SESSION_CONFIG,$q,$state,$window,$compile,$uibModal,$timeout,$rootScope){
  	              	$scope.isInit = false;
  	              	$scope.isDisabled = false;
  	              	$scope.isErrorShow = false;
  	              	$scope.abbr = $state.current.abbr;

  	              	 function getMyQueueTable(){
					    var message = "<h4 class='printMsg'>Forecast Purpose:</h4>"
  	              	 	$scope.scrollbarFilterConfig = {
								axis:"y",
						    	autoHideScrollbar:false,
						    	theme:"dark",
						    	autoDraggerLength:true,
						    	scrollButtons:{
						    		enable: false 
						    	}
				        }
  	              		$scope.dtOptions = DTOptionsBuilder.fromFnPromise(function(){
                                  return getTableData();
  	              		}).withPaginationType('numbers').withButtons([{
							extend:'print',
							title:"My Queue",
							message:message,
							className:'printButton',
							exportOptions: {
				                    columns: ':visible'
				            },
							text:"Print",
							customize:function(win){
								var selectObj =  pncsession.get(PNC_SESSION_CONFIG.SELECTED_EVENT_OBJ);
								 $(win.document.body).find('.printMsg').html('Forecast Purpose:'+selectObj.eventName);
								$(win.document.body).find('table').css({'margin':'0px','padding':'0px','border-collapse':'collapse','width':'80%'}).addClass('compact').css('font-size','inherit');
							    $(win.document.body).find('table,table td,table th').css('border','1px solid black')
								
							}
						}]).withOption('info',false).withDisplayLength(15).withOption('fnCreatedRow',function(nRow, aData, iDataIndex){
							 $(nRow).attr('ng-click','openQueueModal($event)').attr('processid',aData.processId);
							 $compile(nRow)($scope);
							 return nRow;
						});
						$scope.dtColumns=[
					        DTColumnBuilder.newColumn('executionType').withTitle('Execution Type'),
					        DTColumnBuilder.newColumn('controlID').withTitle('ID').withClass('controlId'),
					        DTColumnBuilder.newColumn('startDate').withTitle('Start Date').withClass('mq_shortColumn'),
					        DTColumnBuilder.newColumn('dueDate').withTitle('Due Date').withClass('mq_shortColumn'),
					        DTColumnBuilder.newColumn('controlGroupOwner').withTitle('Control Group Owner'),
					        DTColumnBuilder.newColumn('controlExecuterId').withTitle('Control Executor').withClass('mq_shortColumn'),
					        DTColumnBuilder.newColumn('controlReviewerId').withTitle('Control Reviewer').withClass('mq_shortColumn'),
					        DTColumnBuilder.newColumn('controlGroup').withTitle('Control Group').withClass('mq_shortColumn'),
					        DTColumnBuilder.newColumn('processId').withTitle('Process Id').withClass('processId').withOption('visible',false),
					        DTColumnBuilder.newColumn('control').withTitle('Control Status').withClass('mq_shortColumn')
					    ];
					     function getTableData(){
					     	var deferred = $q.defer();
	                       	var tableData = pncsession.get(PNC_SESSION_CONFIG.GET_MYQUEUE);
	                       	if(tableData.length === 0){
                                             $scope.isDisabled = true;
										}else{
                                            $scope.isDisabled = false;
										}
	                         deferred.resolve(tableData);
	                         return deferred.promise;
	                       
				    	}
				    	$scope.dtInstanceCallback = function(dtInstance){
		                           $scope.dtInstance = dtInstance;
		                           pncServices.generateDTCustomFilters(dtInstance,$compile,$scope);
		                           

						}

  	              	 }
  	              		

					$scope.$on("getMyQueueData",function(event,args){
						$scope.getQueueData(args.data);
					})

					pncServices.getForecastDropDown().then(function(data){
						 $rootScope.$broadcast('error_hide');
			    	     $scope.getEventsObj  = pncsession.get(PNC_SESSION_CONFIG.GET_EVENTS);
			    	     $scope.getQueueData($scope.getEventsObj[0],'initial');
			         },function(err){
                        console.log(err);
                        $rootScope.$broadcast('error_show',err.data);
			        });
             

					$scope.getQueueData = function(eventObj,mode){
						$rootScope.$broadcast('error_hide');
						pncsession.update(PNC_SESSION_CONFIG.SELECTED_EVENT_OBJ,eventObj);
						$scope.isInit = false;
						 $scope.selectedValue = eventObj.eventName;
						 var userID = pncsession.get(PNC_SESSION_CONFIG.LOGGEDIN_USER_INFO).user_Details.userCd;
						 $scope.exportObj = {
						 	userCd : userID,
						 	eventId : eventObj.eventId,
						 	columnClass : 'processId',
					    	isFilter : false,
					    	filterData : []
						 }
				    	  pncServices.getMyQueue(userID,eventObj.eventId).then(function(data){
				    	  	    $scope.isInit = true;

				    	  	    if(mode){
				    	  	    	getMyQueueTable();
				    	  	    }else{
                                    function getUpdatedMyQueueTable(){
										var deferred = $q.defer();
										var tableData = pncsession.get(PNC_SESSION_CONFIG.GET_MYQUEUE);
										if(tableData.length === 0){
                                             $scope.isDisabled = true;
										}else{
                                            $scope.isDisabled = false;
										}
										deferred.resolve(tableData);
										return deferred.promise;
								    }
                                	$scope.dtInstance.changeData(getUpdatedMyQueueTable);
                                	$timeout(function(){
                                        pncServices.generateDTCustomFilters($scope.dtInstance,$compile,$scope);
                                    },100)
				    	  	    }    
				    	  },function(err){
				    	  	$scope.isErrorShow = true;
				    	  	$scope.errorQueue = err.data.message;
				    	  })
					}

					$scope.openQueueModal = function($event){
						var processId = $($event.currentTarget).attr('processid');
						var userID = pncsession.get(PNC_SESSION_CONFIG.LOGGEDIN_USER_INFO).user_Details.userCd;
  					    pncServices.showModel(userID,processId).then(function(data){
  					    	$rootScope.$broadcast('error_hide');
					 	    if(data.length!=0){
					 	    	data.abbr = $scope.abbr;
					 	    	data.trigger = "myQueue";
							    var modalInstance = $uibModal.open({
							      templateUrl:"views/modalPopUp.html",
							      controller:'modalPopUpCtrl',
							      resolve: {
							        data: function () {
							          return data;
							        }
							      }	,
							      backdrop : 'static'
							    });
						    }
				        },function(err){
				    	    $rootScope.$broadcast('error_show',err.data);
				    	  	
				    	})
					}


					

  }])
	
})();
