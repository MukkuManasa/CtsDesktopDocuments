	"use strict";
	(function(){
		angular.module('PNCApp.modelExecutionModule').controller('modalPopUpCtrl',['$scope','$uibModalInstance','pncServices','pncsession','PNC_SESSION_CONFIG','data','$rootScope','$templateRequest','$compile','DTOptionsBuilder','DTColumnBuilder','$q',
			function($scope,$uibModalInstance,pncServices,pncsession,PNC_SESSION_CONFIG,data,$rootScope,$templateRequest,$compile,DTOptionsBuilder,DTColumnBuilder,$q){
				
				var flag=false;
				$scope.displayFlag = false;
				$scope.executeFlag = true;
				$scope.reviewFlag = true;
				$scope.rejectFlag = true;
				$scope.executeDisableFlag=false;
				$scope.reviewerDisableFlag=false;
				$scope.filePathDisableFlag=false;
				$scope.abbr = data.abbr;
				var trigger = data.trigger;
				var userID = pncsession.get(PNC_SESSION_CONFIG.LOGGEDIN_USER_INFO).user_Details.userCd;
				var processStatus = data[0].processStatus;
				var currentUser = data[0].approverID;
				if (processStatus == "Reviewed" ||  processStatus == "Not Applicable" || userID != currentUser) {
					$scope.executeFlag = false;
					$scope.reviewFlag = false;
					$scope.rejectFlag = false;
					$scope.executeDisableFlag=true;
					$scope.reviewerDisableFlag=true;
					$scope.filePathDisableFlag=true;
	            }else{
	            	if (data[0].reviewerName == null || data[0].reviewerName == "") {
									$scope.reviewFlag = true;
									$scope.reviewFlag = false;
									$scope.rejectFlag = false;
									$scope.reviewerDisableFlag=false;
	                                $scope.executeDisableFlag=true;                             
	                            } else if (processStatus == "Not Started") {
									$scope.executeFlag = true;
									$scope.reviewFlag = false;
									$scope.rejectFlag = false;
									$scope.executeDisableFlag=false;
	                                $scope.reviewerDisableFlag=true;

	                            } else if (processStatus == "Executed") {

									$scope.reviewFlag = true;
									$scope.rejectFlag = true;
									$scope.executeFlag = false;
									$scope.reviewerDisableFlag=false;
	                                $scope.executeDisableFlag=true;             
	                            } else if (processStatus == "Rejected") {
	                            	
	                            	$scope.executeFlag = true;
	                            	$scope.reviewFlag = false;
	                            	$scope.rejectFlag = false;
	                            	$scope.executeDisableFlag=false;
	                            	$scope.reviewerDisableFlag=true;
	                            }
	                        }
	                        $scope.modelData=data[0];
	                        if($scope.modelData.documentationFilePath === null){
	                        	$scope.modelData.documentationFilePath = '';
	                        }
	                        if($scope.modelData.executorComments === null){
	                        	$scope.modelData.executorComments = '';
	                        }
	                        if($scope.modelData.approverComments === null){
	                        	$scope.modelData.approverComments = '';
	                        }
	                        $scope.cancel = function () {
	                        	$uibModalInstance.dismiss('cancel');
	                        }
                            $scope.updatePopupScrollbar = null;
	                        $scope.scrollBarYConfig = {
						    	axis:"y",
						    	autoHideScrollbar:false,
						    	theme:"dark",
						    	autoDraggerLength:true,
						    	scrollButtons:{
						    		enable: false 
						    	},
						    	callbacks:{
						    		onUpdate:function(){
						    			$scope.updatePopupScrollbar("scrollTo",['bottom',null])
						    		}
				    	        }
						    }
						    $scope.scrollBarCDSectionConfig = {
						    	axis:"y",
						    	autoHideScrollbar:false,
						    	theme:"dark",
						    	autoDraggerLength:true,
						    	scrollButtons:{
						    		enable: false 
						    	}
						    }
						    $scope.scrollBarCASectionConfig = {
						    	axis:"y",
						    	autoHideScrollbar:false,
						    	theme:"dark",
						    	autoDraggerLength:true,
						    	scrollButtons:{
						    		enable: false 
						    	}
						    }
                            
	                        $scope.approveProcess = function(form,event){	
	                        	$scope.submitted = true;
	                        	if(form.$valid){
	                        	var ProcessPojo={}
	                        	ProcessPojo.processId = data[0].processId;
	                        	ProcessPojo.executorComments = $("#executorComments").val();
	                        	ProcessPojo.approverComments = $("#reviewerComments").val();
	                        	ProcessPojo.documentationFilePath = $("#filepath").val();
	                        	ProcessPojo.processStatus = event.target.id;
	                        	ProcessPojo.delegateTo = "";
	                        	ProcessPojo.userId = userID;
	                        	ProcessPojo.reviewerName = data[0].reviewerName;
	                        	ProcessPojo.ownerName = data[0].ownerName;
	                        	ProcessPojo.controlExecutorEmail = data[0].controlExecutorEmail;
	                        	ProcessPojo.controlReviewerEmail  = data[0].controlReviewerEmail;
	                        	ProcessPojo.processName = data[0].processName;

	                        	pncServices.approveProcess(ProcessPojo).then(function(data){
	                        		$rootScope.$broadcast('error_hide');
	                        		$uibModalInstance.dismiss('cancel');
	                        		var selectObj = pncsession.get(PNC_SESSION_CONFIG.SELECTED_EVENT_OBJ);
	                        		if(trigger === "charts"){
	                        		  $rootScope.$broadcast('getChartData', { data: selectObj});
	                        		}else if(trigger === "myQueue"){
	                        		   $rootScope.$broadcast('getMyQueueData', { data: selectObj});
	                        		}

	                        		 
	                        	},function(err){
	                        		$uibModalInstance.dismiss('cancel');
	                        		$rootScope.$broadcast('error_show',err.data);
	                        	})
	                           }

	                        };
	                        $scope.showAudit = function(){
	                        	if(flag == false){
	                        	pncServices.getProcessAuditData(userID,data[0].processId).then(function(data){
	                        		$rootScope.$broadcast('error_hide');
	                        		/*pncsession.update(PNC_SESSION_CONFIG.AUDIT_DATA,data);*/
	                        		flag=true;
	                        		checkForAuditData(pncsession.get(PNC_SESSION_CONFIG.AUDIT_DATA));
	                        		
	                        		$scope.displayFlag =  true;
	                        		
	                        	},function(err){
	                        		console.log(err);
	                        		$rootScope.$broadcast('error_show',err.data);
	                        	})
	                        }
	                        else{
	                        	checkForAuditData(pncsession.get(PNC_SESSION_CONFIG.AUDIT_DATA));
	                        	$scope.displayFlag =  true;
	                        		$scope.displayAuditFlag = false;
	                        }
	                        	
	                        };
	                        function checkForAuditData(auditData){
	                        	$scope.dtOptions = DTOptionsBuilder.fromFnPromise(getTableData()).withOption('drawCallback', drawCallback).withPaginationType('numbers').withOption('info',false).withDisplayLength(2).withOption('bSort',false);
	                        		$scope.dtColumns=[
	                        		DTColumnBuilder.newColumn('processStatus').withTitle('Process Status'),
	                        		DTColumnBuilder.newColumn('reviewerName').withTitle('Executor Name'),
	                        		DTColumnBuilder.newColumn('ownerName').withTitle('Reviewer Name'),
	                        		DTColumnBuilder.newColumn('updatedBy').withTitle('Updated By'),
	                        		DTColumnBuilder.newColumn('updatedDate').withTitle('Updated Date'),
	                        		DTColumnBuilder.newColumn('executorComments').withTitle('Executor Comments'),
	                        		DTColumnBuilder.newColumn('approverComments').withTitle('Approver Comments')

	                        		];
	                        		function getTableData(){
	                        			var deferred = $q.defer(),
	                        			tableData = auditData;
	                        			deferred.resolve(tableData);
	                        			return deferred.promise;
	                        		}
	                        		 
   								   function drawCallback( settings ) {
   								    $compile($(settings.nTableWrapper.lastChild).append('<div class="backBttn"><button class="orangeButton normFont" ng-click="hideAudit()">Back</button></div>'))($scope);

    								}
                                    
    								
	                        }
	                        $scope.hideAudit = function(){
	                        	$scope.displayFlag = false;	                    	
	                        };


	                    }])


})();