"use strict";
 angular.module('PNCApp.administrationModule').controller('addRolePopupCtrl', ['$scope','$uibModalInstance','pncServices','data','$rootScope','PNC_SESSION_CONFIG','pncsession',
 	function($scope,$uibModalInstance,pncServices,data,$rootScope,PNC_SESSION_CONFIG,pncsession) {
 		var loop;
 		var statusListLength;
 		var roleLength;
 		var mode = data.mode;
 		var data = data.data;
 		var userId=pncsession.get(PNC_SESSION_CONFIG.LOGGEDIN_USER_INFO).user_Details.userCd;
 		$scope.treeObj = data.roleResouceMstList;
 		$scope.newRole = {};
 		if(mode === "EDIT"){
 			$scope.newRole = data;
 			$scope.updatedFlag=true;
 			$scope.addFlag = false;
 			$scope.statusList=["YES","NO"];
 			statusListLength = $scope.statusList.length;
 			for(loop=0;loop<statusListLength;loop++){
 				if($scope.statusList[loop]==data.isActiveFlag){
 					$scope.newRole.isActiveFlag=$scope.statusList[loop];
 				}
 			}
 			$scope.disableFlag=true;
 			
 		}else if(mode === "ADD"){
 			$scope.updatedFlag=false;
 			$scope.addFlag = true;
 			$scope.statusList=["YES","NO"];
 			$scope.newRole.isActiveFlag=$scope.statusList[0];
 			$scope.newRole.startDttm=data.startDttm;
 			$scope.newRole.endDttm=data.endDttm;
 			$scope.newRole.lastUpdated=data.lastUpdated;
 			$scope.newRole.roleResouceMstList=data.roleResouceMstList;
 			$scope.newRole.updatedByUserCd=userId;
 			$scope.disableFlag=false;
 		}
 				
				$scope.cancel = function () {
	                $uibModalInstance.dismiss('cancel');
	            };
	            $scope.hasError = function(field, validation){
	            	if(validation){
	            		return ($scope.form[field].$touched && $scope.form[field].$error[validation]) || ($scope.submitted && $scope.form[field].$error[validation]);
	            	}
	            	return ($scope.form[field].$touched && $scope.form[field].$invalid) || ($scope.submitted && $scope.form[field].$invalid);
	            };
	            $scope.AddRole =  function(form){
	            	$scope.submitted = true;
	            	if(form.$valid){
	            		angular.extend($scope.newRole.roleResouceMstList,$scope.treeObj);
	            	pncServices.createRole($scope.newRole).then(function(data){
	            		$uibModalInstance.dismiss('cancel');
	            		$rootScope.$broadcast('error_hide');
	            		$rootScope.$broadcast('getrolesTable', { data: data });
				},function(err){
				$uibModalInstance.dismiss('cancel');
				$rootScope.$broadcast('error_show',err.data);
				});
        			
        		}
	            }	
	            $scope.update =  function(form){
	            	$scope.submitted = true;
	            	if(form.$valid){
                        angular.extend($scope.newRole.roleResouceMstList,$scope.treeObj);
	            		pncServices.updateRole($scope.newRole).then(function(data){
	            		$rootScope.$broadcast('error_hide');
	            		$uibModalInstance.dismiss('cancel');
	            		$rootScope.$broadcast('getrolesTable', { data: data });
						},function(err){
						$uibModalInstance.dismiss('cancel');
						$rootScope.$broadcast('error_show',err.data);
						});
	            	}
	            };
	            $scope.CheckRoleID = function(field,role){
	            	var roles=pncsession.get(PNC_SESSION_CONFIG.GETROLES_DATA);
	            		if(roles!== undefined && role !== undefined){
	            			roleLength = roles.length;
							for(loop=0;loop<roleLength;loop++){
									if(role.toUpperCase()==(roles[loop].roleCd).toUpperCase()){
										return true;
									}
							}
						}
					

	            }

	            $scope.scrollBarYConfig= {
					axis:"y",
					autoHideScrollbar:false,
					theme:"dark",
					autoDraggerLength:true,
					scrollButtons:{
						enable: false 
					}
				}			
}])