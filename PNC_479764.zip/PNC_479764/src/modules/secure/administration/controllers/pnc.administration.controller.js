"use strict";
 angular.module('PNCApp.administrationModule')
		.controller('administrationCtrl', ['$scope','$state','PNC_CONSTANT','pncsession','PNC_SESSION_CONFIG',
			function($scope,$state,PNC_CONSTANT,pncsession,PNC_SESSION_CONFIG) {
			
				$scope.pncConstants = PNC_CONSTANT;
			    $scope.userInfo = pncsession.get(PNC_SESSION_CONFIG.LOGGEDIN_USER_INFO);
			    $scope.currentState='administration';
			    $scope.currentSubState = $state.current.name;
			    $scope.currentSubStateAbbr = $state.current.abbr;
			    
			     $scope.action = function(value){
	                     $scope.userInfo.default_Role = value;
	                     $state.go('landing')
				    }

				 $scope.className = $state.current.class;

				 $scope.scrollBarYConfig = {
			    	axis:"y",
			    	autoHideScrollbar:false,
			    	theme:"dark",
			    	autoDraggerLength:true,
			    	scrollButtons:{
			    		enable: false 
			    	}
			    }
			    
			    $scope.subMenuObj =  $scope.userInfo.assigned_Resources[$scope.userInfo.default_Role].filter(function(d){
                            if(d.menuShortName === $scope.pncConstants[$scope.currentState]){
                               return d;
                            }
                          
				})
				/*clearing below session objects because its dependency on preffered columns*/
				pncsession.remove(PNC_SESSION_CONFIG.HIDECOLUMN_DATA);
				pncsession.remove(PNC_SESSION_CONFIG.PREFERED_DATA);

}])