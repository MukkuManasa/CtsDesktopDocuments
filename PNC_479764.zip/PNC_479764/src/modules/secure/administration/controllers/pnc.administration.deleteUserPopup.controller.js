"use strict";
angular.module('PNCApp.administrationModule').controller('deleteUserPopupCtrl', ['$scope','$uibModalInstance','pncServices','$rootScope','pncsession','PNC_SESSION_CONFIG','id','flag',
 	function($scope,$uibModalInstance,pncServices,$rootScope,pncsession,PNC_SESSION_CONFIG,id,flag) {
 		$scope.cancelConfirmation = function () {
	                $uibModalInstance.dismiss('cancel');
	            };
	            $scope.deleteConfirmation = function(){
	            		$uibModalInstance.dismiss('cancel');
						pncServices.deleteUser(id,flag).then(function(data){
							$rootScope.$broadcast('error_hide');
							$rootScope.$broadcast('getuserTable',{data:data});

						},function(err){
							$rootScope.$broadcast('error_show',err.data);
						});

					};
 }])