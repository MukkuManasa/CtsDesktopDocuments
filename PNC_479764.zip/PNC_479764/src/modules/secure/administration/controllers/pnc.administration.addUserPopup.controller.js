"use strict";
 angular.module('PNCApp.administrationModule').controller('addUserPopupCtrl', ['$scope','$uibModalInstance','pncServices','data','$rootScope','pncsession','PNC_SESSION_CONFIG',
 	function($scope,$uibModalInstance,pncServices,data,$rootScope,pncsession,PNC_SESSION_CONFIG) {
 		$scope.checkedArray=[];
 		$scope.formatFlag = false;
 		$scope.options={ "eventsToHandle": [ "input", "click"],clearOnBlur: false,addDefaultPlaceholder:false,clearOnBlurPlaceholder:true};
 		
 		if(data!==undefined){
 			$scope.newUser = data;
 			$scope.newUser.mobileNoTxt = data.mobileNoTxt;
 			if(data.roleList!==null){
				$scope.roleList = data.roleList.split(",");
			}
			$scope.roles=[];
 			var roles=pncsession.get(PNC_SESSION_CONFIG.GETROLESFORUSER_DATA);
 			if(roles!==undefined){
 				var roleLength=roles.length;
 				var loop;
	 			for(loop=0;loop<roleLength;loop++){
	 				$scope.roles.push(roles[loop].roleCd);
	 			}
 			}
 			$scope.roles=removeDuplicates($scope.roles);
			$scope.checkedArray=$scope.roleList;
			$scope.models = [];
 			var models = pncsession.get(PNC_SESSION_CONFIG.GETMODELSFORUSER_DATA);
 			if(models !== undefined){
 				for(var i in models){
 					var obj ={
 						modelId : models[i].mrmgModelId,
 						modelName : models[i].modelName
 					}
 					$scope.models.push(obj)
 				}
 			}
 			if(data.modelID !== null){
				$scope.modelList = data.modelID.split(",");
				getCheckedModelList(); //this method is to make checkable based on modelList
			}
			$scope.defaultRole=data.defaultRole;
 			$scope.updatedFlag=true;
 			$scope.addFlag = false;
 			$scope.statusList=["YES","NO"];
 			for(var i=0;i<$scope.statusList.length;i++){
 				if($scope.statusList[i]==data.isDeletedFlag){
 					$scope.newUser.isDeletedFlag=$scope.statusList[i];
 				}
 			}
 			$scope.disableFlag=true;
 			
 		}else{
 			$scope.disableFlag=false;
 			$scope.roles=[];
 			var roles=pncsession.get(PNC_SESSION_CONFIG.GETROLESFORUSER_DATA);
 			if(roles!==undefined){
	 			for(var i=0;i<roles.length;i++){
	 				$scope.roles.push(roles[i].roleCd);
	 			}
	 		}
 			$scope.roles=removeDuplicates($scope.roles);
 			$scope.models = [];
 			var models = pncsession.get(PNC_SESSION_CONFIG.GETMODELSFORUSER_DATA);
 			if(models !== undefined){
 				for(var i in models){
 					var obj ={
 						modelId : models[i].mrmgModelId,
 						modelName : models[i].modelName
 					}
 					$scope.models.push(obj)
 				}
 			}
 			$scope.updatedFlag=false;
 			$scope.addFlag = true;
 			$scope.newUser = {};
				$scope.newUser.officeAddrTxt=null;
				$scope.newUser.mailingAddrTxt=null;
				$scope.newUser.mobileNoTxt=null;
				$scope.statusList=["YES","NO"];
 			$scope.newUser.isDeletedFlag=$scope.statusList[0];
 		}
 		$scope.scrollBarYConfig= {
					axis:"y",
					autoHideScrollbar:false,
					theme:"dark",
					autoDraggerLength:true,
					scrollButtons:{
						enable: false 
					}
				}
				$scope.scrollbarRoleConfig= {
					axis:"y",
					autoHideScrollbar:false,
					theme:"dark",
					autoDraggerLength:true,
					scrollButtons:{
						enable: false 
					}
				}
				$scope.scrollbarModelConfig= {
					axis:"y",
					autoHideScrollbar:false,
					theme:"dark",
					autoDraggerLength:true,
					scrollButtons:{
						enable: false 
					}
				}
 				
		
       $scope.getSelectedArea = function(event){  	
            var position=$(event.currentTarget).getCursorPosition();
            $(event.currentTarget).selectRange(position-1,position);
       
        	}
			
				$scope.cancel = function () {
	                $uibModalInstance.dismiss('cancel');
	            };
	            $scope.hasError = function(field, validation){
	            	if(validation){
	            		return ($scope.form[field].$touched && $scope.form[field].$error[validation]) || ($scope.submitted && $scope.form[field].$error[validation]);
	            	}
	            	return ($scope.form[field].$touched && $scope.form[field].$invalid) || ($scope.submitted && $scope.form[field].$invalid);
	            };
	            $scope.AddUser =  function(form){
	            	 $scope.submitted = true;
	            	 $scope.newUser.modelID = getSelectedModels(form);
	            	if(form.$valid){
	            		$scope.newUser.defaultRole=$scope.defaultRole;
	            	pncServices.saveUsers($scope.newUser).then(function(data){
	            		$uibModalInstance.dismiss('cancel');
	            		$rootScope.$broadcast('error_hide');
	            		$scope.newUser = {};
	            	$rootScope.$broadcast('getuserTable', { data: data });
				},function(err){
				$uibModalInstance.dismiss('cancel');
				$rootScope.$broadcast('error_show',err.data);
				});
        			
        		}
	            };	
	            $scope.update = function(form){ 
			            $scope.submitted = true; 
			            $scope.newUser.modelID = getSelectedModels(form);
			            if(form.$valid){
			             $scope.newUser.defaultRole=$scope.defaultRole;	
			            	pncServices.updateUser($scope.newUser).then(function(data){
			            		$rootScope.$broadcast('error_hide');
			            		$uibModalInstance.dismiss('cancel');
			            		$rootScope.$broadcast('getuserTable',{data:data});
						},function(err){
						$uibModalInstance.dismiss('cancel');
						$rootScope.$broadcast('error_show',err.data);
						});
			            }
	            };
	            $scope.getPreferedRole = function(role,$event){
	            	$scope.checkedArray=[];
	            	var roles='';
	            	var selectedRole = $($event.target).prop('checked');
	            	var checkedArray = $('.rolePreference').find('ul input:checked');
	            	if(checkedArray.length){
	            	    checkedArray.each(function(i){
		            		$scope.checkedArray.push($(checkedArray[i]).val());
		            		if(i>0){
	      					 roles += ','; 
	    					}
	    					roles += $(checkedArray[i]).val();
	    				 	$scope.newUser.roleList=roles;
	            	    })
	            	    if(selectedRole === false && role === $scope.defaultRole){
	            	    	$scope.defaultRole = null;
	            	    }

		            }
		            else{
		            	$scope.newUser.roleList=null;
		            	$scope.defaultRole=null;
		            }

	            };	
	            $scope.CheckUserID = function(field,userId){
	            	var users=pncsession.get(PNC_SESSION_CONFIG.GET_USER_DATA);
	            		if(users!==undefined && userId !== undefined){
	            			var usersLength=users.length;
	            			var loop;
							for(loop=0;loop<usersLength;loop++){
									if(userId.toUpperCase()==(users[loop].userCd).toUpperCase()){
										return true;
									}
							}
						}
					

	            }
	           
	            function removeDuplicates(arr) {
					var i, j, cur, found;
					for ( i = arr.length - 1; i >= 0; i--) {
						cur = arr[i];
						found = false;
						for ( j = i - 1; !found && j >= 0; j--) {
							if (cur === arr[j]) {
								if (i !== j) {
								arr.splice(i, 1);
								}
								found = true;
							}
						}
					}
					return arr;
				};

				function getSelectedModels(form){
                  var selectedModels="";
                  angular.forEach($scope.models,function(model){
                  	if(model.selected){
                  		selectedModels += model.modelId + ","
                  	}
                  })
                 var result = selectedModels.substr(0,selectedModels.length-1);
                 if(result=== ""){
                 	$scope.modelInvalid = true;
                 	form.$valid = false;
                 }else{
                 	$scope.modelInvalid = false;
                 }
                 return result;
				}
				function getCheckedModelList(){
					var matchedArr = [];
					angular.forEach($scope.modelList,function(modelId){
                       $scope.models.filter(function(d){
                       	  if(d.modelId === modelId){
                       	  	 d.selected = true;
                       	  }
                       })
					})
					
				}


}])