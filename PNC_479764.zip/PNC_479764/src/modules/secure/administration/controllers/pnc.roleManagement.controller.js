"use strict";
angular.module('PNCApp.administrationModule')
.controller('roleManagementCtrl', ['$scope','$uibModal','pncServices','$compile','$state','PNC_CONSTANT','pncsession','PNC_SESSION_CONFIG','DTOptionsBuilder','DTColumnBuilder','DTColumnDefBuilder','$q','$rootScope','$timeout',
	function($scope,$uibModal,pncServices,$compile,$state,PNC_CONSTANT,pncsession,PNC_SESSION_CONFIG,DTOptionsBuilder,DTColumnBuilder,DTColumnDefBuilder,$q,$rootScope,$timeout) {
		$scope.displayFlag=false;
		$scope.hideshowFlag=false;
		$scope.abbr = $state.current.abbr;
		$scope.input = {};
		$scope.scrollbarHorizontalConfig = {
			axis:"x",
			autoHideScrollbar:false,
			theme:"dark",
			autoDraggerLength:true,
			scrollButtons:{
				enable: false 
			}
		}
		$scope.scrollbarVerticalConfig = {
			axis:"y",
			autoHideScrollbar:false,
			theme:"dark",
			autoDraggerLength:true,
			scrollButtons:{
				enable: false 
			}
		}
	    $scope.exportObj = {
		    	userCd  : pncsession.get(PNC_SESSION_CONFIG.LOGGEDIN_USER_INFO).user_Details.userCd,
		    	eventId : '',
		    	columnClass : 'roleCd',
		    	isFilter : false,
		    	filterData : []
			}
		$scope.className = $state.current.class;
		$scope.$on('getrolesTable', function(event,args){
				      getRoles("UPDATE");
				      pncsession.update(PNC_SESSION_CONFIG.UPDATEDELETEFLAG, true);
				  });
		function getRoles(mode){
			pncServices.getRoles().then(function(data){
				$rootScope.$broadcast('error_hide');
				$scope.displayFlag=true;
				if(mode === "Existed"){
					drawTable(data);
				}else if(mode === "UPDATE"){
								function getUpdatedTable(){
									var deferred = $q.defer(),
									tableData = data;
									deferred.resolve(tableData);
									return deferred.promise;
								}
								$scope.dtInstance.changeData(getUpdatedTable);
                                pncsession.update(PNC_SESSION_CONFIG.UPDATEDELETEFLAG, false);
                                $timeout(function(){
                                  pncServices.generateDTCustomFilters($scope.dtInstance,$compile,$scope);
                                  pncServices.editDeleteButtons($scope.dtInstance,$compile,$scope);
                                },100)
                                $rootScope.$broadcast('loader_hide');
							}
			},function(err){
				console.log(err);
				$rootScope.$broadcast('error_show',err.data);
			});
		}
		getRoles("Existed");

				    	$scope.addRolePopupOpen = function(){
				    		pncServices.getResources().then(function(data){
				    			$rootScope.$broadcast('error_hide');
				    			var obj = {
				    				data: data,
				    				mode:'ADD'
				    			}
				    			var modalInstance = $uibModal.open({
					    			templateUrl:"modules/secure/administration/views/addRolePopup.html",
					    			controller:'addRolePopupCtrl',
					    			resolve: {
					    				data: function () {
					    					return obj;
					    				}
					    			},
					    			backdrop : 'static' 	
				    		    });
				    		},function(err){
                              console.log(err);
				              $rootScope.$broadcast('error_show',err.data);
				    		})
				    		
				    	}

				    	$scope.scrollbarFilterConfig = {
				    		axis:"y",
				    		autoHideScrollbar:false,
				    		theme:"dark",
				    		autoDraggerLength:true,
				    		scrollButtons:{
				    			enable: false 
				    		}
				    	}
				    	function drawTable(data){
				    		var oTable = $('#dataTable').dataTable();
				    		oTable.fnClearTable();
				    		oTable.fnAddData(data);
				    		oTable.fnDraw();
				    		$scope.dtOptions = DTOptionsBuilder.fromFnPromise(getTableData()).withOption('info',false).withPaginationType('numbers').withDisplayLength(15).withButtons([{
				    				extend:'print',
				    				title:"Role Management",
				    				className:'printButton',
				    				text:"Print",
				    				exportOptions: {
				                    columns: ':visible'
				                    },
				    				customize:function(win){
				    					$(win.document.body).find('table').css({'margin':'0px','padding':'0px','border-collapse':'collapse','width':'80%'}).addClass('compact').css('font-size','inherit');
							            $(win.document.body).find('table,table td,table th').css('border','1px solid black')
							            $(win.document.body).find('th,td').css({'margin':'0px','padding':'0px'})
							            $(win.document.body).find('td').css({'word-break':'break-all','white-space':'pre-wrap','word-wrap':'break-word','min-width':'100px'})
				    				}
				    			}]);
				    			$scope.dtColumns=[
				    			DTColumnBuilder.newColumn('roleCd').withTitle('Role').withOption('class','roleCd'),
				    			DTColumnBuilder.newColumn('roleDescTxt').withTitle('Role Description'),
				    			DTColumnBuilder.newColumn('commentTxt').withTitle('Comment'),
				    			DTColumnBuilder.newColumn('isActiveFlag').withTitle('Active').withClass('text-center'),
				    			DTColumnBuilder.newColumn('lastUpdated').withTitle('Last Updated'),
				    			DTColumnBuilder.newColumn('updatedByUserCd').withTitle('Last Updated By')        
				    			];

				    			function getTableData(){
				    				var deferred = $q.defer(),
				    				tableData = data;
				    				deferred.resolve(tableData);
				    				return deferred.promise;
				    			}
				    			$scope.dtInstanceCallback = function(dtInstance){
				    				$scope.dtInstance = dtInstance;
	                         		pncServices.generateDTCustomFilters(dtInstance,$compile,$scope);
	                         		pncServices.editDeleteButtons(dtInstance,$compile,$scope);
	                     		}
			                    var unwatchSearch = $scope.$watch("input.searchVal",function(newVal,oldVal){ 
												       if(newVal !== oldVal){
														  if($scope.dtInstance){
															var table = $scope.dtInstance.DataTable;
															table.search($scope.input.searchVal).draw();
																	}
																}
											    		});

							$scope.clearSearch = function(){
						    	$scope.input.searchVal="";
						    }
			                $scope.$on('$destroy',function(){
			                	unwatchSearch();
			                })	
	                 }
	                 $scope.editRow = function(event){
	                 	pncServices.getRoleById($scope.id).then(function(data){
	                 		$rootScope.$broadcast('error_hide');
	                 		var obj = {
	                 			data:data,
	                 			mode:"EDIT"
	                 		}
	                 		var modalInstance = $uibModal.open({
	                 			templateUrl:"modules/secure/administration/views/addRolePopup.html",
	                 			controller:'addRolePopupCtrl',
	                 			resolve: {
	                 				data: function () {
	                 					return obj;
	                 				}
	                 			},
	                 			backdrop : 'static' 
	                 		});

	                 	},function(err){
	                 		console.log(err);
	                 		$rootScope.$broadcast('error_show',err.data);
	                 	});

	                 };
	                 $scope.deleteRow = function(event){
	                 			var modalInstance = $uibModal.open({
								templateUrl:"modules/secure/administration/views/deletePopup.html",
								controller:'deleteRolePopupCtrl',
								resolve: {
										id: function () {
											return $scope.id;
										},
										flag: function () {
											return $scope.isFlag;
										},
									},
								backdrop : 'static',
								windowClass :'addModelDialogueWidth'
								});

	                 		};


	             }])