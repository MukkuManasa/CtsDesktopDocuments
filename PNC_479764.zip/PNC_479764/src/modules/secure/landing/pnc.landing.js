'use strict';
(function(){
angular.module('PNCApp.landingModule',['ui.router','datatables','datatables.buttons','angular-svg-round-progress','ngScrollbars',
			'ngIdle'])
.config(['$stateProvider','$urlRouterProvider','IdleProvider',function($stateProvider,$urlRouterProvider,IdleProvider){
   $stateProvider.state('landing',{
   	   url:'/landing',
   	   templateUrl:'modules/secure/landing/views/landing.html',
   	   controller:'landingCtrl'
   })
    IdleProvider.idle(15 * 60) //15 minutes of idle time;
 }])
.run(['$rootScope','$state','pncsession','$location','PNC_SESSION_CONFIG','Idle','pncServices',
	function($rootScope,$state,pncsession,$location,PNC_SESSION_CONFIG,Idle,pncServices){
		
        $rootScope.$on('IdleStart',function(){
        	var loginPageRedirectFlag = pncsession.get(PNC_SESSION_CONFIG.LOGGEDIN_USER_INFO).login_page_redirect;
               	    pncServices.logout()
						.then(function(data){			 			
							if(data.isLogoutSuccess){
								if(loginPageRedirectFlag){
									$state.go('login',{timeout: true});
								}else{
									$state.go('appStatus',{sessionTimeout:true});
								}
								
							}
						},function(err){
							console.log(err);

						});
        })
	}])
	
})();