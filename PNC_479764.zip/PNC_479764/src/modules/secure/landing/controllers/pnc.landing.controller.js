"use strict";
 angular.module('PNCApp.landingModule')
		.controller('landingCtrl', ['$scope','DTOptionsBuilder','DTColumnBuilder','pncServices','PNC_CONSTANT','pncsession','PNC_SESSION_CONFIG','$q','$state','$window','$compile','Idle',
		 function($scope,DTOptionsBuilder,DTColumnBuilder,pncServices,PNC_CONSTANT,pncsession,PNC_SESSION_CONFIG,$q,$state,$window,$compile,Idle) {
                Idle.watch()
                $scope.input={};
		 		$scope.isDisabled = false;
		 		$scope.currentState=$state.current.name;
		 		$scope.getMyQueue = function (){
					var userID = pncsession.get(PNC_SESSION_CONFIG.LOGGEDIN_USER_INFO).user_Details.userCd;
					pncServices.getMyQueue(userID,'')
								.then(function(data){
									$scope.isInitQueue = true;
									initiateLandingPage();
									 },function(err){				 	
		 		                        $scope.isInitQueue = false;
									 	$scope.errorQueue = err.data.message;
								 	console.log(err);
								 });
				}

			 	$scope.getTaskMeter = function (){
					var userID = pncsession.get(PNC_SESSION_CONFIG.LOGGEDIN_USER_INFO).user_Details.userCd;
					pncServices.getTaskMeter(userID)
								.then(function(data){
									$scope.isTaskMeterInit = true;
									updateTaskMeter();									
								 },function(err){
								    $scope.isTaskMeterInit = false;
								 	console.log(err);
								 	$scope.errorTaskMater = err.data.message;
								 });
				}

		 		if(pncsession.get(PNC_SESSION_CONFIG.LOGGEDIN_USER_INFO) && pncsession.get(PNC_SESSION_CONFIG.LOGGEDIN_USER_INFO).user_Details.userCd){
		 			initateHeader();
		 			$scope.getMyQueue();
		 			$scope.getTaskMeter();
		 		}
		 		else{
		 			pncServices.isSingleSignOn()
		 				.then(function(data){			 			
					 	if(!(data.isSingleSignOn)){
					 		/*change below code based on singlesignonflag*/
					 		var loginPageRedirectFlag = data.login_page_redirect;
					 		if(loginPageRedirectFlag){
					 			$state.go('login',{loginFailed: true});
					 		}else{
					 			$state.go('appStatus',{ssoFailed:true})
					 		}
					 		
					 	}else{
					 		getLoggedInUserInfo();
					 	}
					 },function(err){
					 	console.log(err);
					 	
					 });
		 		}

		 		function getLoggedInUserInfo() {
			 		pncServices.loggedInUserInfo()
			 			.then(function(data){
			 			initateHeader();
					 	$scope.getMyQueue();
					 	$scope.getTaskMeter();
					 },function(err){
					 	console.log(err);
					 });
			 	}

				
				function initiateLandingPage(){
					
					$scope.scrollbarFilterConfig = {
						axis:"y",
				    	autoHideScrollbar:false,
				    	theme:"dark",
				    	autoDraggerLength:true,
				    	scrollButtons:{
				    		enable: false 
				    	}
				    }

					$scope.dtOptions = DTOptionsBuilder.fromFnPromise(getTableData()).withPaginationType('numbers').withButtons([{
						    extend:'print',
						    title:"My Queue",
						    className:'printButton',
						    text:"Print",
						    exportOptions: {
				                    columns: ':visible'
				            },
						    customize:function(win){
							$(win.document.body).find('table')
							.css({'margin':'0px','padding':'0px','border-collapse':'collapse','width':'90%'}).addClass('compact').css('font-size','inherit');
							 $(win.document.body).find('table,table td,table th').css('border','1px solid black')
							 
							
						}
					}]).withOption('info',false).withDisplayLength(15);
					$scope.dtColumns=[
				        DTColumnBuilder.newColumn('executionType').withTitle('Execution Type'),
				        DTColumnBuilder.newColumn('controlID').withTitle('ID').withOption('class','controlId'),
				        DTColumnBuilder.newColumn('startDate').withTitle('Start Date').withClass('mq_shortColumn'),
				        DTColumnBuilder.newColumn('dueDate').withTitle('Due Date').withClass('mq_shortColumn'),
				        DTColumnBuilder.newColumn('controlGroupOwner').withTitle('Control Group Owner'),
				        DTColumnBuilder.newColumn('controlExecuterId').withTitle('Control Executor').withClass('mq_shortColumn'),
				        DTColumnBuilder.newColumn('controlReviewerId').withTitle('Control Reviewer').withClass('mq_shortColumn'),
				        DTColumnBuilder.newColumn('controlGroup').withTitle('Control Group').withClass('mq_shortColumn'),
				        DTColumnBuilder.newColumn('control').withTitle('Control Status').withClass('mq_shortColumn'),
				        DTColumnBuilder.newColumn('processId').withTitle('Process Id').withClass('processId').withOption('visible',false)
				    ];

				    function getTableData(){
                       var deferred = $q.defer(),
                       tableData = pncsession.get(PNC_SESSION_CONFIG.GET_MYQUEUE);
                       deferred.resolve(tableData);
                       return deferred.promise;
			    	}

			    	
				    
					$scope.dtInstanceCallback = function(dtInstance){
	                           $scope.dtInstance = dtInstance;
	                           pncServices.generateDTCustomFilters(dtInstance,$compile,$scope);
	                           if(pncsession.get(PNC_SESSION_CONFIG.GET_MYQUEUE).length === 0){
		                           	   $scope.isDisabled = true;
		                        }

					}
					
				    var unwatchSearch = $scope.$watch("input.searchVal",function(newVal,oldVal){ 
					       if(newVal !== oldVal){
							  if($scope.dtInstance){
								var table = $scope.dtInstance.DataTable;
								table.search($scope.input.searchVal).draw();
								}
							}
		    		});

					$scope.clearSearch = function(){
				    	$scope.input.searchVal="";
				    }
                    $scope.$on('$destroy',function(){
                    	unwatchSearch();
                    })

				    $scope.exportObj = {
				    	userCd  : pncsession.get(PNC_SESSION_CONFIG.LOGGEDIN_USER_INFO).user_Details.userCd,
				    	eventId : '',
				    	columnClass : 'processId',
				    	isFilter : false,
				    	filterData : []
				    }
				    				  
				}

				function updateTaskMeter(){
					$scope.isCollapsed = true;
					$scope.taskMeter = pncsession.get(PNC_SESSION_CONFIG.TASK_METER);
					$scope.toggleChart = function(){
						$scope.isCollapsed = !$scope.isCollapsed;
					}
				}

				function initateHeader(){
					$scope.pncConstants = PNC_CONSTANT;
				    $scope.userInfo = pncsession.get(PNC_SESSION_CONFIG.LOGGEDIN_USER_INFO);
				    $scope.action = function(value){
	                     $scope.userInfo.default_Role = value;
	                     $state.go('landing')
				    }

				}
               
              
				
			    
                /*radialChart button toggle */
				
}]);


