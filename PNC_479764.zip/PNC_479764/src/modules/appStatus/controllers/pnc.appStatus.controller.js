"use strict";
 angular.module('PNCApp.appStatusModule')
		.controller('appStatusCtrl', ['$scope','pncServices','PNC_CONSTANT','pncsession','PNC_SESSION_CONFIG','$q','$state','$stateParams','Idle',
		 function($scope,pncServices,PNC_CONSTANT,pncsession,PNC_SESSION_CONFIG,$q,$state,$stateParams,Idle) {
		 	Idle.unwatch();
              $scope.message = "";
              if($stateParams.fromApp){
              	$scope.message = "You have successfully logged out.";
              }else if($stateParams.sessionTimeout){
              	$scope.message = "You session has expired, Please login again.";
              }else if($stateParams.ssoFailed){
              	$scope.message = "Access Denied! Please contact Administrator to get the access to portal.";
              }
				
}]);