'use strict';
(function(){
angular.module('PNCApp.appStatusModule',[])
.config(['$stateProvider','$urlRouterProvider',function($stateProvider,$urlRouterProvider){
   $stateProvider.state('appStatus',{
   	   url:'/appStatus?fromApp&ssoFailed&sessionTimeout',
   	   templateUrl:'modules/appStatus/views/appStatus.html',
   	   controller:'appStatusCtrl'
   })
 }]);


})();