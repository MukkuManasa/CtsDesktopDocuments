"use strict";
(function(){
angular.module('PNCApp.loginModule')
.controller('LoginController',['$scope','$state','pncServices','$base64','pncsession','$q','PNC_SESSION_CONFIG',
	'$stateParams','Idle','$uibModalStack',function($scope,$state,pncServices,$base64,pncsession,$q,PNC_SESSION_CONFIG,$stateParams,Idle,$uibModalStack){
	    Idle.unwatch();
	  	//health check on page load
		pncServices.healthCheck();

		pncServices.isLoginFlowAllowed().then(function(data){
	         if(data.login_page_redirect === "false"){
	         	$state.go('appStatus',{ssoFailed:true});
	         }        
		    },function(err){
			    console.log(err)
		})

		$scope.errorMessage = "";

		$uibModalStack.dismissAll(); 

		if($stateParams.loginFailed){
			$scope.errorMessage = "Unable to authenticate with your SSO Id.Please contact Administrator";
		}

		if($stateParams.timeout){
			$scope.errorMessage = "Session has expired, Please login again";
		}

	  $scope.login = function(form){
	  	
	  	if(form.$valid){		     
		     var data = {};
			 data.username = angular.lowercase($scope.userName);
			 data.password = $base64.encode(angular.lowercase($scope.password));
			 pncServices.login(data)
			 	.then(function(data){
				 	pncsession.update('isLogged',true);
				 	$state.go('landing');
				 },function(err){
				 	if(err.errorCode == 401){
						$scope.errorMessage = "Invalid username or password";
				 	}
				 	console.log(err);
				 });
		}	
	
	  };  
}])

})();