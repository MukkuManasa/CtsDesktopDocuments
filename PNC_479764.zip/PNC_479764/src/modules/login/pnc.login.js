'use strict';
(function(){
angular.module('PNCApp.loginModule',['ui.router'])
.config(['$stateProvider','$urlRouterProvider',function($stateProvider,$urlRouterProvider){    
    $stateProvider.state('login',{
   	    url:'/login?loginFailed&timeout',
   	    templateUrl : 'modules/login/views/login.html',
   	    controller:'LoginController'
 	})

 	$urlRouterProvider.otherwise('/login');
 }]);
})();