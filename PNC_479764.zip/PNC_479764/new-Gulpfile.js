var gulp = require('gulp');

gulp.task('one', function(){

	console.log("Task running....");
});

