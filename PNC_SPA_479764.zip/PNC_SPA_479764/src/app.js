"use strict";
angular.module('PNCApp',
		[
			'PNCApp.loginModule',
			'PNCApp.landingModule',
			//'PNCApp.AnalysisModule',
			'PNCApp.modelExecutionModule',
			'PNCApp.technicaldifficultiesModule',
			'ui.bootstrap',
			'PNCApp.services',
			'base64',
			'ngStorage',
			'PNCAppDirectives',
			'pncMockService',
			'ngCookies',
			'PNCApp.administrationModule',
			'PNCAppFilters'
			])
.run(['$rootScope','$state','pncsession','$location','PNC_SESSION_CONFIG', 
	function($rootScope,$state,pncsession,$location,PNC_SESSION_CONFIG){

		$rootScope.$on('technicaldifficulties',function(event){
			$state.go('technicaldifficulties');
		});

		$rootScope.$on('pnc_logout',function(event){
			pncsession.removeAll();
			$state.go('login',{timeout: true});
		});


	    $rootScope.$on('$stateChangeStart', function (event,toState,toParams,fromState,fromParams) {
	    	
	    	if($location.search().isSingleSign){
	    		pncsession.update('isLogged',true);
	    	}
	    	
	      var isLogged=pncsession.get('isLogged');
	       var redirectPath = angular.isUndefined(isLogged) ? false : true;
	       var techinicalFlag =angular.isUndefined(pncsession.get(PNC_SESSION_CONFIG.SHOW_TECHNCALDIFFICULTIES)) ? false : true;
	      if(redirectPath && toState.name=="login"){
	          event.preventDefault();
	          if(fromState.name!="" ){
	          $state.go(fromState.name);
	              }
	        else if(fromState.name==""){
	          $state.go('landing');
	        }
	      }
	     
	      else{
	      	if(!redirectPath){
	      	event.preventDefault();
	      	 $state.go('login', toParams, {notify: false}).then(function() {
	                            $rootScope.$broadcast('$stateChangeSuccess', toState, toParams, fromState, fromParams);
	                        });
	        return;
	      }else{
	        event.preventDefault();
	        $state.go(toState.name, toParams, {notify: false}).then(function() {
	                            $rootScope.$broadcast('$stateChangeSuccess', toState, toParams, fromState, fromParams);
	                        });
	        return;
	      }
	  }
	    });
	}]);
