"use strict";
(function(){
angular.module('PNCApp.loginModule')
.controller('LoginController',['$scope','$state','pncServices','$base64','pncsession','$q','PNC_SESSION_CONFIG',
	'$stateParams','Idle',function($scope,$state,pncServices,$base64,pncsession,$q,PNC_SESSION_CONFIG,$stateParams,Idle){
	    Idle.unwatch();
	  	//health check on page load
		pncServices.healthCheck();

		$scope.errorMessage = "";

		if($stateParams.loginFailed){
			$scope.errorMessage = "Unable to authenticate with your SSO Id.Please contact Administrator";
		}

		if($stateParams.timeout){
			$scope.errorMessage = "Session has expired, Please login again";
		}

	  $scope.login = function(form){
	  	
	  	if(form.$valid){		     
		     var data = {};
			 data.username = angular.lowercase($scope.userName);
			 data.password = $base64.encode(angular.lowercase($scope.password));
			 pncServices.login(data)
			 	.then(function(data){
				 	pncsession.update('isLogged',true);
				 	$state.go('landing');
				 },function(err){
				 	if(err.errorCode == 401){
						$scope.errorMessage = "Invalid username or password";
				 	}
				 	console.log(err);
				 });
		}	
	
	  };  
}])

})();