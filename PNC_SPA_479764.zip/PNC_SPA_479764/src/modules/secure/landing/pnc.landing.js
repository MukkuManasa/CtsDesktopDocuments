'use strict';
(function(){
angular.module('PNCApp.landingModule',['ui.router','datatables','datatables.buttons','angular-svg-round-progress','ngScrollbars',
			'ngIdle'])
.config(['$stateProvider','$urlRouterProvider','IdleProvider',function($stateProvider,$urlRouterProvider,IdleProvider){
   $stateProvider.state('landing',{
   	   url:'/landing',
   	   templateUrl:'modules/secure/landing/views/landing.html',
   	   controller:'landingCtrl'
   })
    IdleProvider.idle(15*60) //5 minutes of idle time;
 }])
.run(['$rootScope','$state','pncsession','$location','PNC_SESSION_CONFIG','Idle','pncServices',
	function($rootScope,$state,pncsession,$location,PNC_SESSION_CONFIG,Idle,pncServices){
        $rootScope.$on('IdleStart',function(){
               	    pncServices.logout()
						.then(function(data){			 			
							if(data.isLogoutSuccess){
								$state.go('login',{timeout: true});
							}
						},function(err){
							console.log(err);

						});
        })
	}])
	
})();