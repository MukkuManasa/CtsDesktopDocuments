'use strict';
(function(){
angular.module('PNCApp.technicaldifficultiesModule',['ui.router','datatables','datatables.buttons','angular-svg-round-progress'])
.config(['$stateProvider','$urlRouterProvider',function($stateProvider,$urlRouterProvider){
   $stateProvider.state('technicaldifficulties',{
   	   url:'/technicaldifficulties',
   	   templateUrl:'modules/secure/technical-difficulties/views/technicaldifficulties.html',
   	   controller:'technicaldifficultiesCtrl'
   })
 }]);


})();