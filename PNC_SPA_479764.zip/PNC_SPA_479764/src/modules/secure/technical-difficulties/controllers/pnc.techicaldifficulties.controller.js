"use strict";
 angular.module('PNCApp.technicaldifficultiesModule')
		.controller('technicaldifficultiesCtrl', ['$scope','pncServices','PNC_CONSTANT','pncsession','PNC_SESSION_CONFIG','$q','$state',
		 function($scope,pncServices,PNC_CONSTANT,pncsession,PNC_SESSION_CONFIG,$q,$state) {
                
				
}]);