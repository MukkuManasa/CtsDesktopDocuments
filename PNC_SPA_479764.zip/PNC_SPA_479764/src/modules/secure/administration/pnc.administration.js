'use strict';
(function(){
angular.module('PNCApp.administrationModule',['ui.router','datatables','datatables.buttons','ngScrollbars','ngMessages'])
.config(['$stateProvider','$urlRouterProvider',function($stateProvider,$urlRouterProvider){
   $stateProvider.state('administration',{
   	   url:'/administration',
   	   templateUrl:'modules/secure/administration/views/administration.html',
   	   controller:'administrationCtrl'
   })
   .state('administration.userManagement',{
   	   url:'/userManagement',
   	   templateUrl:'modules/secure/administration/views/userManagement.html',
   	   controller:"adminManagementCtrl",
   	   class:"userManagement"
    })
   .state('administration.roleManagement',{
   	   url:'/roleManagement',
   	   templateUrl:'modules/secure/administration/views/roleManagement.html',
   	   controller:"roleManagementCtrl",
   	   class:"roleManagement"
   })
 }])
	
})();