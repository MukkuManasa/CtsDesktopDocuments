"use strict";
 angular.module('PNCApp.administrationModule').controller('addRolePopupCtrl', ['$scope','$uibModalInstance','pncServices','data','$rootScope','PNC_SESSION_CONFIG','pncsession',
 	function($scope,$uibModalInstance,pncServices,data,$rootScope,PNC_SESSION_CONFIG,pncsession) {
 		var loop;
 		var statusListLength;
 		var roleLength;
 		if(data!=undefined){
 			$scope.newRole = data;
 			$scope.updatedFlag=true;
 			$scope.addFlag = false;
 			$scope.statusList=["YES","NO"];
 			statusListLength = $scope.statusList.length;
 			for(loop=0;loop<statusListLength;loop++){
 				if($scope.statusList[loop]==data.isActiveFlag){
 					$scope.newRole.isActiveFlag=$scope.statusList[loop];
 				}
 			}
 			$scope.disableFlag=true;
 			
 		}else{
 			$scope.newRole = {};
 			$scope.updatedFlag=false;
 			$scope.addFlag = true;
 			$scope.statusList=["YES","NO"];
 			$scope.newRole.isActiveFlag=$scope.statusList[0];
 			$scope.disableFlag=false;
 		}
 				
				$scope.cancel = function () {
	                $uibModalInstance.dismiss('cancel');
	            };
	            $scope.hasError = function(field, validation){
	            	if(validation){
	            		return ($scope.form[field].$touched && $scope.form[field].$error[validation]) || ($scope.submitted && $scope.form[field].$error[validation]);
	            	}
	            	return ($scope.form[field].$touched && $scope.form[field].$invalid) || ($scope.submitted && $scope.form[field].$invalid);
	            };
	            $scope.AddRole =  function(form){
	            	$scope.submitted = true;
	            	if(form.$valid){
	            	pncServices.createRole($scope.newRole).then(function(data){
	            		$uibModalInstance.dismiss('cancel');
	            		$rootScope.$broadcast('getrolesTable', { data: data });
				},function(err){
				$uibModalInstance.dismiss('cancel');
				$rootScope.$broadcast('error_show',err.data);
				});
        			$scope.newRole = {};
        		}
	            }	
	            $scope.update =  function(form){
	            	$scope.submitted = true;
	            	if(form.$valid){
	            		pncServices.updateRole($scope.newRole).then(function(data){
	            		$uibModalInstance.dismiss('cancel');
	            		$rootScope.$broadcast('getrolesTable', { data: data });
						},function(err){
						$uibModalInstance.dismiss('cancel');
						$rootScope.$broadcast('error_show',err.data);
						});
        				$scope.newRole = {};
	            	}
	            };
	            $scope.CheckRoleID = function(field,role){
	            	var roles=pncsession.get(PNC_SESSION_CONFIG.GETROLES_DATA);
	            		if(roles!=undefined || roles!==null){
	            			roleLength = roles.length;
							for(loop=0;loop<roleLength;loop++){
									if(role==(roles[loop].roleCd)){
										return true;
									}
							}
						}
					

	            }			
}])