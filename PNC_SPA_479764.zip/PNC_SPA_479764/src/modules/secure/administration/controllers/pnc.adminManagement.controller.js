			"use strict";
			angular.module('PNCApp.administrationModule')
			.controller('adminManagementCtrl', ['$scope','$uibModal','pncServices','$compile','$state','PNC_CONSTANT','pncsession','PNC_SESSION_CONFIG','DTOptionsBuilder','DTColumnBuilder','DTColumnDefBuilder','$q','$rootScope','$timeout',
				function($scope,$uibModal,pncServices,$compile,$state,PNC_CONSTANT,pncsession,PNC_SESSION_CONFIG,DTOptionsBuilder,DTColumnBuilder,DTColumnDefBuilder,$q,$rootScope,$timeout) {
					$scope.displayFlag=false;
					$scope.hideshowFlag=false;
					$scope.scrollbarHorizontalConfig = {
						axis:"x",
						autoHideScrollbar:false,
						theme:"dark",
						autoDraggerLength:false,
						scrollButtons:{
							enable: false 
						}
					}
					
					$scope.className = $state.current.class;
					$scope.$on('getuserTable', function(event,args){
						      getUsers("UPDATE");
						      pncsession.update(PNC_SESSION_CONFIG.UPDATEDELETEFLAG, true);
					});
					function getUsers(mode){
						pncServices.getUsers().then(function(data){
							$scope.displayFlag=true;
							$rootScope.$broadcast('loader_show');
							if(mode === "ADD"){
								drawTable(data);
							}else if(mode === "UPDATE"){
								function getUpdatedTable(){
									var deferred = $q.defer(),
									tableData = data;
									deferred.resolve(tableData);
									return deferred.promise;
								}
								$scope.dtInstance.changeData(getUpdatedTable);
                                pncsession.update(PNC_SESSION_CONFIG.UPDATEDELETEFLAG, false);
                                $timeout(function(){
                                  pncServices.editDeleteButtons($scope.dtInstance,$compile,$scope);
                                },100)
                                $rootScope.$broadcast('loader_hide');
							}
							
						},function(err){
							console.log(err);
							$rootScope.$broadcast('error_show',err.data);
						});
					}
					getUsers("ADD");

				$scope.addUserPopupOpen = function(){
					pncServices.getRolesForUser().then(function(data){
						var modalInstance = $uibModal.open({
							templateUrl:"modules/secure/administration/views/editUserInfoPopup.html",
							controller:'addUserPopupCtrl',
							resolve: {
								data: function () {
									return undefined;
								}
							},
							backdrop : 'static' 
						});
					},function(err){
						console.log(err);
						$rootScope.$broadcast('error_show',err.data);
					});

				};


				$scope.scrollbarFilterConfig = {
					axis:"y",
					autoHideScrollbar:false,
					theme:"dark",
					autoDraggerLength:false,
					scrollButtons:{
						enable: false 
					}
				}


				function drawTable(data){
					var oTable = $('#dataTable').dataTable();
					oTable.fnClearTable();
					oTable.fnAddData(data);
					oTable.fnDraw();

					$scope.dtOptions = DTOptionsBuilder.fromFnPromise(function(){
						return getTableData()
					}).withOption('info',false).withPaginationType('numbers').withDisplayLength(10).withButtons([{
						extend:'print',title:"User Management",className:'printButton',text:"Print",customize:function(win){
							$(win.document.body).find('table')
							.css({'margin':'0px','padding':'0px','border-collapse':'collapse','width':'80%'}).addClass('compact').css('font-size','inherit');
							 $(win.document.body).find('table,table td,table th').css('border','1px solid black')
							  $(win.document.body).find('th,td').css({'margin':'0px','padding':'0px'})
							  $(win.document.body).find('td').css({'word-break':'break-all','white-space':'pre-wrap','word-wrap':'break-word','min-width':'50px'})
							
						}
					}]);
					$scope.dtColumns=[
					DTColumnBuilder.newColumn('userCd').withTitle('ID').withOption("className","search-filter"),
					DTColumnBuilder.newColumn('firstNameTxt').withTitle('First Name').withOption("className","search-filter"),
					DTColumnBuilder.newColumn('middleNameTxt').withTitle('Middle Name'),
					DTColumnBuilder.newColumn('lastNameTxt').withTitle('Last Name'),
					DTColumnBuilder.newColumn('emailAddrTxt').withTitle('Email').withOption("className","search-filter"),
					DTColumnBuilder.newColumn('mailingAddrTxt').withTitle('Mailing Address'),
					DTColumnBuilder.newColumn('officeAddrTxt').withTitle('Office Address'),
					DTColumnBuilder.newColumn('mobileNoTxt').withTitle('Mobile No'),
					DTColumnBuilder.newColumn('officePhoneTxt').withTitle('Office No'),
					DTColumnBuilder.newColumn('homeNoTxt').withTitle('Home No'),
					DTColumnBuilder.newColumn('isDeletedFlag').withTitle('Active'),
					DTColumnBuilder.newColumn('lastUpdated').withTitle('Last Updated'),
					DTColumnBuilder.newColumn('lastUpdatedByUserCd').withTitle('Updated By')

					];

					function getTableData(){
						var deferred = $q.defer(),
						tableData = data;
						deferred.resolve(tableData);
						return deferred.promise;
					}
					
					$scope.dtInstanceCallback = function(dtInstance){
						$scope.dtInstance = dtInstance;
						pncServices.generateDTCustomFilters(dtInstance,$compile,$scope);
						pncServices.editDeleteButtons(dtInstance,$compile,$scope);
						
			                $rootScope.$broadcast('loader_hide');
			        	
					}
					$scope.searchDT = function(){
						var table = $scope.dtInstance.DataTable;
						//table.columns([1,0]).search($scope.input.searchVal).draw();
    					table.search($scope.input.searchVal).draw();
    				};
    				
					}

					$scope.getPrefernces = function(){
						$scope.hideshowFlag = !$scope.hideshowFlag;
						 $rootScope.$broadcast('getPrefernces',{});

					};


			

			}])