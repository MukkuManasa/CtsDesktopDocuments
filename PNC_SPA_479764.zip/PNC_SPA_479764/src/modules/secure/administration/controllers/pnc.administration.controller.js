"use strict";
 angular.module('PNCApp.administrationModule')
		.controller('administrationCtrl', ['$scope','$state','PNC_CONSTANT','pncsession','PNC_SESSION_CONFIG',
			function($scope,$state,PNC_CONSTANT,pncsession,PNC_SESSION_CONFIG) {
			
				$scope.pncConstants = PNC_CONSTANT;
			    $scope.userInfo = pncsession.get(PNC_SESSION_CONFIG.LOGGEDIN_USER_INFO);
			    $scope.currentState='administration';
			    $scope.currentSubState = $state.current.name;
			     $scope.action = function(value){
	                     $scope.userInfo.default_Role = value;
	                     $state.go('landing')
				    }

				 $scope.className = $state.current.class;

				 $scope.scrollBarYConfig = {
			    	axis:"y",
			    	autoHideScrollbar:false,
			    	theme:"dark",
			    	autoDraggerLength:false,
			    	scrollButtons:{
			    		enable: false 
			    	}
			    }

}])