"use strict";
angular.module('PNCApp.administrationModule').controller('deleteRolePopupCtrl', ['$scope','$uibModalInstance','pncServices','$rootScope','pncsession','PNC_SESSION_CONFIG','id','flag',
 	function($scope,$uibModalInstance,pncServices,$rootScope,pncsession,PNC_SESSION_CONFIG,id,flag) {
 		$scope.cancelConfirmation = function () {
	                $uibModalInstance.dismiss('cancel');
	            };
	            $scope.deleteConfirmation = function(){
	            		$uibModalInstance.dismiss('cancel');
						pncServices.deleteRole(id,flag).then(function(data){
			                 		$rootScope.$broadcast('getrolesTable',{data:data});
			                 	},function(err){
			                 		$rootScope.$broadcast('error_show',err.data);
			                 	});

					};
 }])
