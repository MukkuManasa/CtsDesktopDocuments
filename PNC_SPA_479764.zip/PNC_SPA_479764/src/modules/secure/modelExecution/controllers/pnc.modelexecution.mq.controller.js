"use strict";
(function(){
  angular.module('PNCApp.modelExecutionModule').controller('meMyQueueCtrl',
  	['$scope','DTOptionsBuilder','DTColumnBuilder','pncServices','PNC_CONSTANT','pncsession','PNC_SESSION_CONFIG','$q','$state','$window','$compile',
  	              function($scope,DTOptionsBuilder,DTColumnBuilder,pncServices,PNC_CONSTANT,pncsession,PNC_SESSION_CONFIG,$q,$state,$window,$compile){
  	              	$scope.isInit = false;
  	              	$scope.isDisabled = false;
			 		$scope.myQueueUrl="/service/exportMyQueue";
			 		$scope.pdfurl = "/service/exportMyQueuePDF";
  	              		$scope.scrollbarFilterConfig = {
						axis:"y",
				    	autoHideScrollbar:false,
				    	theme:"dark",
				    	autoDraggerLength:false,
				    	scrollButtons:{
				    		enable: false 
				    	}
				        }
  	              		$scope.dtOptions = DTOptionsBuilder.fromFnPromise(function(){
                                  return getTableData();
  	              		}).withPaginationType('numbers').withButtons([{
							extend:'print',title:"My Queue",className:'printButton',text:"Print",customize:function(win){
								$(win.document.body).find('table').css({'margin':'0px','padding':'0px','border-collapse':'collapse','width':'80%'}).addClass('compact').css('font-size','inherit');
							 $(win.document.body).find('table,table td,table th').css('border','1px solid black')
							  $(win.document.body).find('th,td').css({'margin':'0px','padding':'0px'})
								
							}
						}]).withOption('info',false).withDisplayLength(10).withOption('responsive', true);
						$scope.dtColumns=[
					        DTColumnBuilder.newColumn('executionType').withTitle('Execution Type'),
					        DTColumnBuilder.newColumn('controlID').withTitle('ID'),
					        DTColumnBuilder.newColumn('startDate').withTitle('Start Date'),
					        DTColumnBuilder.newColumn('dueDate').withTitle('Due Date'),
					        DTColumnBuilder.newColumn('controlGroupOwner').withTitle('Control Group Owner'),
					        DTColumnBuilder.newColumn('controlExecuterId').withTitle('Control Executor'),
					        DTColumnBuilder.newColumn('controlReviewerId').withTitle('Control Reviewer'),
					        DTColumnBuilder.newColumn('controlGroup').withTitle('Control Group'),
					        DTColumnBuilder.newColumn('control').withTitle('Control Status')
					    ];
					     function getTableData(){
					     	var deferred = $q.defer(),
	                       	    tableData = pncsession.get(PNC_SESSION_CONFIG.GET_MYQUEUE);
	                         deferred.resolve(tableData);
	                         return deferred.promise;
	                       
				    	}
				    	$scope.dtInstanceCallback = function(dtInstance){
		                           $scope.dtInstance = dtInstance;
		                           pncServices.generateDTCustomFilters(dtInstance,$compile,$scope);
		                           if(pncsession.get(PNC_SESSION_CONFIG.GET_MYQUEUE).length === 0){
		                           	   $scope.isDisabled = true;
		                           }

						}
					    $scope.searchDT = function(){
		                         var table = $scope.dtInstance.DataTable;
		                          table.search($scope.input.searchVal).draw();
					    }
  	              	

  	              	$scope.exportToExcel = function (){
					var userID = pncsession.get(PNC_SESSION_CONFIG.LOGGEDIN_USER_INFO).user_Details.userCd;
					pncServices.exportToExcel(userID)
								.then(function(data){
									var ua = window.navigator.userAgent;
                                    var msie = ua.indexOf("MSIE ");
                                    var blob = new Blob([data], {type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"});
                                    if(msie !== -1 || !!navigator.userAgent.match(/Trident.*rv\:11\./)){
                                    	window.navigator.msSaveBlob(blob, 'myqueue.xlsx');
                                    }else{
                                    	var objectUrl = $window.URL.createObjectURL(blob);
							            
								        $('body').append('<a id="download"></a>'); 
										      $('#download').attr('href', objectUrl);
										      $('#download').attr('download', 'myqueue.xlsx');
										      $('#download')[0].click();
										      $('#download').remove();

								        $window.URL.revokeObjectURL(objectUrl);

                                    }
								    //a.style = "display: none";
									
						            
								 },function(err){
								 	console.log(err);
								 });
				}

				$scope.exportToPDF = function (){
					var userID = pncsession.get(PNC_SESSION_CONFIG.LOGGEDIN_USER_INFO).user_Details.userCd;
					pncServices.exportToPDF(userID)
								.then(function(data){
									var ua = window.navigator.userAgent;
                                    var msie = ua.indexOf("MSIE ");
                                    var blob = new Blob([data], {type: "application/pdf"});
                                    if(msie !== -1 || !!navigator.userAgent.match(/Trident.*rv\:11\./)){
                                    	window.navigator.msSaveBlob(blob, 'myqueue.pdf');
                                    }else{
                                    	var objectUrl = $window.URL.createObjectURL(blob);
							            
								        $('body').append('<a id="download"></a>'); 
										      $('#download').attr('href', objectUrl);
										      $('#download').attr('download', 'myqueue.pdf');
										      $('#download')[0].click();
										      $('#download').remove();

								        $window.URL.revokeObjectURL(objectUrl);

                                    }
								 },function(err){
								 	console.log(err);
								 });
				}				
					   
					    
						
			    $scope.pncConstants = PNC_CONSTANT;
			    $scope.userInfo = pncsession.get(PNC_SESSION_CONFIG.LOGGEDIN_USER_INFO);
			    $scope.action = function(value){
                     $scope.userInfo.default_Role = value;
			    }

					pncServices.getForecastDropDown().then(function(data){
			    	     $scope.getEventsObj  = pncsession.get(PNC_SESSION_CONFIG.GET_EVENTS);
			    	     $scope.getQueueData($scope.getEventsObj[0]);
			         },function(err){
                        console.log(err);
			        });


					$scope.getQueueData = function(eventObj){
						pncsession.update(PNC_SESSION_CONFIG.SELECTED_EVENT_OBJ,eventObj);
						$scope.isInit = false;
						 $scope.selectedValue = eventObj.eventName;
						 var userID = pncsession.get(PNC_SESSION_CONFIG.LOGGEDIN_USER_INFO).user_Details.userCd;
				    	  pncServices.getMyQueue(userID,eventObj.eventId).then(function(data){
				    	  	    $scope.isInit = true;
                                 getTableData();
				    	  },function(err){
				    	  	$scope.errorQueue = err.data.code+" "+err.data.message;
				    	  })
					}
					

  }])
	
})();
