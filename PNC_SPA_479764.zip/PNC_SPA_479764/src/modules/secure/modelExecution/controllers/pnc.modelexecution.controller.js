"use strict";
(function(){
  angular.module('PNCApp.modelExecutionModule').controller('modelExecutionCtrl',['$scope','$uibModal','pncServices','PNC_CONSTANT','pncsession','PNC_SESSION_CONFIG','$q','$state',
  	              function($scope,$uibModal,pncServices,PNC_CONSTANT,pncsession,PNC_SESSION_CONFIG,$q,$state){
  	              	$scope.pncConstants = PNC_CONSTANT;
				    $scope.userInfo = pncsession.get(PNC_SESSION_CONFIG.LOGGEDIN_USER_INFO);
				    $scope.currentState='modelExecution';
				    $scope.currentSubState = $state.current.name;

				    $scope.action = function(value){
	                     $scope.userInfo.default_Role = value;
	                     $state.go('landing')
				    }

				    $scope.sendMail = function() {

				 		var userInfo = pncsession.get(PNC_SESSION_CONFIG.LOGGEDIN_USER_INFO);
				 		var fullName = "";
				 		if(userInfo.user_Details.firstNameTxt){
				 			fullName = userInfo.user_Details.firstNameTxt;
				 		}
				 		if(userInfo.user_Details.middleNameTxt){
				 			fullName += ' ' + userInfo.user_Details.middleNameTxt;
				 		}
				 		if(userInfo.user_Details.lastNameTxt){
							fullName += ' ' + userInfo.user_Details.lastNameTxt;
				 		}

				 		var toAddress = userInfo.user_Details.emailAddrTxt;
				 		var mailBody = [fullName];
				 		var mailInputParams = [userInfo.user_Details.userCd];

				 		pncServices.sendMail(toAddress, mailBody, mailInputParams)
				 			.then(function(data){
						 },function(err){
						 	console.log(err);
						 });
				 	}

				  /*modal Pop Up*/
				 
				  
									 
  }])
})();