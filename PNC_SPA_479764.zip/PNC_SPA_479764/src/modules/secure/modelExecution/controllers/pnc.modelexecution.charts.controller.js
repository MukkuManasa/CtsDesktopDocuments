"use strict";
(function(){
  angular.module('PNCApp.modelExecutionModule').controller('modelExecutionChartsCtrl',['$scope','$state','pncServices','pncsession','PNC_SESSION_CONFIG','$uibModal','$rootScope',
  	              function($scope,$state,pncServices,pncsession,PNC_SESSION_CONFIG,$uibModal,$rootScope){

  	              	$scope.isInit = false;
                    $scope.isDisabled = false;
                    	$scope.chartOptions = {
				    	gridsize: 40,
				    	spacing : 20
				    }
				    $scope.className = $state.current.class;
				    switch($scope.className){
  	              		case "controldashboard":
  	              		     $scope.dashboardUrl = "/service/getControlDashboard";
  	              		     $scope.dashboardPrintUrl = "/service/getControlDashboardReport";
  	              		break;
  	              		case "enterprisedashboard":
                             $scope.dashboardUrl = "/service/getEnterpriseDashBoard"
  	              		break;
  	              		case "statusdashboard":
                            $scope.dashboardUrl = "/service/getStatusDashboard"
                            $scope.dashboardPrintUrl = "/service/getStatusDashboardReport";    
  	              		break;

  	              	}
  	              	 $scope.scrollBarConfig = {
				    	axis:"y",
				    	autoHideScrollbar:false,
				    	theme:"dark",
				    	autoDraggerLength:false,
				    	scrollButtons:{
				    		enable: false 
				    	},
				    	callbacks:{
				    		onUpdate:function(){
				    			$scope.updateScrollbar("scrollTo",['bottom',null])
				    		},
				    		whileScrolling:function(){
				    			   if($('.StackedChartSection').length){
				    			   	var holderOffset = $('.StackedChartSection').height() + $('.StackedChartSection').offset().top;
				    			   	if($('#chart').find('.xaxis').length!==0){
				    			   	    var xaxisOffset = $('#chart').find('.xaxis').offset().top;
					    				    if(xaxisOffset >= holderOffset){
					    		    			$('.xAxisClone').removeClass('hideXaxis')
							    		    }else{
							    		    	$('.xAxisClone').addClass('hideXaxis')
							    		    }
							    	}
				    			   }
					    		   
				    		}
				    	}
				    }
				    $scope.scrollBarXConfig = {
				    	axis:"x",
				    	autoHideScrollbar:false,
				    	theme:"dark",
				    	autoDraggerLength:false,
				    	scrollButtons:{
				    		enable: false 
				    	},
				    	callbacks:{
				    		whileScrolling:function(){

				    			$('.xAxisClone').scrollLeft(-this.mcs.left); 
				    		}
				    	} 
				    }
			    	pncServices.getForecastDropDown().then(function(data){
			    	     $scope.getEventsObj  = pncsession.get(PNC_SESSION_CONFIG.GET_EVENTS);
			    	     $scope.getData($scope.getEventsObj[0]);
			         },function(err){
                        console.log(err);
                        $scope.isDisabled = true;
                        $scope.isChartInit = false;
                        $scope.chartError = err.data.message;
			        });
				    	
				  $scope.$on('getChartData', function(event, args){
				       $scope.getData(args.data);
				  });
                    $scope.getData = function(eventObj){
                    	 $scope.getChartData(eventObj);
                    	 if($scope.dashboardPrintUrl){
			    	     	$scope.getPrintChartData(eventObj);
			    	     }
                    }
				    $scope.getChartData = function(eventObj){
				    	pncsession.update(PNC_SESSION_CONFIG.SELECTED_EVENT_OBJ,eventObj);
                          $scope.isInit = false;
				    	  $scope.selectedValue = eventObj.eventName;
				    	  var userID = pncsession.get(PNC_SESSION_CONFIG.LOGGEDIN_USER_INFO).user_Details.userCd;
				    	  pncServices.getChartDashBoardData(userID,eventObj.eventId,$scope.dashboardUrl).then(function(data){
                                 $scope.chartOptions.ObjData = data;
                                 $scope.isInit = true;
                                 $scope.isChartInit = true;
                                 if(Object.keys(data).length === 0){
                                 	$scope.isDisabled = true;
                                 }
                                  
				    	  },function(err){
				    	  	$scope.isDisabled = true;
				    	  	$scope.isChartInit = false;
				    	  	$scope.chartError = err.data.message;
				    	  })

				    }
				    $scope.getPrintChartData = function(eventObj){
				    	  var userID = pncsession.get(PNC_SESSION_CONFIG.LOGGEDIN_USER_INFO).user_Details.userCd;
				    	  pncServices.getChartPrintDashBoardData(userID,eventObj.eventId,$scope.dashboardPrintUrl).then(function(data){
                                 $scope.chartOptions.printObjData = data;      
				    	  },function(err){
				    	  	console.log(err);
				    	  })

				    }
				     $scope.open = function (obj) {
				     	var userID = pncsession.get(PNC_SESSION_CONFIG.LOGGEDIN_USER_INFO).user_Details.userCd;
	  					pncServices.showModel(userID,obj.processId).then(function(data){
							    if(data.length!=0){
							    var modalInstance = $uibModal.open({
							      templateUrl:"views/modalPopUp.html",
							      controller:'modalPopUpCtrl',
							      resolve: {
							        data: function () {
							          return data;
							        }
							      }	,
							      backdrop : 'static'
							      });
							}
					    	  },function(err){
					    	    $rootScope.$broadcast('error_show',err.data);
					    	  	console.log(err);
					    	  })
     					
				  }
                    
				   
  
  }])
	
})();