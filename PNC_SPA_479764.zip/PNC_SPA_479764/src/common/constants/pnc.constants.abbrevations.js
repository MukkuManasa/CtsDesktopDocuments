"use strict";
(function(){
angular.module('PNCApp')
	.constant("PNC_CONSTANT",{
		      "HM":"Home",
		      "LT":"Logout",
		      "AM":"Administration",
		      "AR":"Analysis & Reports",
		      "analysisReport":"AR",
		      "TL":"Tools",
		      "ME":"Model Execution Dashboard",
		      "landing":"HM",
		      "modelExecution":"ME",
		      "administration":"AM",
		      "tools":"TL"
	});		
 })();