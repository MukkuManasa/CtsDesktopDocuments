"use strict";
(function(){

	angular.module('PNCApp')
	.decorator("pncServices",['$delegate','$rootScope','pncsession','PNC_SESSION_CONFIG','$uibModal',
		function($delegate,$rootScope,pncsession,PNC_SESSION_CONFIG,$uibModal){
		  	 /*Hide colums and append edit and delete buttons on table row */

		   		$delegate.editDeleteButtons = function(dtInstance,$compile,scope){
	               
						   var hideColumn=[5,6,7,8,9,11,12],
                            table =  dtInstance.dataTable,
                            checkboxArray = $('.preferencesDiv').find('ul input'),
                            checkedArray = $('.preferencesDiv').find('ul input:checked');
                           $('#administrationWrapper .userManagement .table-responsive table tbody').off('click');
                           $('tbody tr').removeClass("rowActive");
				           $("tbody tr td span.options").remove();
				            $("tbody tr td").removeClass("editdelete");
                           if(pncsession.get(PNC_SESSION_CONFIG.PREFERED_DATA)!=undefined){
                           	var toRemove=pncsession.get(PNC_SESSION_CONFIG.PREFERED_DATA);
                           	var allColumns = [0,1,2,3,4,5,6,7,8,9,10,11,12];
                           	if(allColumns.length!=toRemove.length){
                           	hideColumn = allColumns.filter( function( el ) {
  								return toRemove.indexOf( el ) < 0;
							});
							var lastColumn = table.api().columns($(toRemove[toRemove.length-1])).nodes()[0];	
			            	for(var key in lastColumn){
                        	$(lastColumn[key]).addClass("editdelete");
		    				}
                           }
                           else{
                           	hideColumn=[];
                           }
                           }
                           else{
							hideColumn=[5,6,7,8,9,11,12];
							if($('.userManagement .preferencesDiv').length>0){
                           var arr = (table.api().columns(10).nodes())[0];	
                           for(var key in arr){
                        		$(arr[key]).addClass("editdelete");
		    					}
		    				}
							}
							for(var loop=0;loop<checkboxArray.length;loop++){
								 $(checkboxArray[loop]).addClass("preferenceLabelChecked");
							}
						for(var j=0;j<hideColumn.length;j++){
							var arr = (table.api().columns(hideColumn[j]).nodes())[0];	
			               	for(var key in arr){
                        	$(arr[key]).hide();
		    				}
		    				$(table.api().columns(hideColumn[j]).header()).hide();
			                }
                           
						    table.api().columns().every( function () {
			                var column = this;
			                //var hideColumn=[5,6,7,8,9,11,12];
			                if($('.userManagement .preferencesDiv').length>0){	
			                	pncsession.update(PNC_SESSION_CONFIG.HIDECOLUMN_DATA,hideColumn);	
			                for(var j=0;j<hideColumn.length;j++){
			                	if(column.index()==hideColumn[j]){
			                $($('.userManagement .preferencesDiv').find('ul input')[column.index()]).removeClass("preferenceLabelChecked");
			            	}
			            	}
			            }
			             });
						    table.api().rows().every( function () {
						    	var row=this;
						    	var trIndex=null;
						    	trIndex = row.node();
						    	$(trIndex).attr("data-id",row.data().userCd).attr("data-isDeletedFlag",row.data().isDeletedFlag);

				              });
						    $('#dataTable').on('page.dt', function() {
    						/*var info = table.page.info();
    						var page = info.page+1;*/
    						$('tbody tr').removeClass("rowActive");
				           $("tbody tr td span.options").remove();
    						
							});
				            $('#administrationWrapper .userManagement .table-responsive table tbody').on('click', 'tr td:not(.editdelete span)', function () {
				              	var trIndex=$(this).parent();
				              	if($(trIndex).hasClass("rowActive")){
				              		$('tbody tr').removeClass("rowActive");
				              		$("tbody tr td span.options").remove();
				              	}
				              	else{
				              		$('tbody tr').removeClass("rowActive");
				              		$("tbody tr td span.options").remove();
				              		$(trIndex).addClass("rowActive");
				              		scope.id=$(trIndex).attr("data-id");
								scope.isDeletedFlag = $(trIndex).attr("data-isDeletedFlag");	
								if(scope.isDeletedFlag=='NO' && $("tbody tr td").hasClass("editdelete")){	
								$compile($(trIndex).find('.editdelete').append('<span class="options" id="edit"  ng-click="editRow($event); $event.stopPropagation();"></span>'))(scope);
								}
								else{	
								$("tbody tr td span.options").remove();
								$compile($(trIndex).find('.editdelete').append('<span class="options" id="edit" ng-click="editRow($event); $event.stopPropagation();"></span><span class="options" id="delete"  ng-click="deleteRow(); $event.stopPropagation();"></span>'))(scope);
								}
				              	}
				              })   
				             scope.editRow = function($event){
				             $delegate.getRolesForUser().then(function(data){	
							$delegate.getUserByID(scope.id).then(function(getUserByIdData){
							var modalInstance = $uibModal.open({
								templateUrl:"modules/secure/administration/views/editUserInfoPopup.html",
								controller:'addUserPopupCtrl',
								resolve: {
									data: function () {
										return getUserByIdData;
									}
								},
								backdrop : 'static' 
							});
							},function(err){
							$rootScope.$broadcast('error_show',err.data);
						});
						},function(err){
							$rootScope.$broadcast('error_show',err.data);
						});

					};
					scope.deleteRow = function(){
						var modalInstance = $uibModal.open({
						templateUrl:"modules/secure/administration/views/deletePopup.html",
						controller:'deleteUserPopupCtrl',
						resolve: {
								id: function () {
									return scope.id;
								},
								flag: function () {
									return scope.isDeletedFlag;
								},
							},
						backdrop : 'static',
						windowClass :'addModelDialogueWidth'
					});
					};
					
		   		}
		   		
	            return $delegate;

	}]);

})();