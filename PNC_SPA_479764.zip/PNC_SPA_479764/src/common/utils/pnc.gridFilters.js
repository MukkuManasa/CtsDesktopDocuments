"use strict";
(function(){

	angular.module('PNCApp')
	.decorator("pncServices",['$delegate', function($delegate){
		  	 //Generate dataTable and costum filtering 

		   		$delegate.generateDTCustomFilters = function(dtInstance,$compile,scope){
	               
						var filterTemplate = '';
                           var table =  dtInstance.dataTable;
						    table.api().columns().every( function () {
			                var column = this;
			                if(!(column.data().length==0 || (column.data().unique().length == 1 && column.data()[0]==null))){
			                	var select = $('<div class="filterOverlay"><span class="filterImg"></span><div class="filterDiv"><div class="filterHeader">Filter</div><ul ng-scrollbars ng-scrollbars-config="scrollbarFilterConfig"></ul><div class="filterButtons"><button class="filterSave grayButton">Ok</button><button class="filterCancel orangeButton">cancel</button></div></div></div>')
			                    .appendTo( $(column.header()));
			                
			                    select.find('.filterSave').on( 'click', function (e) {
			                    	e.stopPropagation();
			                    	$(this).closest('.filterOverlay').find('ul input').each(function(){
				                     		$(this).removeClass('labelChecked');
				                    })
			                   	    var searchValue = "";
	               	                var checkedArray = $(this).closest('.filterOverlay').find('ul input:checked');
				                    if(checkedArray.length>1){
				                     	checkedArray.each(function(i){
				                     		if(i === checkedArray.length-1){
				                     			 searchValue += $(this).val();
				                     		}else{
				                     			  searchValue += $(this).val()+ "|";
				                     		}
				                     		$(this).addClass('labelChecked');
				                        });
				                       $(this).closest('th').addClass('filterApplied');
				                     }else if(checkedArray.length===1){
				                     	searchValue =  checkedArray.val();
				                     	$(checkedArray).addClass('labelChecked');
				                     	$(this).closest('th').addClass('filterApplied');
				                     }else{
				                     	$(this).closest('th').removeClass('filterApplied');
				                     }
	                                 column.search(searchValue,true,false).draw();
			                    	 $(this).closest('.filterOverlay').find('.filterDiv').toggleClass('openFilter');
			                    	 
			                    });
			                    select.find('.filterImg').on('click',function(e){
			                    	$('tbody tr').removeClass("rowActive");
									$("tbody tr td span.options").remove();
			                    	e.stopPropagation();

			                    	select.closest('tr').find('th .filterOverlay .filterDiv').each(function(){
			                    		if($(this).hasClass('openFilter')){
			                    			 $(this).removeClass('openFilter')
			                    		}
			                    	})
			                    	$(this).closest('.filterOverlay').find('.filterDiv').toggleClass('openFilter').removeClass('flipFilterDiv');
			                    	var filterDiv = $(this).closest('.filterOverlay').find('.filterDiv'),
			                    	    offset = $(filterDiv).offset();
			                    	if(offset.top + $(this).closest('.filterOverlay').find('.filterDiv').outerHeight() > $('body').outerHeight()){
                                         $(filterDiv).addClass('flipFilterDiv');
			                    	}
			                    })
			                    var num = Math.floor(Math.random() * 10 + 1)
			                column.data().unique().sort().each( function ( d, j ) {
			                	if(d!=null){
			                   		filterTemplate += '<li class="checkbox"><input id="'+d+num+'" type="checkbox" value="'+d+'"><label for="'+d+num+'">'+d+'</label></li>';
			                	}
			                } );
			                select.find('ul').prepend(filterTemplate);
			                filterTemplate="";
			                select = $compile(select)(scope);
				               select.find('ul').on('click',function(e){
		                                 e.stopPropagation();
				                })

				                 select.find('.filterCancel').on('click',function(e){
			                    	 e.stopPropagation();
			                    	 $(this).closest('.filterOverlay').find('ul input').each(function(){
			                    	 	if(!$(this).hasClass('labelChecked')){
			                    	 	  $(this).prop('checked', false);
			                    	    }else{
			                    	    	$(this).prop('checked', true);
			                    	    }
			                    	 })
			                    	 $(this).closest('.filterOverlay').find('.filterDiv').toggleClass('openFilter');
			                    })
				             }
					        });
	                   

		   		}

	            return $delegate;

	}]);

})();