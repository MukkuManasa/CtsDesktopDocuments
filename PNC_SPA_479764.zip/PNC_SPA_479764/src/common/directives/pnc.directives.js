"use strict";
(function(){
	angular.module('PNCAppDirectives',[])
	.directive('pncHeader',function(){
		return{
			restrict:'E',
			scope:{
				userinfo: '=',
				pncconstants: '=',
				setchoicevalue:'&',
				currentstate : "="
			},
			templateUrl:'views/headerTemplate.html'
		}

	})
	.directive('loader',['$rootScope',function($rootScope){
		return{
			restrict:'E',
			link:function(scope,element,attrs){
				scope.$on('loader_show',function(){
                      element.show();
				})
				scope.$on('loader_hide',function(){
                      element.hide();
				})
			},
			template:'<div class="chartOverLay"><div class="loadingImg">Please Wait...</div></div>'
		}
	}])
	.directive('errorHolder',function(){
		return{
			restrict:'E',
			link:function(scope,element,attrs){
				scope.$on('error_show',function(event,args){
					  element.find('.alertMsg').html(args.code+" "+args.message);
                      element.find('.alert').removeClass('hideSection');
				})
                element.find('.close').on('click',function() {
                	element.find('.alert').addClass('hideSection')
                })
			},
			templateUrl:'views/alerts.html'
		}
	})
	.directive('eventDir',['pncServices','$q','$state',function(pncServices, $q,$state){
		return{
			restrict:'A',
			link:function(scope,ele,attrs){
				ele.on('click',function(){
					if(ele.hasClass('LT')){
						pncServices.logout()
						.then(function(data){			 			
							if(data.isLogoutSuccess){
								$state.go('login');
							}
						},function(err){
							console.log(err);

						});
					}else if(ele.hasClass('ME')){
						$state.go("modelExecution.controldashboard");
					}		
					else if(ele.hasClass('HM')){
						$state.go("landing");
					}else if(ele.hasClass("MQ")){
						ele.siblings().removeClass('selected')
						ele.addClass('selected');
						$state.go('modelExecution.myqueue');
					}else if(ele.hasClass('CD')){
						ele.siblings().removeClass('selected')
						ele.addClass('selected');
						$state.go('modelExecution.controldashboard');
					}else if(ele.hasClass("ED")){
						ele.siblings().removeClass('selected')
						ele.addClass('selected');
						$state.go('modelExecution.enterprisedashboard');
					}else if(ele.hasClass("SD")){
						ele.siblings().removeClass('selected')
						ele.addClass('selected');
						$state.go('modelExecution.statusdashboard');
					}else if(ele.hasClass("AM")){
						$state.go('administration.userManagement');
					}else if(ele.hasClass("AM_UM")){
						ele.siblings().removeClass('selected')
						ele.addClass('selected');
						$state.go('administration.userManagement');
					}else if(ele.hasClass("AM_RM")){
						ele.siblings().removeClass('selected')
						ele.addClass('selected');
						$state.go('administration.roleManagement');
					}else if(ele.hasClass('TL')){
						$state.go("tools");
					}
				})
			}
		}
	}])
	.directive('printGrid',function(){
		return{
			restrict:'A',
			link:function(scope,element,attrs){
				element.on('click',function(){
					angular.element('.printButton').triggerHandler('click')
				})

			}
		}
	})
	.directive('exportGridtoexcel',['$rootScope','pncServices','pncsession','PNC_SESSION_CONFIG','$window',function($rootScope,pncServices,pncsession,PNC_SESSION_CONFIG,$window){
		return{
			restrict:'A',
			scope:{
				fileUrl:'=fileurl',
				fileName:'=filename'

			},
			link:function(scope,element,attrs){
				element.on('click',function(){
					if(!element.parent().hasClass('tableDisabled')){
						var userID = pncsession.get(PNC_SESSION_CONFIG.LOGGEDIN_USER_INFO).user_Details.userCd,
						    eventObj = pncsession.get(PNC_SESSION_CONFIG.SELECTED_EVENT_OBJ);
						    if(eventObj!=undefined){
						    var eventId = eventObj.eventId;
							}else{
							var eventId='';	
							}
						pncServices.exportToExcel(userID,eventId,scope.fileUrl)
									.then(function(data){
										var ua = window.navigator.userAgent;
	                                    var msie = ua.indexOf("MSIE ");
	                                    var blob = new Blob([data], {type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"});
	                                    if(msie !== -1 || !!navigator.userAgent.match(/Trident.*rv\:11\./)){
	                                    	window.navigator.msSaveBlob(blob, scope.fileName);
	                                    }else{
	                                    	var objectUrl = $window.URL.createObjectURL(blob);
								            
									        $('body').append('<a id="download"></a>'); 
											      $('#download').attr('href', objectUrl);
											      $('#download').attr('download', scope.fileName);
											      $('#download')[0].click();
											      $('#download').remove();

									        

	                                    }   
									 },function(err){
									 	$rootScope.$broadcast('error_show',err.data);
									 });
                    } 

				})
                  
			}
		}

	}])
    .directive("exportGridtopdf",['$rootScope','pncServices','pncsession','PNC_SESSION_CONFIG','$window',function($rootScope,pncServices,pncsession,PNC_SESSION_CONFIG,$window){
    	return{
    		restrict:'A',
    		scope:{
				fileUrl:'=fileurl',
				fileName:'=filename'
			},
    		link:function(scope,element,attrs){
    			element.on('click',function(){
    				if(!element.parent().hasClass('tableDisabled')){
		    				var userID = pncsession.get(PNC_SESSION_CONFIG.LOGGEDIN_USER_INFO).user_Details.userCd,
			    				eventObj = pncsession.get(PNC_SESSION_CONFIG.SELECTED_EVENT_OBJ);
							    if(eventObj!=undefined){
						    	var eventId = eventObj.eventId;
								}else{
								var eventId='';	
								}
							pncServices.exportToPDF(userID,eventId,scope.fileUrl)
								.then(function(data){
									var ua = window.navigator.userAgent;
                                    var msie = ua.indexOf("MSIE ");
                                    var blob = new Blob([data], {type: "application/pdf"});
                                    if(msie !== -1 || !!navigator.userAgent.match(/Trident.*rv\:11\./)){
                                    	window.navigator.msSaveBlob(blob, scope.fileName);
                                    }else{
                                    	var objectUrl = $window.URL.createObjectURL(blob);
							            
								        $('body').append('<a id="download"></a>'); 
										      $('#download').attr('href', objectUrl);
										      $('#download').attr('download', scope.fileName);
										      $('#download')[0].click();
										      $('#download').remove();

                                    }
								 },function(err){
								 	$rootScope.$broadcast('error_show',err.data);
								 });
					}

    			})
    		}
    	}
    }])
.directive("mailGrid",['$rootScope','pncServices','pncsession','PNC_SESSION_CONFIG',function($rootScope,pncServices,pncsession,PNC_SESSION_CONFIG){
	return{
		restrict:"A",
		link:function(scope,element,attrs){
			element.on('click',function(){
				if(!element.parent().hasClass('tableDisabled')){
					var userInfo = pncsession.get(PNC_SESSION_CONFIG.LOGGEDIN_USER_INFO);
			 		var fullName = "";
			 		if(userInfo.user_Details.firstNameTxt){
			 			fullName = userInfo.user_Details.firstNameTxt;
			 		}
			 		if(userInfo.user_Details.middleNameTxt){
			 			fullName += ' ' + userInfo.user_Details.middleNameTxt;
			 		}
			 		if(userInfo.user_Details.lastNameTxt){
						fullName += ' ' + userInfo.user_Details.lastNameTxt;
			 		}

			 		var toAddress = userInfo.user_Details.emailAddrTxt;
			 		var mailBody = [fullName];
			 		var mailInputParams = [userInfo.user_Details.userCd];

			 		pncServices.sendMail(toAddress, mailBody, mailInputParams)
			 			.then(function(data){
					 },function(err){
					 	$rootScope.$broadcast('error_show',err.data)
					 });
				}
			})
		}
	}

}])
.directive("captureChart",function(){
		return{
			restrict:'A',
			link:function(scope,element,attrs){
				element.on('click',function(){
					if(!element.parent().hasClass('tableDisabled')){
						var dashboardHolder = element.closest('#dashboardHolder').attr('class');
						createPng(element.attr('class'),dashboardHolder);
				     }	
				})
				function createPng(className,dashboardHolder){
					var chartContainer = $('.captureChartSection').find('#chartPrint').html().trim(),
					canvas= $('#canvas')[0],
					className = className,
					dashboardHolder = dashboardHolder;
					

					function savePng(){
						   //create a dummy CANVAS

							var destinationCanvas = document.createElement("canvas");
							destinationCanvas.width = canvas.width;
							destinationCanvas.height = canvas.height;

							var destCtx = destinationCanvas.getContext('2d');

							//create a rectangle with the desired color
							destCtx.fillStyle = "#FFFFFF";
							destCtx.fillRect(0,0,canvas.width,canvas.height);

							//draw the original canvas onto the destination canvas
							destCtx.drawImage(canvas, 0, 0);

						var jpg =  destinationCanvas.toDataURL("image/jpeg");
						        if(className === 'imgChart'){
	                       	        if (canvas.msToBlob) { //for IE
	                       	        	var blob = destinationCanvas.msToBlob();
	                       	        	window.navigator.msSaveBlob(blob, dashboardHolder+'.jpg');
	                       	        }else{
	                       	        	$('body').append('<a id="export-image-container"></a>') 
	                       	        	$('#export-image-container').attr('href', jpg);
	                       	        	$('#export-image-container').attr('download',dashboardHolder+'.jpg')
	                       	        	$('#export-image-container')[0].click()
	                       	        	$('#export-image-container').remove();  
	                       	        }
	                       	    }else if(className === 'pdfChart'){
	                       	    	var doc = new jsPDF('l','pt','a2');
	                       	    	
	                       	    	doc.addImage(jpg,'jpeg',0,0);
	                       	    	doc.save(dashboardHolder+'.pdf');
	                       	    	$(destinationCanvas).remove()
	                       	    }else if(className === 'printChart'){

				                       var newWin = window.open();
				                       newWin.document.write('<img width=1200 transform="rotate(90deg)" id="printPng" src="'+jpg+'"/>');
				                        newWin.document.close();
										newWin.focus();
										newWin.print();
										newWin.close();
														                       
				                       //$('#printPng').remove()
				                   } 

				               }
				               canvg(canvas,chartContainer,{renderCallback:savePng});
				           }

				       } 
				   }
})
.directive("pdfChart",function(){
		return{
			restrict:'A',
			link:function(scope,element,attrs){
				element.on('click',function(){
					if(!element.parent().hasClass('tableDisabled')){
						var dashboardHolder = element.closest('#dashboardHolder').attr('class');
						createPdf(element.attr('class'),dashboardHolder);
				     }	
				})
				function createPdf(className,dashboardHolder){
					var NumOfcanvases = $('.imageContainer').find('img'),
					    doc = new jsPDF('p','pt','a4'),
					    count = 0;
					    NumOfcanvases.sort(function(a,b){
					    	return $(a).attr('id') - $(b).attr('id')
					    })
					    $('.imageContainer').empty();
					    for(var i=0;i<NumOfcanvases.length;i++){
					    	count++;
					    	var img = $(NumOfcanvases[i])[0];
					    	$('.imageContainer').append(img);
					    	doc.addImage(img,'jpeg',0,0);
					    	doc.addPage();
					    	if(count === NumOfcanvases.length){
					    		if(className === 'pdfChart'){
                            		doc.save(dashboardHolder+'.pdf');
                            	}else if(className === 'printChart'){
	                                var newWin = window.open("", "w");
									var html = $('.imageContainer').html();
									newWin.document.write(html);
			                        newWin.document.close();
									newWin.focus();
									newWin.print();
									newWin.close();
                            	}
					    	}
					    }
                            		
                }
                           

			} 	               
			}

})
.directive("stackedChart",['$window','pncsession','PNC_SESSION_CONFIG',function($window,pncsession,PNC_SESSION_CONFIG){
		return{
			restrict:"A",
			scope:{
				chartoptions:'=',
				open:'='
			},
			link:function(scope,element,attrs){
				var d3 = $window.d3;
				scope.$watch('chartoptions.ObjData',function(newValue,oldValue){
					if(newValue !== oldValue){
						d3.select('.yAxisSection').select('svg').selectAll("*").remove();
						d3.select('.stackedChartWrapper').select('svg').selectAll("*").remove();
						if(Object.keys(scope.chartoptions.ObjData).length !== 0){
							renderChart(scope.chartoptions.ObjData);
						}
						
					}
				})
				function renderChart(data){
					var width,actualSvgWidth,yaxisHeight,maxYvalue,maxXvalue,
					bufferWidth = 50,
					spacing = scope.chartoptions.spacing,
					gridSize= scope.chartoptions.gridsize;

					var svg = d3.select('.stackedChartWrapper').select('svg').append("g").attr('transform','translate(10,50)').attr("xmlns","http://www.w3.org/2000/svg").attr("xmlns:xlink","http://www.w3.org/1999/xlink"),

					yaxisSvg = d3.select('.yAxisSection').select('svg');
                 //tooltip = d3.select('.stackedChartWrapper').append('div').attr("class","chartTooltip").style("opacity",0);
                 
                 var layersArr = [],
                 maxXvalue = Math.max.apply(Math,data['3'].map(function(o){return o.x;}));
                 maxYvalue = Math.max.apply(Math,data['3'].map(function(o){return o.y;}));
                 for(var i=0;i<= maxXvalue;i++){
                 	var layers = [];
                 	layers = data['3'].filter(function(d) {
                 		if(d.x == i){
                 			return d;
                 		}

                 	});
                 	layersArr.push(layers)

                 }

                 actualSvgWidth = ((gridSize+spacing) *(maxXvalue+1));
                 var actualSvgHeight = ((gridSize * (maxYvalue+1)) + 100);
                 width =  actualSvgWidth + bufferWidth;

                 d3.select('.stackedChartWrapper').select('svg').attr('width',width).attr('height',actualSvgHeight);
                 d3.select('.yAxisSection').select('svg').attr('height',actualSvgHeight);
                 d3.select('.controlOwnerGroup').style("height",actualSvgHeight*0.45 + 'px');
                 d3.select('.processGroup').style("width",actualSvgHeight*0.8 + 'px');

                 var x = d3.scale.ordinal().rangeRoundBands([0,actualSvgWidth]);

                 var y = d3.scale.ordinal().rangeRoundBands([0,actualSvgHeight]);

                 var xAxis = d3.svg.axis().scale(x).orient("bottom").tickSize(0);

                 var yAxis = d3.svg.axis().scale(y).orient("left").ticks(5).tickSize(0);

                 function make_y_axis(){
                 	return 	d3.svg.axis().scale(y).orient("left").ticks(5);
                 }   

                 x.domain(data['1'].map(function(d){
                 	return d.PROCESS_NAME;
                 }))
                 y.domain(data['2'].map(function(d){
                 	return d[Object.keys(d)]
                 }))

                 var tip = d3.tip()
                 .attr('class', 'chartTooltip')
                 .offset([0, 0])
                 .html(function(d) {
                 	var tipHtml = "";
                 	tipHtml = '<p>' + d.processName + '</p><p>Status:' + d.processStatus + '</p>';
                 	if(d.processStatus != "Not Applicable"){
                 		tipHtml += '<p>Executor:'+d.reviewerID+'</p><p>Reviewer:'+d.ownerID+'</p>';
                 	}
                 	return tipHtml;
                 })
                 svg.call(tip);

                 var layer = svg.selectAll(".layer")
                 .data(layersArr).enter().append("g").attr("transform",function(d,i){
                 	return "translate("+i*spacing+",0)";
                 });

                 layer.selectAll('rect').data(function(d){
                 	return d;
                 })
                 .enter().append("rect")
                 .attr("x",function(d){
                 	return (d.x)* gridSize;
                 })
                 .attr("y",function(d){
                 	return (d.y)*gridSize;
                 })
                 .attr('fill',function(d){
                 	return d.color;
                 })
                 .attr("width",gridSize)
                 .attr("height",gridSize)
                 .on("click",function(d){
                 	scope.open(d);
                 })
                 .on("mouseover",tip.show)					
                 .on("mouseout", tip.hide);

                 layer.selectAll('.rect1').data(function(d){
                 	return d;
                 })
                 .enter().append("rect")
                 .attr("x",function(d){
                 	return (d.x)* gridSize;
                 })
                 .attr("y",function(d){
                 	return (d.y)*gridSize;
                 })
                 .style('cursor',function(d){if(d.processStatus!="Not Applicable") return 'pointer'})
                 .attr("width",40)
                 .attr("height",40)
                 .attr('fill',function(d){
                 	var userID = pncsession.get(PNC_SESSION_CONFIG.LOGGEDIN_USER_INFO).user_Details.userCd;
                 	if (d.processStatus === "Not Started" && userID === d.approverID) {
                 		return 'url(#pending)'
                 	}
                 	else if (d.processStatus === "Executed" && userID === d.approverID) {
                 		return 'url(#pending)'
                 	}
                 	else if (d.processStatus === "Rejected" && userID === d.approverID) {
                 		return 'url(#pending)'
                 	}
                 	else {
                 		return d.color;
                 	}

                 })
                 .on("click",function(d){
                 	if(d.processStatus!="Not Applicable")
                 	scope.open(d);
                 })
                 .on("mouseover",tip.show)					
                 .on("mouseout", tip.hide);


                 svg.append("g").attr("class","axis xaxis")
                 .attr("transform","translate(0,"+(actualSvgHeight-100)+")").call(xAxis)
                 .selectAll('.tick').each(function(d,i){
                 	var tick = d3.select(this);

                 	if(tick.select('text').text()=== data['1'][i].PROCESS_NAME){
                 		if(data['1'][i].COLOR){
                 			tick.style("fill",data['1'][i].COLOR);
                 		}
                 		else{
                 			tick.style("fill","#2c94ff");
                 		}
                 	}

                 	wrap(tick.select('text'),x.rangeBand()-5,'xaxis');
                 	tick.attr("transform","translate("+((i*(gridSize+spacing))+20)+",0)")
                 });
                 yaxisSvg.append("g").attr("class","axis yaxis")
                 .attr("transform","translate(124,50)").call(yAxis).selectAll('.tick').each(function(d,i){
                 	var tick = d3.select(this);
                 	wrap(tick.select('text'),(y.rangeBand()*2)+20,'yaxis');
                 	tick.attr("transform","translate(-4,"+(((i)*gridSize)+(gridSize/2))+")")
                 })

                 svg.append("g")            
                 .attr("class", "grid")
                 .call(make_y_axis()
                 	.tickSize(-actualSvgWidth, 0, 0)
                 	.tickFormat("")
                 	).selectAll('.tick').each(function(d,i){
                 		var tick = d3.select(this);
                 		yaxisHeight = (i+1)*gridSize;
                 		tick.attr("transform","translate(0,"+(i+1)*gridSize+")")
                 		if(y.domain().length - 1 === i){
                 			tick.attr("style","opacity:0");
                 		}
                 	})
                 	yaxisSvg.append("g").attr("transform",'translate(0,50)')           
                 	.attr("class", "grid")
                 	.call(make_y_axis()
                 		.tickSize(-width, 0, 0)
                 		.tickFormat("")
                 		).selectAll('.tick').each(function(d,i){
                 			var tick = d3.select(this);
                 			yaxisHeight = (i+1)*gridSize;
                 			tick.attr("transform","translate(0,"+(i+1)*gridSize+")")
                 			if(y.domain().length - 1 === i){
                 				tick.attr("style","opacity:0");
                 			}
                 		})
                 		yaxisSvg.select('.yaxis').select('path').attr("marker-end",'url(#arrowhead)').attr("d","M0,0V0H0V"+(yaxisHeight+(gridSize/2))).attr("transform","rotate(-180) translate(0,"+-yaxisHeight+")");
                 		d3.select('.StackedChartSection').select('.controlOwnerGroup').style("height",yaxisHeight + 'px');
                 		svg.append("defs").append("marker")
                 		.attr("id", "arrowhead")
                 		.attr("markerUnits","strokeWidth")
                 		.attr("refX", 3)
                 		.attr("refY", 8)
                 		.attr("markerWidth", 20)
                 		.attr("markerHeight", 20)
                 		.attr("orient","auto")
                 		.append("path")
                 		.attr("d", "M2,2 L2,14 L14,8 L2,2").attr("style","fill: #57798c;")
                 		svg.append("defs")
                 		.append("pattern")
                 		.attr("id", "pending")
                 		.attr('patternUnits','userSpaceOnUse')
                 		.attr("width",40)
                 		.attr("height",40)
                 		.append("image")
                 		.attr("xlink:href", "assets/images/pending__CntlDb-white.png")
                 		.attr('x',10)
                 		.attr('y',10)
                 		.attr("width",20)
                 		.attr("height",21);
                 		d3.select(".xaxis").select("path").attr("d","M0,0V0H"+(actualSvgWidth+spacing)+"V0").attr("marker-end",'url(#arrowhead)').attr('transform','translate('+-spacing+',0)');
                 		$('.xAxisClone svg').empty();
                 		$('.StackedChartSection').find('svg').find('.xaxis').clone().appendTo('.xAxisClone svg')
                 		d3.select('.xAxisClone').select('svg').attr('width',width)
                 		d3.select('.xAxisClone').select('.xaxis').attr('transform','translate(10,6)');
                 		d3.select('.xAxisClone').select('.xaxis path').attr('transform','translate(-20,0)')


                 		function wrap(text, width,axis) {
                 			text.each(function() {
                 				var text = d3.select(this),
                 				words = text.text().split(/\s+/).reverse(),
                 				splitStringArray = [],
                 				word,
                 				line = [],
                 				lineNumber = 0,
						        lineHeight = 1.1, // ems
						        y = text.attr("y"),
						        dy = parseFloat(text.attr("dy")),
						        tspan = text.text(null).append("tspan").attr("x", 0).attr("y", y).attr("dy", dy + "em");
						      
						        if(axis==="xaxis"){
							        for(var i=0;i< words.length;i++){
							        	if(words[i].length > 10 ){
							        		var sb = words[i].substr(9);
							        		var sb2 = words[i].substr(0,9);
						        	 		words.splice(i,1,sb,sb2);
						        	 	
						        	 	}
						        	}
					        	}
					        	while (word = words.pop()) {
					        		line.push(word);
					        		tspan.text(line.join(" "));
					        		if (tspan.node().getComputedTextLength() > width) {
					        			line.pop();
					        			tspan.text(line.join(" "));
					        			line = [word];
					        			tspan = text.append("tspan").attr("x", 0).attr("y", y).attr("dy", ++lineNumber * lineHeight + dy + "em").text(word);
					        		}
					        	}
					        });
                 		}

                 	}

                 }


             }

         }])
.directive("stackedChartforprint",['$window','pncsession','PNC_SESSION_CONFIG',function($window,pncsession,PNC_SESSION_CONFIG){
	return{
		restrict:"A",
		scope:{
			chartoptions:'='
		},
		link:function(scope,element,attrs){
			var d3 = $window.d3;
			scope.$watch('chartoptions.ObjData',function(newValue,oldValue){
				if(newValue !== oldValue){
					d3.select('.captureChartSection .stackedChartWrapper').select('svg').selectAll("*").remove();
					if(Object.keys(scope.chartoptions.ObjData).length !== 0){
							renderChart(scope.chartoptions.ObjData);
				    }
					
				}
			})
			function renderChart(data){
				var width,actualSvgWidth,yaxisHeight,maxYvalue,maxXvalue,
				bufferWidth = 50,
				spacing = scope.chartoptions.spacing,
				gridSize= scope.chartoptions.gridsize;
                d3.select('.captureChartSection').style('display','block');
				var svg = d3.select('.captureChartSection .stackedChartWrapper').select('svg').append("g").attr('transform','translate(300,50)'),
				yaxisSvg = d3.select('.yAxisSection').select('svg'),
				tooltip = d3.select('.captureChartSection .stackedChartWrapper').append('div').attr("class","chartTooltip").style("opacity",0);
				svg.attr("version", "1.1");
				svg.attr("xmlns", "http://www.w3.org/2000/svg");
				svg.attr("xmlns:xlink", "http://www.w3.org/1999/xlink");
				var layersArr = [],
				maxXvalue = Math.max.apply(Math,data['3'].map(function(o){return o.x;}));
				maxYvalue = Math.max.apply(Math,data['3'].map(function(o){return o.y;}));
				for(var i=0;i<= maxXvalue;i++){
					var layers = [];
					layers = data['3'].filter(function(d) {
						if(d.x == i){
							return d;
						}

					});
					layersArr.push(layers)

				}

				actualSvgWidth = ((gridSize+spacing) *(maxXvalue+1));
				var actualSvgHeight = ((gridSize * (maxYvalue+1)) + 100);

				var y = d3.scale.ordinal().rangeRoundBands([0,actualSvgHeight]);

				var yAxis = d3.svg.axis().scale(y).orient("left").ticks(5).tickSize(0);

				y.domain(data['2'].map(function(d){
					return d[Object.keys(d)]
				}))

				function make_y_axis(){
					return 	d3.svg.axis().scale(y).orient("left").ticks(5);
				}   
				svg.append("g").attr("class","axis yaxis")
				.attr("transform","translate(0,0)").call(yAxis).selectAll('.tick').each(function(d,i){
					var tick = d3.select(this);
					wrap(tick.select('text'),(y.rangeBand()*2)+20,'yaxis');
					tick.attr("transform","translate(-4,"+(((i)*gridSize)+(gridSize/2))+")")
					tick.select('text').attr('font-size',12+'px')
				})

				var yaxisWidth = Math.round(d3.select('.yaxis').node().getBBox().width);
				var totalSvgWidth = actualSvgWidth + yaxisWidth;
				width =  actualSvgWidth + bufferWidth;

				d3.select('.captureChartSection .stackedChartWrapper').select('svg').attr('width',totalSvgWidth + 750).attr('height',actualSvgHeight+150);
				d3.select('.captureChartSection .StackedChartSection').select('.processGroup').style("width",actualSvgWidth + 'px');

				var x = d3.scale.ordinal().rangeRoundBands([0,actualSvgWidth]);
				var xAxis = d3.svg.axis().scale(x).orient("bottom").tickSize(0);
				x.domain(data['1'].map(function(d){
					return d.PROCESS_NAME;
				}))
				var layer = svg.append('g').attr('transform','translate(10,0)').selectAll(".layer")
				.data(layersArr).enter().append("g").attr("transform",function(d,i){
					return "translate("+(i)*spacing+",0)";
				});

				layer.selectAll('rect').data(function(d){
					return d;
				})
				.enter().append("rect")
				.attr("x",function(d){
					return (d.x)* gridSize;
				})
				.attr("y",function(d){
					return (d.y)*gridSize;
				})
				.attr('fill',function(d){return d.color})
				.attr("width",gridSize)
				.attr("height",gridSize)
				

				layer.selectAll('.rect1').data(function(d){
					return d;
				})
				.enter().append("rect")
				.attr("x",function(d){
					return (d.x)* gridSize;
				})
				.attr("y",function(d){
					return (d.y)*gridSize;
				})
				.attr("width",40)
				.attr("height",40)
				.attr('fill',function(d){
					var userID = pncsession.get(PNC_SESSION_CONFIG.LOGGEDIN_USER_INFO).user_Details.userCd;
					if (d.processStatus === "Not Started" && userID === d.approverID) {
						return 'url(#pending)'
					}
					else if (d.processStatus === "Executed" && userID === d.approverID) {
						return 'url(#pending)'
					}
					else if (d.processStatus === "Rejected" && userID === d.approverID) {
						return 'url(#pending)'
					}
					else {
						return d.color;
					}
				})

				svg.append('g').attr("class","axis xaxis")
				.attr("transform","translate(20,"+(actualSvgHeight-100)+")").call(xAxis)
				.selectAll('.tick').each(function(d,i){
					var tick = d3.select(this);
					if(tick.select('text').text()=== data['1'][i].PROCESS_NAME){
						if(data['1'][i].COLOR){
							tick.style("fill",data['1'][i].COLOR);
						}
						else{
							tick.style("fill","#2c94ff");
						}
					}
					wrap(tick.select('text'),x.rangeBand()-10,'xaxis');
					tick.attr("transform","translate("+((i*(gridSize+spacing))+10)+",0)")
					tick.select('text').attr('font-size',12+'px')
				});
				
				
				svg.append("g")            
				.attr("class", "grid")
				.call(make_y_axis()
					.tickSize(-totalSvgWidth, 0, 0)
					.tickFormat("")
					).selectAll('.tick').each(function(d,i){
						var tick = d3.select(this);
						yaxisHeight = (i+1)*gridSize;
						tick.attr("transform","translate("+(-yaxisWidth)+","+(i+1)*gridSize+")")
						tick.select('line').attr("y2",2).attr("stroke","black");
						if(y.domain().length - 1 === i){
							tick.attr("style","opacity:0");
						}
					})

					svg.select('.yaxis').select('path').attr("d","M0,0V0H0V"+(yaxisHeight+(gridSize/2))).attr("transform","rotate(-180) translate(0,"+-yaxisHeight+")").attr('stroke',"black")
					d3.select('.StackedChartSection').select('.controlOwnerGroup').style("height",yaxisHeight + 'px');
					svg.append("text")
					.attr("font-size","14px")
					.attr("font-family", "MetaOffcPro-Medi")
					.attr("dx", 0)
					.attr("dy", yaxisHeight+113)
					.text("Status Legend :");
					var color = d3.scale.category20();
					var dataset =[{"x":95, "r":6, "name":"Not Applicable","type":"controldashboard","colorcode":"#586671"}, 
					{"x":200, "r":6, "name":"Not Started","type":"controldashboard","colorcode":"#2c94ff"},
					{"x":300, "r":6, "name":"Executed","type":"controldashboard","colorcode":"#fd9b00"}, 
					{"x":380, "r":6, "name":"Reviewed","type":"controldashboard","colorcode":"#23a565"},
					{"x":455, "r":6, "name":"Rejected","type":"controldashboard","colorcode":"#bf0101"},
					{"x":95, "r":6, "name":"Not Applicable","type":"enterprisedashboard","colorcode":"#586671"}, 
					{"x":200, "r":6, "name":"Not Started","type":"enterprisedashboard","colorcode":"#2c94ff"},
					{"x":300, "r":6, "name":"Executed","type":"enterprisedashboard","colorcode":"#fd9b00"}, 
					{"x":380, "r":6, "name":"Reviewed","type":"enterprisedashboard","colorcode":"#23a565"},
					{"x":455, "r":6, "name":"Rejected","type":"enterprisedashboard","colorcode":"#bf0101"},
					{"x":90, "r":6, "name":"Not Applicable","type":"statusdashboard","colorcode":"#586671"}, 
					{"x":200, "r":6, "name":"Not Started","type":"statusdashboard","colorcode":"#2c94ff"},
					{"x":300, "r":6, "name":"Executed","type":"statusdashboard","colorcode":"#fd9b00"}, 
					{"x":380, "r":6, "name":"Reviewed","type":"statusdashboard","colorcode":"#23a565"}]
					var dataset1 ={"controldashboard1":[{"x":150,"name":"Execution","colorcode":"#C14141"}, 
					{"x":210, "name":"Reporting","colorcode":"#FFA500"},
					{"x":270, "name":"Output","colorcode":"#05A505"}, 
					{"x":315, "name":"Input","colorcode":"#25A1EF"}]};
					var condFlag=d3.select("#dashboardHolder").attr("class");
					var title;
					if(condFlag == "controldashboard"){
						title="Control Dashboard"
					}
					if(condFlag == "enterprisedashboard"){
						title="Enterprise Dashboard"
					}
					if(condFlag == "statusdashboard"){
						title="Status Dashboard"
					}
					var filtered = dataset.filter(function(d) {
						return d.type == condFlag; 
					});
					var forecast = d3.select(".forecast #dropdown").text();
					svg.append("text")
					.attr("dx", actualSvgWidth/2)
					.attr("dy",-25)
					.text(title+" ("+forecast+")")
					.attr("fill","#fd7607");

					var elem = svg.selectAll("g myCircleText")
					.data(filtered)
					var ele = elem.enter()
					.append("g")
					.attr("transform", function(d){return "translate("+(d.x+d.name.length)+","+(yaxisHeight+110)+")";})

					/* var ele = svg.append('g').attr('transform',"translate(30,"+(yaxisHeight+80)+")")*/
					var circle = ele.append("circle")
					.attr("r", function(d){return d.r} )
					.attr("stroke","black")
					.style("fill",function(d){return d.colorcode});
					ele.append("text")
					.attr("dx", 12)
					.attr("dy", 5)
					.text(function(d){
						return (d.name);
					})
					.attr("font-size","12px")
					.attr("font-family", "MetaOffcPro-Norm");
					svg.append("circle")
					.attr("r", 11)
					.attr("cx", 549)
					.attr("cy",yaxisHeight+105)
					.style("fill","url(#controlpending)")
					.style("display", function(condFlag) {
						condFlag =d3.select("#dashboardHolder").attr("class");
						return condFlag == "controldashboard" ? "block" : "none";
					});
					svg.append("text")
					.attr("dx", 562)
					.attr("dy",yaxisHeight+115)
					.style("display", function(condFlag) {
						condFlag =d3.select("#dashboardHolder").attr("class");
						return condFlag == "controldashboard" ? "block" : "none";
					})
					.text("Pending")
					.attr("font-size","12px")
					.attr("font-family", "MetaOffcPro-Norm");;
					svg.append("text")
					.attr("class","onlyControlDashboard")
					.attr("dx", 0)
					.attr("dy", yaxisHeight+145)
					.style("display", function(condFlag) {
						condFlag =d3.select("#dashboardHolder").attr("class");
						return condFlag == "controldashboard" ? "block" : "none";
					})
					.text("Control Group Legend :")
					.attr("font-size","14px")
					.attr("font-family", "MetaOffcPro-Medi");
					var elem1 = svg.selectAll("g controlText")
					.data(dataset1.controldashboard1)
					var ele1 = elem1.enter()
					.append("g")
					.attr("transform", function(d){return "translate("+(d.x)+","+(yaxisHeight+145)+")";})
					ele1.append("text").data(dataset1.controldashboard1)
					.style("display", function(condFlag) {
						condFlag =d3.select("#dashboardHolder").attr("class");
						return condFlag == "controldashboard" ? "block" : "none";
					})
					.text(function(d){
						return (d.name);
					})
					.attr("fill",function(d){return d.colorcode})
					.attr("font-size","12px")
					.attr("font-family", "MetaOffcPro-Norm");

					var HorizontalLine= svg.append("line")          
					.style("stroke", "black")  
					.attr("x1", totalSvgWidth/4)     
					.attr("y1", yaxisHeight+75)      
					.attr("x2", totalSvgWidth/2-20)     
					.attr("y2", yaxisHeight+75)
					svg.append("text")
					.attr("dx", totalSvgWidth/2-15)
					.attr("dy", yaxisHeight+77)
					.text("Processes")
					.attr("font-family", "MetaOffcPro-Norm")
					.attr("font-size", "12px");
					svg.append("line")          
					.style("stroke", "black")  
					.attr("x1", totalSvgWidth/2+40)     
					.attr("y1", yaxisHeight+75)      
					.attr("x2", totalSvgWidth-totalSvgWidth/4)     
					.attr("y2", yaxisHeight+75)

					var verticalLine= svg.append("line")          
					.style("stroke", "black")  
					.attr("x1", -yaxisWidth-140)     
					.attr("y1", yaxisHeight/4)      
					.attr("x2", -yaxisWidth-140)     
					.attr("y2", yaxisHeight/2-20)

					svg.append("text")
					.attr("dx", -yaxisWidth-150)
					.attr("dy", yaxisHeight/2-10)
					.text("Control")
					.attr("font-family", "MetaOffcPro-Norm")
					.attr("font-size", "12px");
					svg.append("text")
					.attr("dx", -yaxisWidth-150)
					.attr("dy", yaxisHeight/2+3)
					.text("Owner")
					.attr("font-family", "MetaOffcPro-Norm")
					.attr("font-size", "12px");
					svg.append("text")
					.attr("dx", -yaxisWidth-150)
					.attr("dy", yaxisHeight/2+15)
					.text("Group")
					.attr("font-family", "MetaOffcPro-Norm")
					.attr("font-size", "12px");
					svg.append("line")          
					.style("stroke", "black")  
					.attr("x1",-yaxisWidth-140)     
					.attr("y1", yaxisHeight/2+20)      
					.attr("x2", -yaxisWidth-140)     
					.attr("y2", yaxisHeight-yaxisHeight/4);
					svg.append("defs")
					.append("pattern")
					.attr("id", "controlpending")
					.attr('patternUnits','userSpaceOnUse')
					.attr("width",20)
					.attr("height",21)
					.append("image")
					.attr("xlink:href", "assets/images/pending_CntlDb.png")
					.attr('x',0)
					.attr('y',0)
					.attr("width",18)
					.attr("height",19);
					svg.append("defs").append("marker")
					.attr("id", "arrowhead")
					.attr("markerUnits","strokeWidth")
					.attr("refX", 3)
					.attr("refY", 8)
					.attr("markerWidth", 20)
					.attr("markerHeight", 20)
					.attr("orient","auto")
					.append("path")
					.attr("d", "M2,2 L2,14 L14,8 L2,2").attr("style","fill: #57798c;")
					svg.append("defs")
					.append("pattern")
					.attr("id", "pending")
					.attr('patternUnits','userSpaceOnUse')
					.attr("width",40)
					.attr("height",40)
					.append("image")
					.attr("xlink:href", "assets/images/pending__CntlDb-white.png")
					.attr('x',10)
					.attr('y',10)
					.attr("width",20)
					.attr("height",21);
					svg.select(".xaxis").select("path").attr("d","M0,0V0H"+(actualSvgWidth+spacing)+"V0").attr('transform','translate('+-spacing+',0)').attr('stroke',"black")
					d3.select('.captureChartSection').style('display','none');

					function wrap(text, width,axis) {
                 			text.each(function() {
                 				var text = d3.select(this),
                 				words = text.text().split(/\s+/).reverse(),
                 				splitStringArray = [],
                 				word,
                 				line = [],
                 				lineNumber = 0,
						        lineHeight = 1.1, // ems
						        y = text.attr("y"),
						        dy = parseFloat(text.attr("dy")),
						        tspan = text.text(null).append("tspan").attr("x", 0).attr("y", y).attr("dy", dy + "em");
						      
						        if(axis==="xaxis"){
							        for(var i=0;i< words.length;i++){
							        	if(words[i].length > 10 ){
							        		var sb = words[i].substr(9);
							        		var sb2 = words[i].substr(0,9);
						        	 		words.splice(i,1,sb,sb2);
						        	 	
						        	 	}
						        	}
					        	}
					        	while (word = words.pop()) {
					        		line.push(word);
					        		tspan.text(line.join(" "));
					        		if (tspan.node().getComputedTextLength() > width) {
					        			line.pop();
					        			tspan.text(line.join(" "));
					        			line = [word];
					        			tspan = text.append("tspan").attr("x", 0).attr("y", y).attr("dy", ++lineNumber * lineHeight + dy + "em").text(word);
					        		}
					        	}
					        });
                 		}
				}       
			}
		}

	}])
.directive("stackedChartforpdf",['$window','pncsession','PNC_SESSION_CONFIG',function($window,pncsession,PNC_SESSION_CONFIG){
	return{
		restrict:"A",
		scope:{
			chartoptions:'='
		},
		link:function(scope,element,attrs){
			var d3 = $window.d3;
			scope.$watch('chartoptions.printObjData',function(newValue,oldValue){
				if(newValue !== oldValue){
					$('.capturePdfChartSection .stackedChartWrapper #chartPdf').empty();
					if(Object.keys(scope.chartoptions.printObjData).length !== 0){
							for(var key in scope.chartoptions.printObjData){
						 	  renderChart(scope.chartoptions.printObjData[key]);
						    }
						    renderToCanvas();
				    }
					
				}
			})
			function renderChart(data){
				var width,actualSvgWidth,yaxisHeight,maxYvalue,maxXvalue,
				bufferWidth = 50,
				spacing = scope.chartoptions.spacing,
				gridSize= scope.chartoptions.gridsize;
                d3.select('.capturePdfChartSection').style('display','block');
                var div = d3.select('.capturePdfChartSection .stackedChartWrapper #chartPdf').append('div').attr('class','chartHolder');
				var svg = div.append('svg');
				//yaxisSvg = d3.select('.yAxisSection').select('svg'),
				//tooltip = d3.select('.captureChartSection .stackedChartWrapper #chartPrint').append('div').attr("class","chartTooltip").style("opacity",0);

				svg.attr("version", "1.1");
				svg.attr("xmlns", "http://www.w3.org/2000/svg");
				svg.attr("xmlns:xlink", "http://www.w3.org/1999/xlink");
				svg = svg.append("g").attr('transform','translate(180,50)');
				var layersArr = [],
				maxXvalue = Math.max.apply(Math,data['3'].map(function(o){return o.x;}));
				maxYvalue = Math.max.apply(Math,data['3'].map(function(o){return o.y;}));
				for(var i=0;i<= maxXvalue;i++){
					var layers = [];
					layers = data['3'].filter(function(d) {
						if(d.x == i){
							return d;
						}

					});
					layersArr.push(layers)

				}

				actualSvgWidth = ((gridSize+spacing) *(maxXvalue+1));
				var actualSvgHeight = ((gridSize * (maxYvalue+1)) + 100);

				var y = d3.scale.ordinal().rangeRoundBands([0,actualSvgHeight]);

				var yAxis = d3.svg.axis().scale(y).orient("left").ticks(5).tickSize(0);

				y.domain(data['2'].map(function(d){
					return d[Object.keys(d)]
				}))

				function make_y_axis(){
					return 	d3.svg.axis().scale(y).orient("left").ticks(5);
				}   
				svg.append("g").attr("class","axis yaxis")
				.attr("transform","translate(0,0)").call(yAxis).selectAll('.tick').each(function(d,i){
					var tick = d3.select(this);
					wrap(tick.select('text'),(y.rangeBand()*2)+20,'yaxis');
					tick.attr("transform","translate(-4,"+(((i)*gridSize)+(gridSize/2))+")")
					tick.select('text').attr('font-size',12+'px')
				})

				var yaxisWidth = Math.round(d3.select('.yaxis').node().getBBox().width);
				var totalSvgWidth = actualSvgWidth + yaxisWidth;
				width =  actualSvgWidth + bufferWidth;

				div.select('svg').attr('width',totalSvgWidth + 750).attr('height',actualSvgHeight+150);
				d3.select('.captureChartSection .StackedChartSection').select('.processGroup').style("width",actualSvgWidth + 'px');

				var x = d3.scale.ordinal().rangeRoundBands([0,actualSvgWidth]);
				var xAxis = d3.svg.axis().scale(x).orient("bottom").tickSize(0);
				x.domain(data['1'].map(function(d){
					return d.PROCESS_NAME;
				}))
				var layer = svg.append('g').attr('transform','translate(10,0)').selectAll(".layer")
				.data(layersArr).enter().append("g").attr("transform",function(d,i){
					return "translate("+(i)*spacing+",0)";
				});

				layer.selectAll('rect').data(function(d){
					return d;
				})
				.enter().append("rect")
				.attr("x",function(d){
					return (d.x)* gridSize;
				})
				.attr("y",function(d){
					return (d.y)*gridSize;
				})
				.attr('fill',function(d){return d.color})
				.attr("width",gridSize)
				.attr("height",gridSize)
				

				layer.selectAll('.rect1').data(function(d){
					return d;
				})
				.enter().append("rect")
				.attr("x",function(d){
					return (d.x)* gridSize;
				})
				.attr("y",function(d){
					return (d.y)*gridSize;
				})
				.attr("width",40)
				.attr("height",40)
				.attr('fill',function(d){
					var userID = pncsession.get(PNC_SESSION_CONFIG.LOGGEDIN_USER_INFO).user_Details.userCd;
					if (d.processStatus === "Not Started" && userID === d.approverID) {
						return 'url(#pending)'
					}
					else if (d.processStatus === "Executed" && userID === d.approverID) {
						return 'url(#pending)'
					}
					else if (d.processStatus === "Rejected" && userID === d.approverID) {
						return 'url(#pending)'
					}
					else {
						return d.color;
					}
				})

				svg.append('g').attr("class","axis xaxis")
				.attr("transform","translate(20,"+(actualSvgHeight-100)+")").call(xAxis)
				.selectAll('.tick').each(function(d,i){
					var tick = d3.select(this);
					if(tick.select('text').text()=== data['1'][i].PROCESS_NAME){
						if(data['1'][i].COLOR){
							tick.style("fill",data['1'][i].COLOR);
						}
						else{
							tick.style("fill","#2c94ff");
						}
					}
					wrap(tick.select('text'),x.rangeBand()-10,'xaxis');
					tick.attr("transform","translate("+((i*(gridSize+spacing))+10)+",0)")
					tick.select('text').attr('font-size',12+'px')
				});
				
				
				svg.append("g")            
				.attr("class", "grid")
				.call(make_y_axis()
					.tickSize(-totalSvgWidth, 0, 0)
					.tickFormat("")
					).selectAll('.tick').each(function(d,i){
						var tick = d3.select(this);
						yaxisHeight = (i+1)*gridSize;
						tick.attr("transform","translate("+(-yaxisWidth)+","+(i+1)*gridSize+")")
						tick.select('line').attr("y2",2).attr("stroke","black");
						if(y.domain().length - 1 === i){
							tick.attr("style","opacity:0");
						}
					})

					svg.select('.yaxis').select('path').attr("d","M0,0V0H0V"+(yaxisHeight+(gridSize/2))).attr("transform","rotate(-180) translate(0,"+-yaxisHeight+")").attr('stroke',"black")
					d3.select('.StackedChartSection').select('.controlOwnerGroup').style("height",yaxisHeight + 'px');
					svg.append("text")
					.attr("font-size","14px")
					.attr("font-family", "MetaOffcPro-Medi")
					.attr("dx", 0)
					.attr("dy", yaxisHeight+113)
					.text("Status Legend :");
					var color = d3.scale.category20();
					var dataset =[{"x":95, "r":6, "name":"Not Applicable","type":"controldashboard","colorcode":"#586671"}, 
					{"x":200, "r":6, "name":"Not Started","type":"controldashboard","colorcode":"#2c94ff"},
					{"x":300, "r":6, "name":"Executed","type":"controldashboard","colorcode":"#fd9b00"}, 
					{"x":380, "r":6, "name":"Reviewed","type":"controldashboard","colorcode":"#23a565"},
					{"x":455, "r":6, "name":"Rejected","type":"controldashboard","colorcode":"#bf0101"},
					{"x":95, "r":6, "name":"Not Applicable","type":"enterprisedashboard","colorcode":"#586671"}, 
					{"x":200, "r":6, "name":"Not Started","type":"enterprisedashboard","colorcode":"#2c94ff"},
					{"x":300, "r":6, "name":"Executed","type":"enterprisedashboard","colorcode":"#fd9b00"}, 
					{"x":380, "r":6, "name":"Reviewed","type":"enterprisedashboard","colorcode":"#23a565"},
					{"x":455, "r":6, "name":"Rejected","type":"enterprisedashboard","colorcode":"#bf0101"},
					{"x":90, "r":6, "name":"Not Applicable","type":"statusdashboard","colorcode":"#586671"}, 
					{"x":200, "r":6, "name":"Not Started","type":"statusdashboard","colorcode":"#2c94ff"},
					{"x":300, "r":6, "name":"Executed","type":"statusdashboard","colorcode":"#fd9b00"}, 
					{"x":380, "r":6, "name":"Reviewed","type":"statusdashboard","colorcode":"#23a565"}]
					var dataset1 ={"controldashboard1":[{"x":150,"name":"Execution","colorcode":"#C14141"}, 
					{"x":210, "name":"Reporting","colorcode":"#FFA500"},
					{"x":270, "name":"Output","colorcode":"#05A505"}, 
					{"x":315, "name":"Input","colorcode":"#25A1EF"}]};
					var condFlag=d3.select("#dashboardHolder").attr("class");
					var title;
					if(condFlag == "controldashboard"){
						title="Control Dashboard"
					}
					if(condFlag == "enterprisedashboard"){
						title="Enterprise Dashboard"
					}
					if(condFlag == "statusdashboard"){
						title="Status Dashboard"
					}
					var filtered = dataset.filter(function(d) {
						return d.type == condFlag; 
					});
					var forecast = d3.select(".forecast #dropdown").text();
					svg.append("text")
					.attr("dx", actualSvgWidth/2)
					.attr("dy",-25)
					.text(title+" ("+forecast+")")
					.attr("fill","#fd7607");

					var elem = svg.selectAll("g myCircleText")
					.data(filtered)
					var ele = elem.enter()
					.append("g")
					.attr("transform", function(d){return "translate("+(d.x+d.name.length)+","+(yaxisHeight+110)+")";})

					/* var ele = svg.append('g').attr('transform',"translate(30,"+(yaxisHeight+80)+")")*/
					var circle = ele.append("circle")
					.attr("r", function(d){return d.r} )
					.attr("stroke","black")
					.style("fill",function(d){return d.colorcode});
					ele.append("text")
					.attr("dx", 12)
					.attr("dy", 5)
					.text(function(d){
						return (d.name);
					})
					.attr("font-size","12px")
					.attr("font-family", "MetaOffcPro-Norm");
					svg.append("circle")
					.attr("r", 11)
					.attr("cx", 549)
					.attr("cy",yaxisHeight+105)
					.style("fill","url(#controlpending)")
					.style("display", function(condFlag) {
						condFlag =d3.select("#dashboardHolder").attr("class");
						return condFlag == "controldashboard" ? "block" : "none";
					});
					svg.append("text")
					.attr("dx", 562)
					.attr("dy",yaxisHeight+115)
					.style("display", function(condFlag) {
						condFlag =d3.select("#dashboardHolder").attr("class");
						return condFlag == "controldashboard" ? "block" : "none";
					})
					.text("Pending")
					.attr("font-size","12px")
					.attr("font-family", "MetaOffcPro-Norm");;
					svg.append("text")
					.attr("class","onlyControlDashboard")
					.attr("dx", 0)
					.attr("dy", yaxisHeight+145)
					.style("display", function(condFlag) {
						condFlag =d3.select("#dashboardHolder").attr("class");
						return condFlag == "controldashboard" ? "block" : "none";
					})
					.text("Control Group Legend :")
					.attr("font-size","14px")
					.attr("font-family", "MetaOffcPro-Medi");
					var elem1 = svg.selectAll("g controlText")
					.data(dataset1.controldashboard1)
					var ele1 = elem1.enter()
					.append("g")
					.attr("transform", function(d){return "translate("+(d.x)+","+(yaxisHeight+145)+")";})
					ele1.append("text").data(dataset1.controldashboard1)
					.style("display", function(condFlag) {
						condFlag =d3.select("#dashboardHolder").attr("class");
						return condFlag == "controldashboard" ? "block" : "none";
					})
					.text(function(d){
						return (d.name);
					})
					.attr("fill",function(d){return d.colorcode})
					.attr("font-size","12px")
					.attr("font-family", "MetaOffcPro-Norm");

					var HorizontalLine= svg.append("line")          
					.style("stroke", "black")  
					.attr("x1", totalSvgWidth/4)     
					.attr("y1", yaxisHeight+75)      
					.attr("x2", totalSvgWidth/2-20)     
					.attr("y2", yaxisHeight+75)
					svg.append("text")
					.attr("dx", totalSvgWidth/2-15)
					.attr("dy", yaxisHeight+77)
					.text("Processes")
					.attr("font-family", "MetaOffcPro-Norm")
					.attr("font-size", "12px");
					svg.append("line")          
					.style("stroke", "black")  
					.attr("x1", totalSvgWidth/2+40)     
					.attr("y1", yaxisHeight+75)      
					.attr("x2", totalSvgWidth-totalSvgWidth/4)     
					.attr("y2", yaxisHeight+75)

					var verticalLine= svg.append("line")          
					.style("stroke", "black")  
					.attr("x1", -yaxisWidth-40)     
					.attr("y1", yaxisHeight/4)      
					.attr("x2", -yaxisWidth-40)     
					.attr("y2", yaxisHeight/2-20)

					svg.append("text")
					.attr("dx", -yaxisWidth-60)
					.attr("dy", yaxisHeight/2-10)
					.text("Control")
					.attr("font-family", "MetaOffcPro-Norm")
					.attr("font-size", "12px");
					svg.append("text")
					.attr("dx", -yaxisWidth-60)
					.attr("dy", yaxisHeight/2+3)
					.text("Owner")
					.attr("font-family", "MetaOffcPro-Norm")
					.attr("font-size", "12px");
					svg.append("text")
					.attr("dx", -yaxisWidth-60)
					.attr("dy", yaxisHeight/2+15)
					.text("Group")
					.attr("font-family", "MetaOffcPro-Norm")
					.attr("font-size", "12px");
					svg.append("line")          
					.style("stroke", "black")  
					.attr("x1",-yaxisWidth-40)     
					.attr("y1", yaxisHeight/2+20)      
					.attr("x2", -yaxisWidth-40)     
					.attr("y2", yaxisHeight-yaxisHeight/4);
					svg.append("defs")
					.append("pattern")
					.attr("id", "controlpending")
					.attr('patternUnits','userSpaceOnUse')
					.attr("width",20)
					.attr("height",21)
					.append("image")
					.attr("xlink:href", "assets/images/pending_CntlDb.png")
					.attr('x',0)
					.attr('y',0)
					.attr("width",18)
					.attr("height",19);
					svg.append("defs").append("marker")
					.attr("id", "arrowhead")
					.attr("markerUnits","strokeWidth")
					.attr("refX", 3)
					.attr("refY", 8)
					.attr("markerWidth", 20)
					.attr("markerHeight", 20)
					.attr("orient","auto")
					.append("path")
					.attr("d", "M2,2 L2,14 L14,8 L2,2").attr("style","fill: #57798c;")
					svg.append("defs")
					.append("pattern")
					.attr("id", "pending")
					.attr('patternUnits','userSpaceOnUse')
					.attr("width",40)
					.attr("height",40)
					.append("image")
					.attr("xlink:href", "assets/images/pending__CntlDb-white.png")
					.attr('x',10)
					.attr('y',10)
					.attr("width",20)
					.attr("height",21);
					svg.select(".xaxis").select("path").attr("d","M0,0V0H"+(actualSvgWidth+spacing)+"V0").attr('transform','translate('+-spacing+',0)').attr('stroke',"black")
					d3.select('.capturePdfChartSection').style('display','none');

					function wrap(text, width,axis) {
                 			text.each(function() {
                 				var text = d3.select(this),
                 				words = text.text().split(/\s+/).reverse(),
                 				splitStringArray = [],
                 				word,
                 				line = [],
                 				lineNumber = 0,
						        lineHeight = 1.1, // ems
						        y = text.attr("y"),
						        dy = parseFloat(text.attr("dy")),
						        tspan = text.text(null).append("tspan").attr("x", 0).attr("y", y).attr("dy", dy + "em");
						      
						        if(axis==="xaxis"){
							        for(var i=0;i< words.length;i++){
							        	if(words[i].length > 10 ){
							        		var sb = words[i].substr(9);
							        		var sb2 = words[i].substr(0,9);
						        	 		words.splice(i,1,sb,sb2);
						        	 	
						        	 	}
						        	}
					        	}
					        	while (word = words.pop()) {
					        		line.push(word);
					        		tspan.text(line.join(" "));
					        		if (tspan.node().getComputedTextLength() > width) {
					        			line.pop();
					        			tspan.text(line.join(" "));
					        			line = [word];
					        			tspan = text.append("tspan").attr("x", 0).attr("y", y).attr("dy", ++lineNumber * lineHeight + dy + "em").text(word);
					        		}
					        	}
					        });
                 		}
				}      
			function renderToCanvas(){
				var NumOfsvgs = $('.capturePdfChartSection').find('#chartPdf .chartHolder').length;
					    $('.imageContainer').empty();
					for(var i=0;i < NumOfsvgs;i++){                       
						  var chartContainer = $('.capturePdfChartSection').find('#chartPdf .chartHolder')[i];
                            chartContainer = $(chartContainer).html().trim();
                        var c = document.createElement('canvas');
                            $(c).attr('id',i)
                            canvg(c,chartContainer,{renderCallback:(function(c){
                            	return function(){
                            		var destinationCanvas = document.createElement("canvas");
										destinationCanvas.width = c.width;
										destinationCanvas.height = c.height;

										var destCtx = destinationCanvas.getContext('2d');

										//create a rectangle with the desired color
										destCtx.fillStyle = "#FFFFFF";
										destCtx.fillRect(0,0,c.width,c.height);

										//draw the original canvas onto the destination canvas
										destCtx.drawImage(c, 0, 0);
										var canvasID = $(c).attr('id');
                            		    var img = destinationCanvas.toDataURL("image/jpeg");
                            		   $('.imageContainer').append('<img id="'+canvasID+'" src='+img+'>')
                            		   destinationCanvas.remove()
                            	}
                            })(c)
                        });
                    }

			}
		}

	}
}])
.directive('preferedColumns',['pncsession','PNC_SESSION_CONFIG',function(pncsession,PNC_SESSION_CONFIG){
		return{
			restrict:'A',
			link:function(scope,ele,attrs){
					scope.showPreferences = function(){
						scope.hideshowFlag = !scope.hideshowFlag;
						var table =  $('#dataTable').dataTable();
						var checkboxArray = $('.preferencesDiv').find('ul input');
						var checkedArray = $('.preferencesDiv').find('ul input:checked');
						$('tbody tr').removeClass("rowActive");
				        $("tbody tr td span.options").remove();
				         $("tbody tr td").removeClass("editdelete");
						function selectedColumns(checkedArray){
		    							var selectedColumns=[];
		    							if(checkedArray.length>0){
		    							checkedArray.each(function(j){
		    							selectedColumns.push(parseInt($(checkedArray[j]).val()));
		    						});
		    							
		    						}
		    						return selectedColumns
		    						}
		    						var temp=selectedColumns(checkedArray);
		    						pncsession.update(PNC_SESSION_CONFIG.PREFERED_DATA,temp);
		    						var toRemove=temp;
                           	var allColumns = [0,1,2,3,4,5,6,7,8,9,10,11,12];
                           	if(allColumns.length!=toRemove.length){
                           	temp = allColumns.filter( function( el ) {
  								return toRemove.indexOf( el ) < 0;
							});
                           }
		    				pncsession.update(PNC_SESSION_CONFIG.HIDECOLUMN_DATA,temp);	
						if(checkboxArray.length>0){
							
							for(var loop=0;loop<checkboxArray.length;loop++){
								$(checkboxArray[loop]).removeClass('preferenceLabelChecked');
							var arr = (table.api().columns($(checkboxArray[loop]).attr("id")).nodes())[0];	
			               	for(var key in arr){
                        	$(arr[key]).hide();
                        	$(arr[key]).removeClass("editdelete");
		    				}
		    				$(table.api().columns($(checkboxArray[loop]).attr("id")).header()).hide();
			                }
						for(var j=0;j<checkedArray.length;j++){
							$(checkedArray[j]).addClass('preferenceLabelChecked');
							var arr = (table.api().columns($(checkedArray[j]).attr("id")).nodes())[0];	
			               	for(var key in arr){
                        	$(arr[key]).show();
		    				}
		    				$(table.api().columns($(checkedArray[j]).attr("id")).header()).show();
			                }
			                var lastColumn = (table.api().columns($(checkedArray[checkedArray.length-1]).attr("id")).nodes())[0];	
			            	for(var key in lastColumn){
                        	$(lastColumn[key]).addClass("editdelete");
		    				}
			            }else{

			            }

					};
					scope.cancelPreferences = function(){
						scope.hideshowFlag = !scope.hideshowFlag;
						$('.preferencesDiv').find('ul input').each(function(){
							if(!$(this).hasClass('preferenceLabelChecked')){
								$(this).prop('checked', false);
							}else{
								$(this).prop('checked', true);
							}
						})

					}
					scope.$on('getPrefernces',function(event, data){
             		scope.getCheckedPrefernces();
         			});
         			scope.getCheckedPrefernces = function(){
         				var hideColumn=pncsession.get(PNC_SESSION_CONFIG.HIDECOLUMN_DATA);	
         				if(hideColumn.length!=13){
         				for(var loop=0;loop<hideColumn.length;loop++){
         					$($('.preferencesDiv').find('ul input')[hideColumn[loop]]).removeClass('preferenceLabelChecked');
         						
         				}
         				}
						$('.preferencesDiv').find('ul input').each(function(){
							if($(this).hasClass('preferenceLabelChecked')){
								$(this).prop('checked', true);
							}else{
								$(this).prop('checked', false);
							}
						})

					};

			},
			templateUrl:'modules/secure/administration/views/preferencesTemplate.html'
		}
}])
.directive('phonenumberDirective', ['$filter', function($filter) {
		return {
			restrict: 'A',
			require: 'ngModel',
			link: function(scope, element, attributes, ctrl) {
				scope.$watch('newUser.mobileNoTxt', function(value, oldValue) {
				value = String(value);
				var number = value.replace(/[^0-9]+/g, '');
				scope.newUser.mobileNoTxt= $filter('phonenumber')(number);
				var regExp=/^(\()?\d{3}(\))?(\s)?\d{3}(-|\s)\d{4}$/;
				scope.formatFlag = false;
				if(scope.newUser.mobileNoTxt!==''){
					if(!(regExp.test(scope.newUser.mobileNoTxt))){
						scope.formatFlag = true;
					}
					else{
						scope.formatFlag = false;
					}
				}
				});
		}
			
		};
	}])
})();