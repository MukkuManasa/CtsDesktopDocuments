"use strict";
(function(){
	angular.module('PNCApp.services', [])
	  .service('pncServices', ['$http', '$q', 'pncsession', 'PNC_CONFIG', '$cookies','PNC_SESSION_CONFIG',
	   function($http, $q, pncsession, PNC_CONFIG, $cookies,PNC_SESSION_CONFIG) {

	  		//health
	  		this.healthCheck = function(){
	  			var url = PNC_CONFIG.baseUrl + "/authenticate/healthCheck";

				var deferred = $q.defer();
	            
	            $http.get(url).success(function(data, status, headers, config) {
					deferred.resolve(data);					
					pncsession.update(PNC_SESSION_CONFIG.X_XSRF_TOKEN, headers(PNC_SESSION_CONFIG.X_XSRF_TOKEN));
				}).error(function(response, status) {
							console.log( "Message:" + response);
							var errorData={};
		                    errorData.data=response;
		                    errorData.errorCode= status;
		                    deferred.reject(errorData);
						});

				return deferred.promise;
	  		}

	  		//Export to XLS
			this.exportToExcel = function(userID,eventId,excelUrl) {
				var deferred = $q.defer();
				var url = PNC_CONFIG.baseUrl + excelUrl;//"/service/exportMyQueue";
	            var config;
	            var data = { userCd : userID, eventId: eventId}

	            config = { responseType: 'arraybuffer' };

	            $http.post(url, data, config).success(function(data, status, headers, config) {
					deferred.resolve(data);
				}).error(function(response, status) {
							console.log( "Message:" + response);
							var errorData={};
		                    errorData.data=response;
		                    errorData.errorCode= status;
		                    deferred.reject(errorData);
						});

				return deferred.promise;
			}

			//Export to XLS
			this.exportToPDF = function(userID,eventId,pdfUrl) {
				var deferred = $q.defer();
				var url = PNC_CONFIG.baseUrl + pdfUrl;//"/service/exportMyQueuePDF";
	            var config;
	            var data = { userCd : userID, eventId: eventId}

	            config = { responseType: 'arraybuffer' };

	            $http.post(url, data, config).success(function(data, status, headers, config) {
					deferred.resolve(data);
				}).error(function(response, status) {
							console.log( "Message:" + response);
							var errorData={};
		                    errorData.data=response;
		                    errorData.errorCode= status;
		                    deferred.reject(errorData);
						});

				return deferred.promise;
			}

	  		//single sign on
	  		this.isSingleSignOn = function(){
	  			var url = PNC_CONFIG.baseUrl + "/authenticate/isSingleSignOn";

				var deferred = $q.defer();
	            
				$http.get(url).success(function(data, status, headers, config) {
					deferred.resolve(data);					
					if(data.isSingleSignOn){
						pncsession.update(PNC_SESSION_CONFIG.X_XSRF_TOKEN, headers(PNC_SESSION_CONFIG.X_XSRF_TOKEN));					
					}
				}).error(function(response, status) {
							console.log( "Message:" + response);
							var errorData={};
		                    errorData.data=response;
		                    errorData.errorCode= status;
		                    deferred.reject(errorData);
						});

				return deferred.promise;
	  		}

	  		//Login
	  		this.login = function(data) {
	  			
				var url = PNC_CONFIG.baseUrl + "/authenticate/authenticateUser";

				var deferred = $q.defer();
	            var data = {username : data.username, password : data.password};
	            
	            $http.post(url, data).success(function(data, status, headers, config) {
					deferred.resolve(data);
					pncsession.update(PNC_SESSION_CONFIG.LOGGEDIN_USER_INFO, data);
				}).error(function(response, status) {
							console.log( "Message:" + response);
							var errorData={};
		                    errorData.data=response;
		                    errorData.errorCode= status;
		                    deferred.reject(errorData);
						});

				return deferred.promise;
			}

			//Logout
	  		this.logout = function(data) {
	  			
				var url = PNC_CONFIG.baseUrl + "/authenticate/logout";

				var deferred = $q.defer();
	            
				$http.get(url).success(function(data, status, headers, config) {
					deferred.resolve(data);
					if(data.isLogoutSuccess){
						pncsession.removeAll();
					}
				}).error(function(response, status) {
							console.log( "Message:" + response);
							var errorData={};
		                    errorData.data=response;
		                    errorData.errorCode= status;
		                    deferred.reject(errorData);
						});

				return deferred.promise;
			}

			this.loggedInUserInfo = function(){
				var deferred = $q.defer();
				var url = PNC_CONFIG.baseUrl + "/service/getLoggedInUser";
	            
	            $http.get(url).success(function(data, status, headers, config) {
					deferred.resolve(data);
					pncsession.update(PNC_SESSION_CONFIG.LOGGEDIN_USER_INFO, data);
				}).error(function(response, status) {
					console.log( "Message:" + response);
					var errorData={};
                    errorData.data=response;
                    errorData.errorCode= status;
                    deferred.reject(errorData);
				});

				return deferred.promise;
				
			}

			//Task meter
			this.getTaskMeter = function(userID) {
				var deferred = $q.defer();
				var url = PNC_CONFIG.baseUrl + "/service/getTaskMeter";
	            var data = { userCd : userID, eventId: '' }

	            $http.post(url, data).success(function(data, status, headers, config) {
					deferred.resolve(data);
					pncsession.update(PNC_SESSION_CONFIG.TASK_METER, data);
				}).error(function(response, status) {
							console.log( "Message:" + response);
							var errorData={};
		                    errorData.data=response;
		                    errorData.errorCode= status;
		                    deferred.reject(errorData);
						});

				return deferred.promise;

			}

			//getMyQueue
			this.getMyQueue = function(userID,eventId) {
				var deferred = $q.defer();
				var url = PNC_CONFIG.baseUrl + "/service/getMyQueue";
				var data = { userCd : userID, eventId: eventId };
				  
	            $http.post(url, data).success(function(data, status, headers, config) {
					deferred.resolve(data);
					pncsession.update(PNC_SESSION_CONFIG.GET_MYQUEUE, data);
				}).error(function(response, status) {
							console.log( "Message:" + response);
							var errorData={};
		                    errorData.data=response;
		                    errorData.errorCode= status;
		                    deferred.reject(errorData);
						});

				return deferred.promise;

			}

	  		/*Get Users*/
	   		this.getUsers = function(){
	   			var deferred = $q.defer();
	   			var url = PNC_CONFIG.baseUrl + "/service/getUsers";

				$http.post(url).success(function(data, status, headers, config) {
					deferred.resolve(data);
					pncsession.update(PNC_SESSION_CONFIG.GET_USER_DATA,data);
				}).error(function(response, status) {
							console.log( "Message:" + response);
							var errorData={};
		                    errorData.data=response;
		                    errorData.errorCode= status;
		                    deferred.reject(errorData);
						});

				return deferred.promise;
	   		}
	   		/* Save Users*/
	   		this.saveUsers = function(newUser){
	   			var deferred = $q.defer();
	   			var url = PNC_CONFIG.baseUrl + "/service/saveUser";
	   			var userId=pncsession.get(PNC_SESSION_CONFIG.LOGGEDIN_USER_INFO).user_Details.userCd;
	   			 var data = { userCd  : newUser.userCd, firstNameTxt: newUser.firstNameTxt, middleNameTxt:newUser.middleNameTxt,lastNameTxt:newUser.lastNameTxt,emailAddrTxt:newUser.emailAddrTxt,mailingAddrTxt:newUser.mailingAddrTxt,officeAddrTxt:newUser.officeAddrTxt,mobileNoTxt:newUser.mobileNoTxt,officePhoneTxt:newUser.officePhoneTxt,homeNoTxt:newUser.homeNoTxt,isDeletedFlag:newUser.isDeletedFlag,lastUpdatedByUserCd  : userId,roleList:newUser.roleList,defaultRole:newUser.defaultRole};
				$http.post(url,data).success(function(data, status, headers, config) {
					deferred.resolve(data);
					pncsession.update(PNC_SESSION_CONFIG.SAVE_USER_DATA,data);
				}).error(function(response, status) {
							console.log( "Message:" + response);
							var errorData={};
		                    errorData.data=response;
		                    errorData.errorCode= status;
		                    deferred.reject(errorData);
						});

				return deferred.promise;
	   		}
	   		/*update User*/
	   		
	   		this.updateUser = function(newUser){
	   			var deferred = $q.defer();
	   			var url = PNC_CONFIG.baseUrl + "/service/updateUser";
	   			var userId=pncsession.get(PNC_SESSION_CONFIG.LOGGEDIN_USER_INFO).user_Details.userCd;
	   			  var data = { userCd  : newUser.userCd, firstNameTxt: newUser.firstNameTxt, middleNameTxt:newUser.middleNameTxt,lastNameTxt:newUser.lastNameTxt,emailAddrTxt:newUser.emailAddrTxt,mailingAddrTxt:newUser.mailingAddrTxt,officeAddrTxt:newUser.officeAddrTxt,mobileNoTxt:newUser.mobileNoTxt,officePhoneTxt:newUser.officePhoneTxt,homeNoTxt:newUser.homeNoTxt,isDeletedFlag:newUser.isDeletedFlag,lastUpdatedByUserCd  : userId,roleList:newUser.roleList,defaultRole:newUser.defaultRole};
				$http.post(url,data).success(function(data, status, headers, config) {
					deferred.resolve(data);
					pncsession.update(PNC_SESSION_CONFIG.UPDATEUSER_DATA,data);
				}).error(function(response, status) {
							console.log( "Message:" + response);
							var errorData={};
		                    errorData.data=response;
		                    errorData.errorCode= status;
		                    deferred.reject(errorData);
						});

				return deferred.promise;
	   		}
	   		/* get Users By Id*/
	   		this.getUserByID = function(userId){
	   			var deferred = $q.defer();
	   			var url = PNC_CONFIG.baseUrl + "/service/getUserByUserCd";
	   			
	   			 var data = { userCd  : userId};
				$http.post(url,data).success(function(data, status, headers, config) {
					deferred.resolve(data);
					pncsession.update(PNC_SESSION_CONFIG.GETUSER_BYID_DATA,data);
				}).error(function(response, status) {
							console.log( "Message:" + response);
							var errorData={};
		                    errorData.data=response;
		                    errorData.errorCode= status;
		                    deferred.reject(errorData);
						});

				return deferred.promise;
	   		}
	   		/* Delete User*/
	   		this.deleteUser = function(userId,flag){
	   			var deferred = $q.defer();
	   			var url = PNC_CONFIG.baseUrl + "/service/deleteUser";
	   			
	   			 var data = { userCd  : userId,isDeletedFlag:flag,lastUpdatedByUserCd:pncsession.get(PNC_SESSION_CONFIG.LOGGEDIN_USER_INFO).user_Details.userCd};
				$http.post(url,data).success(function(data, status, headers, config) {
					deferred.resolve(data);
					pncsession.update(PNC_SESSION_CONFIG.DELETE_USER_DATA,data);
				}).error(function(response, status) {
							console.log( "Message:" + response);
							var errorData={};
		                    errorData.data=response;
		                    errorData.errorCode= status;
		                    deferred.reject(errorData);
						});

				return deferred.promise;
	   		}
	   		/*Get Roles for User*/
	   		this.getRolesForUser = function(){
	   			var deferred = $q.defer();
	   			var url = PNC_CONFIG.baseUrl + "/service/getRolesForUser";

				$http.post(url).success(function(data, status, headers, config) {
					deferred.resolve(data);
					pncsession.update(PNC_SESSION_CONFIG.GETROLESFORUSER_DATA,data);
				}).error(function(response, status) {
							console.log( "Message:" + response);
							var errorData={};
		                    errorData.data=response;
		                    errorData.errorCode= status;
		                    deferred.reject(errorData);
						});

				return deferred.promise;
	   		}
	   		
	   		/*Get Roles*/
	   		this.getRoles = function(){
	   			var deferred = $q.defer();
	   			var url = PNC_CONFIG.baseUrl + "/service/getRoles";

				$http.post(url).success(function(data, status, headers, config) {
					deferred.resolve(data);
					pncsession.update(PNC_SESSION_CONFIG.GETROLES_DATA,data);
				}).error(function(response, status) {
							console.log( "Message:" + response);
							var errorData={};
		                    errorData.data=response;
		                    errorData.errorCode= status;
		                    deferred.reject(errorData);
						});

				return deferred.promise;
	   		}
	   		/* Add Roles*/
	   		this.createRole = function(newRole){
	   			var deferred = $q.defer();
	   			var url = PNC_CONFIG.baseUrl + "/service/createRole";
	   			var userId=pncsession.get(PNC_SESSION_CONFIG.LOGGEDIN_USER_INFO).user_Details.userCd;
	   			 var data = { roleCd  : newRole.roleCd, roleDescTxt: newRole.roleDescTxt, commentTxt:newRole.commentTxt,isActiveFlag:newRole.isActiveFlag,updatedByUserCd:userId};
				$http.post(url,data).success(function(data, status, headers, config) {
					deferred.resolve(data);
					pncsession.update(PNC_SESSION_CONFIG.ADD_ROLE_DATA,data);
				}).error(function(response, status) {
							console.log( "Message:" + response);
							var errorData={};
		                    errorData.data=response;
		                    errorData.errorCode= status;
		                    deferred.reject(errorData);
						});

				return deferred.promise;
	   		}
	   		/* Update Roles*/
	   		this.updateRole = function(newRole){
	   			var deferred = $q.defer();
	   			var url = PNC_CONFIG.baseUrl + "/service/updateRole";
	   			var userId=pncsession.get(PNC_SESSION_CONFIG.LOGGEDIN_USER_INFO).user_Details.userCd;
	   			 var data = { roleCd  : newRole.roleCd, roleDescTxt: newRole.roleDescTxt, commentTxt:newRole.commentTxt,isActiveFlag:newRole.isActiveFlag,updatedByUserCd:userId};
				$http.post(url,data).success(function(data, status, headers, config) {
					deferred.resolve(data);
					pncsession.update(PNC_SESSION_CONFIG.UPDATE_ROLE_DATA,data);
				}).error(function(response, status) {
							console.log( "Message:" + response);
							var errorData={};
		                    errorData.data=response;
		                    errorData.errorCode= status;
		                    deferred.reject(errorData);
						});

				return deferred.promise;
	   		}
	   		/* getRole By Id*/
	   		this.getRoleById = function(roleId){
	   			var deferred = $q.defer();
	   			var url = PNC_CONFIG.baseUrl + "/service/getRoleById";
	   			
	   			 var data = { roleCd  : roleId};
				$http.post(url,data).success(function(data, status, headers, config) {
					deferred.resolve(data);
					pncsession.update(PNC_SESSION_CONFIG.GETROLE_BYID_DATA,data);
				}).error(function(response, status) {
							console.log( "Message:" + response);
							var errorData={};
		                    errorData.data=response;
		                    errorData.errorCode= status;
		                    deferred.reject(errorData);
						});

				return deferred.promise;
	   		}
	   		/* Delete Role*/
	   		this.deleteRole = function(roleId,flag){
	   			var deferred = $q.defer();
	   			var url = PNC_CONFIG.baseUrl + "/service/deleteRole";
	   			 var data = { roleCd  : roleId,isActiveFlag:flag,updatedByUserCd:pncsession.get(PNC_SESSION_CONFIG.LOGGEDIN_USER_INFO).user_Details.userCd};
				$http.post(url,data).success(function(data, status, headers, config) {
					deferred.resolve(data);
					pncsession.update(PNC_SESSION_CONFIG.DELETE_ROLE_DATA,data);
				}).error(function(response, status) {
							console.log( "Message:" + response);
							var errorData={};
		                    errorData.data=response;
		                    errorData.errorCode= status;
		                    deferred.reject(errorData);
						});

				return deferred.promise;
	   		}
	   		
	   		//Get Users
	   		this.sendMail = function(toAddress, mailBody, mailInputParams){
	   			var deferred = $q.defer();
	   			var url = PNC_CONFIG.baseUrl + "/service/mailMyQueue";

	   			var data = { toAddress : toAddress, mailBodyParams: mailBody, moduleInputParams: mailInputParams};

				$http.post(url, data).success(function(data, status, headers, config) {
					deferred.resolve(data);
				}).error(function(response, status) {
							console.log( "Message:" + response);
							var errorData={};
		                    errorData.data=response;
		                    errorData.errorCode= status;
		                    deferred.reject(errorData);
						});

				return deferred.promise;
	   		}

	   		
	   		//get forecast purpose dropdown

	   		this.getForecastDropDown = function(){
	   			var deferred = $q.defer();
				var url = PNC_CONFIG.baseUrl + "/service/getEvents";
				$http.post(url).success(function(data, status, headers, config) {
					deferred.resolve(data);
					pncsession.update(PNC_SESSION_CONFIG.GET_EVENTS, data);
				}).error(function(response, status) {
							console.log( "Message:" + response);
							var errorData={};
		                    errorData.data=response;
		                    errorData.errorCode= status;
		                    deferred.reject(errorData);
						});

				return deferred.promise;
	   		}

	   		//get Chart data
	   		this.getChartDashBoardData = function(userID,eventId,dashboardUrl){

	   			var deferred = $q.defer();
				var url = PNC_CONFIG.baseUrl + dashboardUrl;
	            var data = { userCd : userID, eventId: eventId };

	             $http.post(url, data).success(function(data, status, headers, config) {
					deferred.resolve(data);
				}).error(function(response, status) {
							console.log( "Message:" + response);
							var errorData={};
		                    errorData.data=response;
		                    errorData.errorCode= status;
		                    deferred.reject(errorData);
						});

				return deferred.promise;
	   		}

	   		/*Get chart data for print*/
	   		this.getChartPrintDashBoardData = function(userID,eventId,dashboardUrl){
	   			var deferred = $q.defer();
				var url = PNC_CONFIG.baseUrl + dashboardUrl;
	            var data = { userCd : userID, eventId: eventId };

	            $http.post(url, data).success(function(data, status, headers, config) {
					deferred.resolve(data);
				}).error(function(response, status) {
							console.log( "Message:" + response);
							var errorData={};
		                    errorData.data=response;
		                    errorData.errorCode= status;
		                    deferred.reject(errorData);
						});

				return deferred.promise;
	   		}

	   		/* pop up service*/
	   		this.showModel  = function(userId,processId){

	   			var deferred = $q.defer();
				var url = PNC_CONFIG.baseUrl + "/service/getApproveRejectData";
	            var data = { userCd  : userId, processId: processId };

	            $http.post(url, data).success(function(data, status, headers, config) {
					deferred.resolve(data);
					pncsession.update(PNC_SESSION_CONFIG.SHOWMODEL_DATA,data);
				}).error(function(response, status) {
							console.log( "Message:" + response);
							var errorData={};
		                    errorData.data=response;
		                    errorData.errorCode= status;
		                    deferred.reject(errorData);
						});

				return deferred.promise;
	   		}
	   		/* Execute/review/reject Button clicked*/
	   		this.approveProcess  = function(ProcessPojo){

	   			var deferred = $q.defer();
				var url = PNC_CONFIG.baseUrl + "/service/approveProcess";
	            var data = { processId  : ProcessPojo.processId,executorComments : ProcessPojo.executorComments,approverComments:ProcessPojo.approverComments,documentationFilePath:ProcessPojo.documentationFilePath,processStatus:ProcessPojo.processStatus,delegateTo:ProcessPojo.delegateTo,userId:ProcessPojo.userId,reviewerName:ProcessPojo.reviewerName,ownerName:ProcessPojo.ownerName,controlExecutorEmail:ProcessPojo.controlExecutorEmail,controlReviewerEmail:ProcessPojo.controlReviewerEmail,processName:ProcessPojo.processName};

	            $http.post(url, data).success(function(data, status, headers, config) {
					deferred.resolve(data);
					pncsession.update(PNC_SESSION_CONFIG.PROCESS_DATA,data);
				}).error(function(response, status) {
							console.log( "Message:" + response);
							var errorData={};
		                    errorData.data=response;
		                    errorData.errorCode= status;
		                    deferred.reject(errorData);
						});

				return deferred.promise;
	   		}

	   		/* Show Audit Button Click Service*/
	   		this.getProcessAuditData  = function(userId,processId){

	   			var deferred = $q.defer();
				var url = PNC_CONFIG.baseUrl + "/service/getProcessAuditData";
	            var data = { userCd  : userId, processId: processId };

	            $http.post(url, data).success(function(data, status, headers, config) {
					deferred.resolve(data);
					pncsession.update(PNC_SESSION_CONFIG.AUDIT_DATA,data);
				}).error(function(response, status) {
							console.log( "Message:" + response);
							var errorData={};
		                    errorData.data=response;
		                    errorData.errorCode= status;
		                    deferred.reject(errorData);
						});

				return deferred.promise;
	   		}

	   		this.getSeedData  = function(){

	   			var deferred = $q.defer();
				var url = PNC_CONFIG.baseUrl + "/service/getModelsFromModelUsage";
	      

	            $http.post(url).success(function(data, status, headers, config) {
					deferred.resolve(data);
					pncsession.update(PNC_SESSION_CONFIG.SEED_DATA,data);
					
				}).error(function(response, status) {
							console.log( "Message:" + response);
							var errorData={};
		                    errorData.data=response;
		                    errorData.errorCode= status;
		                    deferred.reject(errorData);
						});

				return deferred.promise;
	   		}
	   		/*Get All Model Datas*/
	   		this.getAllAvailableModels  = function(){

	   			var deferred = $q.defer();
				var url = PNC_CONFIG.baseUrl + "/service/getAllAvailableModels";
	      

	            $http.post(url).success(function(data, status, headers, config) {
					deferred.resolve(data);
					pncsession.update(PNC_SESSION_CONFIG.AVAILABLEMODEL_DATA,data);
					
				}).error(function(response, status) {
							console.log( "Message:" + response);
							var errorData={};
		                    errorData.data=response;
		                    errorData.errorCode= status;
		                    deferred.reject(errorData);
						});

				return deferred.promise;
	   		}

	   		this.getSegments = function(){

	   			var deferred = $q.defer();
				var url = PNC_CONFIG.baseUrl + "/service/getSegments";
	      

	            $http.post(url).success(function(data, status, headers, config) {
					deferred.resolve(data);
					pncsession.update(PNC_SESSION_CONFIG.SEGMENTS_DATA,data);
					
				}).error(function(response, status) {
							console.log( "Message:" + response);
							var errorData={};
		                    errorData.data=response;
		                    errorData.errorCode= status;
		                    deferred.reject(errorData);
						});

				return deferred.promise;
	   		}

	   		this.getVariables = function(){

	   			var deferred = $q.defer();
				var url = PNC_CONFIG.baseUrl + "/service/getAllFromVariablemaster";
	      

	            $http.post(url).success(function(data, status, headers, config) {
					deferred.resolve(data);
					pncsession.update(PNC_SESSION_CONFIG.SEGMENTS_DATA,data);
					
				}).error(function(response, status) {
							console.log( "Message:" + response);
							var errorData={};
		                    errorData.data=response;
		                    errorData.errorCode= status;
		                    deferred.reject(errorData);
						});

				return deferred.promise;
	   		}
	  }]);
})();